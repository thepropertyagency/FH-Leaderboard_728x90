(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.IMG01jpgcopy = function() {
	this.initialize(img.IMG01jpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,556);


(lib.IMG02jpgcopy = function() {
	this.initialize(img.IMG02jpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,556);


(lib.IMG03 = function() {
	this.initialize(img.IMG03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,480,300);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG03();
	this.instance.parent = this;
	this.instance.setTransform(-179,-111.85,0.7458,0.7458);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179,-111.8,358,223.7);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG03();
	this.instance.parent = this;
	this.instance.setTransform(-179,-111.85,0.7458,0.7458);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179,-111.8,358,223.7);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG02jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG02jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-221,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-221,-278,500,556);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG01jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG01jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.4,6.9).lineTo(-1.4,-6.9).lineTo(1.5,-6.9).lineTo(1.5,6.9).closePath();
	this.shape.setTransform(57.85,11.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.4,6.9).lineTo(-1.4,-6.9).lineTo(1.5,-6.9).lineTo(1.5,6.9).closePath();
	this.shape_1.setTransform(52.45,11.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.5,7).lineTo(-1.5,-2.5).lineTo(1.4,-2.5).lineTo(1.4,7).closePath().moveTo(-1.2,-4.1).curveTo(-1.7,-4.7,-1.7,-5.4).curveTo(-1.7,-6,-1.2,-6.5).curveTo(-0.7,-7,-0,-7).curveTo(0.7,-7,1.2,-6.5).curveTo(1.7,-6,1.7,-5.4).curveTo(1.7,-4.7,1.2,-4.1).curveTo(0.7,-3.7,-0,-3.7).curveTo(-0.7,-3.7,-1.2,-4.1).closePath();
	this.shape_2.setTransform(47.075,10.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#2E2E2E").beginStroke().moveTo(2.7,6.7).lineTo(2.7,1.4).lineTo(-2.7,1.4).lineTo(-2.7,6.7).lineTo(-5.7,6.7).lineTo(-5.7,-6.7).lineTo(-2.7,-6.7).lineTo(-2.7,-1.5).lineTo(2.7,-1.5).lineTo(2.7,-6.7).lineTo(5.7,-6.7).lineTo(5.7,6.7).closePath();
	this.shape_3.setTransform(37.2,11.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.3,3.7).curveTo(-4.7,2.3,-4.7,-0).curveTo(-4.7,-2.2,-3.3,-3.7).curveTo(-1.9,-5,-0,-5).curveTo(2.2,-5,3.4,-3.7).curveTo(4.7,-2.4,4.7,-0.2).lineTo(4.6,0.7).lineTo(-1.9,0.7).curveTo(-1.9,1.5,-1.3,2).curveTo(-0.6,2.6,0.2,2.6).curveTo(1.7,2.6,2.1,1.3).lineTo(4.5,2).curveTo(4.2,3.3,3.1,4.1).curveTo(1.9,5,0.2,5).curveTo(-1.9,5,-3.3,3.7).closePath().moveTo(1.9,-1.1).curveTo(1.9,-1.8,1.5,-2.2).curveTo(1,-2.7,0,-2.7).curveTo(-0.8,-2.7,-1.4,-2.2).curveTo(-1.8,-1.7,-1.9,-1.1).lineTo(1.9,-1.1).lineTo(1.9,-1.1).closePath();
	this.shape_4.setTransform(20.125,13.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.3,3.7).curveTo(-4.7,2.3,-4.7,-0).curveTo(-4.7,-2.2,-3.3,-3.7).curveTo(-1.9,-5,-0,-5).curveTo(2.2,-5,3.4,-3.7).curveTo(4.7,-2.4,4.7,-0.2).lineTo(4.6,0.7).lineTo(-1.9,0.7).curveTo(-1.9,1.5,-1.3,2).curveTo(-0.6,2.6,0.2,2.6).curveTo(1.7,2.6,2.1,1.3).lineTo(4.5,2).curveTo(4.2,3.3,3.1,4.1).curveTo(1.9,5,0.2,5).curveTo(-1.9,5,-3.3,3.7).closePath().moveTo(1.9,-1.1).curveTo(1.9,-1.8,1.5,-2.2).curveTo(1,-2.7,0,-2.7).curveTo(-0.8,-2.7,-1.4,-2.2).curveTo(-1.8,-1.7,-1.9,-1.1).lineTo(1.9,-1.1).lineTo(1.9,-1.1).closePath();
	this.shape_5.setTransform(9.525,13.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3,4.8).lineTo(-3,-4.7).lineTo(-0.2,-4.7).lineTo(-0.2,-3.4).curveTo(0.5,-4.8,2.3,-4.8).lineTo(3,-4.7).lineTo(3,-1.8).lineTo(2.1,-1.9).curveTo(1.2,-1.9,0.6,-1.3).curveTo(-0.1,-0.7,-0.1,0.7).lineTo(-0.1,4.8).closePath();
	this.shape_6.setTransform(0.8,13.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-0.6,5.4).curveTo(-1.5,4.6,-1.5,3.2).lineTo(-1.5,-0.9).lineTo(-3.2,-0.9).lineTo(-3.2,-3.4).lineTo(-2.7,-3.4).curveTo(-1.3,-3.4,-1.3,-5).lineTo(-1.3,-6.2).lineTo(1.4,-6.2).lineTo(1.4,-3.4).lineTo(3.2,-3.4).lineTo(3.2,-0.9).lineTo(1.4,-0.9).lineTo(1.4,2.6).curveTo(1.4,3.6,2.4,3.6).lineTo(3.2,3.5).lineTo(3.2,5.9).curveTo(2.6,6.2,1.6,6.2).curveTo(0.1,6.2,-0.6,5.4).closePath();
	this.shape_7.setTransform(-7.3,11.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.4,5.7).curveTo(-4.6,4.7,-4.9,3.4).lineTo(-2.3,2.6).curveTo(-2.2,3.4,-1.6,3.8).curveTo(-1.1,4.2,-0.3,4.3).curveTo(2,4.3,2,1.8).lineTo(2,1.4).curveTo(1.3,2.4,-0.5,2.4).curveTo(-2.4,2.5,-3.6,1.2).curveTo(-4.9,-0.2,-4.9,-2.1).curveTo(-4.9,-4.1,-3.6,-5.4).curveTo(-2.4,-6.7,-0.5,-6.7).curveTo(1.5,-6.7,2.1,-5.6).lineTo(2.1,-6.6).lineTo(4.9,-6.6).lineTo(4.9,1.6).curveTo(4.9,3.9,3.7,5.2).curveTo(2.4,6.7,-0.2,6.8).curveTo(-2.1,6.8,-3.4,5.7).closePath().moveTo(-1.4,-3.7).curveTo(-2,-3.1,-2,-2.1).curveTo(-2,-1.2,-1.4,-0.6).curveTo(-0.8,-0,0.1,-0.1).curveTo(0.9,-0,1.5,-0.6).curveTo(2.1,-1.2,2.1,-2.1).curveTo(2.1,-3.1,1.5,-3.7).curveTo(0.9,-4.2,0.1,-4.2).curveTo(-0.8,-4.2,-1.4,-3.7).closePath();
	this.shape_8.setTransform(-16.725,15.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.5,7).lineTo(-1.5,-2.5).lineTo(1.4,-2.5).lineTo(1.4,7).closePath().moveTo(-1.2,-4.1).curveTo(-1.7,-4.7,-1.7,-5.4).curveTo(-1.7,-6,-1.2,-6.5).curveTo(-0.7,-7,-0,-7).curveTo(0.7,-7,1.2,-6.5).curveTo(1.7,-6,1.7,-5.4).curveTo(1.7,-4.7,1.2,-4.1).curveTo(0.7,-3.7,-0,-3.7).curveTo(-0.7,-3.7,-1.2,-4.1).closePath();
	this.shape_9.setTransform(-24.875,10.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-4.4,6.7).lineTo(-4.4,-6.7).lineTo(4.4,-6.7).lineTo(4.4,-3.9).lineTo(-1.4,-3.9).lineTo(-1.4,-1).lineTo(3.7,-1).lineTo(3.7,1.7).lineTo(-1.3,1.7).lineTo(-1.3,6.7).closePath();
	this.shape_10.setTransform(-32.55,11.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-0.7,5.4).curveTo(-1.5,4.6,-1.5,3.2).lineTo(-1.5,-0.9).lineTo(-3.2,-0.9).lineTo(-3.2,-3.4).lineTo(-2.7,-3.4).curveTo(-1.2,-3.4,-1.2,-5).lineTo(-1.2,-6.2).lineTo(1.3,-6.2).lineTo(1.3,-3.4).lineTo(3.2,-3.4).lineTo(3.2,-0.9).lineTo(1.3,-0.9).lineTo(1.3,2.6).curveTo(1.3,3.6,2.4,3.6).lineTo(3.1,3.5).lineTo(3.1,5.9).curveTo(2.6,6.2,1.7,6.2).curveTo(0.2,6.2,-0.7,5.4).closePath();
	this.shape_11.setTransform(-46.85,11.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.5,4.2).curveTo(-4.3,3.3,-4.3,2.2).curveTo(-4.3,0.9,-3.5,0.2).curveTo(-2.8,-0.5,-1.5,-0.7).lineTo(0.7,-1.1).curveTo(1.4,-1.2,1.4,-1.7).curveTo(1.4,-2.1,1,-2.4).curveTo(0.6,-2.7,-0,-2.7).curveTo(-0.7,-2.7,-1.2,-2.3).curveTo(-1.6,-1.9,-1.6,-1.3).lineTo(-4.1,-1.9).curveTo(-4,-3,-3.1,-3.9).curveTo(-1.9,-5,0,-5).curveTo(2.2,-5,3.3,-3.9).curveTo(4.2,-3,4.2,-1.3).lineTo(4.2,3.3).curveTo(4.2,4.2,4.3,4.7).lineTo(1.7,4.7).lineTo(1.6,3.7).curveTo(0.8,5,-1.1,5).curveTo(-2.5,5,-3.5,4.2).closePath().moveTo(-0.4,0.9).curveTo(-1.5,1.1,-1.5,1.9).curveTo(-1.5,2.9,-0.3,2.9).curveTo(1.4,2.9,1.4,1).lineTo(1.4,0.7).closePath();
	this.shape_12.setTransform(-55.575,13.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,3.7).curveTo(-4.7,2.3,-4.7,-0).curveTo(-4.7,-2.2,-3.3,-3.7).curveTo(-1.9,-5,-0,-5).curveTo(2.2,-5,3.4,-3.7).curveTo(4.7,-2.4,4.7,-0.2).lineTo(4.6,0.7).lineTo(-1.9,0.7).curveTo(-1.9,1.5,-1.3,2).curveTo(-0.6,2.6,0.2,2.6).curveTo(1.7,2.6,2.1,1.3).lineTo(4.5,2).curveTo(4.2,3.3,3.1,4.1).curveTo(1.9,5,0.2,5).curveTo(-1.9,5,-3.3,3.7).closePath().moveTo(1.9,-1.1).curveTo(1.9,-1.8,1.5,-2.2).curveTo(1,-2.7,0,-2.7).curveTo(-0.8,-2.7,-1.4,-2.2).curveTo(-1.8,-1.7,-1.9,-1.1).lineTo(1.9,-1.1).lineTo(1.9,-1.1).closePath();
	this.shape_13.setTransform(73.025,-8.825);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.3,4.7).lineTo(-5.2,-4.7).lineTo(-2.1,-4.7).lineTo(0.1,1.2).lineTo(2.1,-4.7).lineTo(5.2,-4.7).lineTo(1.6,4.7).closePath();
	this.shape_14.setTransform(62.325,-8.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.5,7).lineTo(-1.5,-2.5).lineTo(1.4,-2.5).lineTo(1.4,7).closePath().moveTo(-1.2,-4.1).curveTo(-1.7,-4.7,-1.7,-5.4).curveTo(-1.7,-6,-1.2,-6.5).curveTo(-0.7,-7,-0,-7).curveTo(0.7,-7,1.2,-6.5).curveTo(1.7,-6,1.7,-5.4).curveTo(1.7,-4.7,1.2,-4.1).curveTo(0.7,-3.7,-0,-3.7).curveTo(-0.7,-3.7,-1.2,-4.1).closePath();
	this.shape_15.setTransform(54.275,-11.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.4,6.9).lineTo(-1.4,-6.9).lineTo(1.5,-6.9).lineTo(1.5,6.9).closePath();
	this.shape_16.setTransform(48.85,-10.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,3.6).curveTo(-5,2.2,-5,-0).curveTo(-5,-2.2,-3.6,-3.6).curveTo(-2.2,-5,0,-5).curveTo(2.1,-5,3.6,-3.6).curveTo(5,-2.2,5,-0).curveTo(5,2.2,3.6,3.6).curveTo(2.1,5,0,5).curveTo(-2.1,5,-3.6,3.6).closePath().moveTo(-1.4,-1.8).curveTo(-2.1,-1.1,-2.1,-0).curveTo(-2.1,1.1,-1.4,1.8).curveTo(-0.9,2.4,0,2.4).curveTo(0.9,2.4,1.5,1.8).curveTo(2.1,1.1,2.2,-0).curveTo(2.1,-1.1,1.5,-1.8).curveTo(0.9,-2.3,0,-2.3).curveTo(-0.9,-2.3,-1.4,-1.8).closePath();
	this.shape_17.setTransform(35.9,-8.825);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.6,5.4).curveTo(-1.5,4.6,-1.5,3.2).lineTo(-1.5,-0.9).lineTo(-3.2,-0.9).lineTo(-3.2,-3.4).lineTo(-2.7,-3.4).curveTo(-1.3,-3.4,-1.3,-5).lineTo(-1.3,-6.2).lineTo(1.4,-6.2).lineTo(1.4,-3.4).lineTo(3.2,-3.4).lineTo(3.2,-0.9).lineTo(1.4,-0.9).lineTo(1.4,2.6).curveTo(1.4,3.6,2.4,3.6).lineTo(3.2,3.5).lineTo(3.2,5.9).curveTo(2.6,6.2,1.6,6.2).curveTo(0.1,6.2,-0.6,5.4).closePath();
	this.shape_18.setTransform(26.45,-10.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,5.4).curveTo(-1.5,4.6,-1.5,3.2).lineTo(-1.5,-0.9).lineTo(-3.2,-0.9).lineTo(-3.2,-3.4).lineTo(-2.7,-3.4).curveTo(-1.2,-3.4,-1.2,-5).lineTo(-1.2,-6.2).lineTo(1.4,-6.2).lineTo(1.4,-3.4).lineTo(3.2,-3.4).lineTo(3.2,-0.9).lineTo(1.4,-0.9).lineTo(1.4,2.6).curveTo(1.4,3.6,2.4,3.6).lineTo(3.2,3.5).lineTo(3.2,5.9).curveTo(2.6,6.2,1.6,6.2).curveTo(0.2,6.2,-0.7,5.4).closePath();
	this.shape_19.setTransform(14.55,-10.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3,3.9).curveTo(-3.8,3.1,-3.9,2).lineTo(-1.4,1.6).curveTo(-1.4,2.1,-1,2.5).curveTo(-0.6,2.9,0.1,2.9).curveTo(1.2,2.9,1.2,2.1).curveTo(1.2,1.5,0.2,1.3).lineTo(-0.9,1).curveTo(-3.7,0.4,-3.7,-1.9).curveTo(-3.7,-3.2,-2.6,-4.1).curveTo(-1.6,-5,-0,-5).curveTo(1.8,-5,2.8,-4).curveTo(3.6,-3.2,3.7,-2.2).lineTo(1.3,-1.8).curveTo(1.2,-2.9,-0,-2.9).curveTo(-0.4,-2.9,-0.7,-2.7).curveTo(-1,-2.5,-1,-2.1).curveTo(-1,-1.5,-0.3,-1.4).lineTo(1,-1.1).curveTo(2.4,-0.9,3.1,-0).curveTo(3.9,0.7,3.9,1.8).curveTo(3.9,3.1,2.9,4).curveTo(1.9,5,0.1,5).curveTo(-1.9,5,-3,3.9).closePath();
	this.shape_20.setTransform(6.675,-8.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3,4.8).lineTo(-3,-4.7).lineTo(-0.2,-4.7).lineTo(-0.2,-3.4).curveTo(0.4,-4.8,2.3,-4.8).lineTo(3,-4.7).lineTo(3,-1.8).lineTo(2.1,-1.9).curveTo(1.1,-1.9,0.6,-1.3).curveTo(-0.1,-0.7,-0.1,0.7).lineTo(-0.1,4.8).closePath();
	this.shape_21.setTransform(-1.1,-8.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.5,7).lineTo(-1.5,-2.5).lineTo(1.4,-2.5).lineTo(1.4,7).closePath().moveTo(-1.2,-4.1).curveTo(-1.7,-4.7,-1.7,-5.4).curveTo(-1.7,-6,-1.2,-6.5).curveTo(-0.7,-7,-0,-7).curveTo(0.7,-7,1.2,-6.5).curveTo(1.7,-6,1.7,-5.4).curveTo(1.7,-4.7,1.2,-4.1).curveTo(0.7,-3.7,-0,-3.7).curveTo(-0.7,-3.7,-1.2,-4.1).closePath();
	this.shape_22.setTransform(-8.025,-11.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.8,6.9).lineTo(-1.8,-0).lineTo(-3.2,-0).lineTo(-3.2,-2.5).lineTo(-1.8,-2.5).lineTo(-1.8,-3.3).curveTo(-1.8,-5,-0.8,-6).curveTo(0.2,-7,1.8,-7).curveTo(2.8,-7,3.3,-6.8).lineTo(3.3,-4.4).lineTo(2.4,-4.5).curveTo(1.2,-4.5,1.2,-3.2).lineTo(1.2,-2.5).lineTo(3.2,-2.5).lineTo(3.2,-0).lineTo(1.2,-0).lineTo(1.2,6.9).closePath();
	this.shape_23.setTransform(-14.15,-11.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,3.7).curveTo(-4.7,2.3,-4.7,-0).curveTo(-4.7,-2.2,-3.3,-3.7).curveTo(-1.9,-5,-0,-5).curveTo(2.2,-5,3.4,-3.7).curveTo(4.7,-2.4,4.7,-0.2).lineTo(4.6,0.7).lineTo(-1.9,0.7).curveTo(-1.9,1.5,-1.3,2).curveTo(-0.6,2.6,0.2,2.6).curveTo(1.7,2.6,2.1,1.3).lineTo(4.5,2).curveTo(4.2,3.3,3.1,4.1).curveTo(1.9,5,0.2,5).curveTo(-1.9,5,-3.3,3.7).closePath().moveTo(1.9,-1.1).curveTo(1.9,-1.8,1.5,-2.2).curveTo(1,-2.7,0,-2.7).curveTo(-0.8,-2.7,-1.4,-2.2).curveTo(-1.8,-1.7,-1.9,-1.1).lineTo(1.9,-1.1).lineTo(1.9,-1.1).closePath();
	this.shape_24.setTransform(-27.525,-8.825);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.5,6.9).lineTo(1.5,1.4).curveTo(1.5,-0.2,0,-0.2).curveTo(-0.7,-0.2,-1.1,0.2).curveTo(-1.5,0.7,-1.5,1.3).lineTo(-1.5,6.9).lineTo(-4.5,6.9).lineTo(-4.5,-6.9).lineTo(-1.5,-6.9).lineTo(-1.5,-2).curveTo(-0.7,-2.8,0.9,-2.8).curveTo(2.6,-2.8,3.6,-1.7).curveTo(4.4,-0.7,4.4,0.9).lineTo(4.4,6.9).closePath();
	this.shape_25.setTransform(-38.45,-10.975);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,5.4).curveTo(-1.5,4.6,-1.5,3.2).lineTo(-1.5,-0.9).lineTo(-3.2,-0.9).lineTo(-3.2,-3.4).lineTo(-2.7,-3.4).curveTo(-1.2,-3.4,-1.2,-5).lineTo(-1.2,-6.2).lineTo(1.4,-6.2).lineTo(1.4,-3.4).lineTo(3.2,-3.4).lineTo(3.2,-0.9).lineTo(1.4,-0.9).lineTo(1.4,2.6).curveTo(1.4,3.6,2.4,3.6).lineTo(3.2,3.5).lineTo(3.2,5.9).curveTo(2.6,6.2,1.6,6.2).curveTo(0.2,6.2,-0.7,5.4).closePath();
	this.shape_26.setTransform(-48,-10.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,3.7).curveTo(-4.7,2.3,-4.7,-0).curveTo(-4.7,-2.2,-3.3,-3.7).curveTo(-1.9,-5,-0,-5).curveTo(2.2,-5,3.4,-3.7).curveTo(4.7,-2.4,4.7,-0.2).lineTo(4.6,0.7).lineTo(-1.9,0.7).curveTo(-1.9,1.5,-1.3,2).curveTo(-0.6,2.6,0.2,2.6).curveTo(1.7,2.6,2.1,1.3).lineTo(4.5,2).curveTo(4.2,3.3,3.1,4.1).curveTo(1.9,5,0.2,5).curveTo(-1.9,5,-3.3,3.7).closePath().moveTo(1.9,-1.1).curveTo(1.9,-1.8,1.5,-2.2).curveTo(1,-2.7,0,-2.7).curveTo(-0.8,-2.7,-1.4,-2.2).curveTo(-1.8,-1.7,-1.9,-1.1).lineTo(1.9,-1.1).lineTo(1.9,-1.1).closePath();
	this.shape_27.setTransform(-61.325,-8.825);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-4.8,6.7).lineTo(-4.8,-6.7).lineTo(0.2,-6.7).curveTo(2.2,-6.7,3.3,-5.7).curveTo(4.4,-4.7,4.4,-3.1).curveTo(4.4,-2.1,3.8,-1.3).curveTo(3.3,-0.5,2.4,-0.3).curveTo(3.4,-0,4.1,0.8).curveTo(4.8,1.7,4.8,2.9).curveTo(4.8,4.6,3.7,5.6).curveTo(2.5,6.7,0.6,6.7).closePath().moveTo(-1.9,4.3).lineTo(-0,4.3).curveTo(0.9,4.3,1.4,3.8).curveTo(1.9,3.4,1.9,2.7).curveTo(1.9,2,1.4,1.6).curveTo(0.9,1.1,-0,1.1).lineTo(-1.9,1.1).closePath().moveTo(-1.9,-1.3).lineTo(-0.3,-1.3).curveTo(0.5,-1.3,1,-1.7).curveTo(1.5,-2.1,1.5,-2.8).curveTo(1.5,-4.3,-0.3,-4.3).lineTo(-1.9,-4.3).closePath();
	this.shape_28.setTransform(-72.075,-10.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-86.9,-25,173.9,50.1), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-2.7,4.3).lineTo(-2.7,-4.2).lineTo(-0.2,-4.2).lineTo(-0.2,-3).curveTo(0.4,-4.3,2,-4.3).lineTo(2.7,-4.2).lineTo(2.7,-1.6).lineTo(1.9,-1.7).curveTo(1,-1.7,0.5,-1.2).curveTo(-0.1,-0.6,-0.1,0.6).lineTo(-0.1,4.3).closePath();
	this.shape.setTransform(40.725,18.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.2,3.3).curveTo(-4,2.4,-4,1).lineTo(-4,-4.3).lineTo(-1.4,-4.3).lineTo(-1.4,0.5).curveTo(-1.4,1.1,-1.1,1.5).curveTo(-0.7,1.9,-0.1,1.9).curveTo(0.6,1.9,1,1.5).curveTo(1.3,1.1,1.3,0.5).lineTo(1.3,-4.3).lineTo(3.9,-4.3).lineTo(3.9,2.6).lineTo(4,4.1).lineTo(1.5,4.1).lineTo(1.4,3.3).curveTo(0.8,4.3,-0.8,4.3).curveTo(-2.3,4.3,-3.2,3.3).closePath();
	this.shape_1.setTransform(31.875,18.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.4,6.1).lineTo(1.4,1.3).curveTo(1.4,-0.2,-0,-0.2).curveTo(-0.6,-0.2,-1,0.2).curveTo(-1.4,0.6,-1.4,1.2).lineTo(-1.4,6.1).lineTo(-4,6.1).lineTo(-4,-6.1).lineTo(-1.4,-6.1).lineTo(-1.4,-1.8).curveTo(-0.6,-2.5,0.8,-2.5).curveTo(2.3,-2.5,3.2,-1.5).curveTo(4,-0.7,4,0.8).lineTo(4,6.1).closePath();
	this.shape_2.setTransform(21.825,16.55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.6,4.8).curveTo(-1.3,4.1,-1.3,2.8).lineTo(-1.3,-0.8).lineTo(-2.9,-0.8).lineTo(-2.9,-3.1).lineTo(-2.4,-3.1).curveTo(-1.1,-3.1,-1.2,-4.5).lineTo(-1.2,-5.5).lineTo(1.2,-5.5).lineTo(1.2,-3.1).lineTo(2.8,-3.1).lineTo(2.8,-0.8).lineTo(1.2,-0.8).lineTo(1.2,2.3).curveTo(1.2,3.2,2.1,3.2).lineTo(2.8,3.2).lineTo(2.8,5.3).curveTo(2.3,5.5,1.5,5.5).curveTo(0.2,5.5,-0.6,4.8).closePath();
	this.shape_3.setTransform(13.3,17.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-2.7,4.3).lineTo(-2.7,-4.2).lineTo(-0.2,-4.2).lineTo(-0.2,-3).curveTo(0.4,-4.3,2,-4.3).lineTo(2.7,-4.2).lineTo(2.7,-1.6).lineTo(1.9,-1.7).curveTo(1,-1.7,0.5,-1.2).curveTo(-0.1,-0.6,-0.1,0.6).lineTo(-0.1,4.3).closePath();
	this.shape_4.setTransform(7.225,18.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.1,3.7).curveTo(-3.9,3,-3.9,1.9).curveTo(-3.9,0.8,-3.2,0.1).curveTo(-2.4,-0.5,-1.4,-0.7).lineTo(0.6,-1).curveTo(1.2,-1.1,1.3,-1.5).curveTo(1.2,-1.9,0.9,-2.2).curveTo(0.5,-2.5,-0,-2.5).curveTo(-0.6,-2.5,-1.1,-2.1).curveTo(-1.4,-1.7,-1.4,-1.2).lineTo(-3.7,-1.7).curveTo(-3.6,-2.7,-2.8,-3.5).curveTo(-1.7,-4.5,-0,-4.5).curveTo(2,-4.5,2.9,-3.5).curveTo(3.8,-2.6,3.8,-1.2).lineTo(3.8,2.9).lineTo(3.9,4.2).lineTo(1.5,4.2).lineTo(1.4,3.3).curveTo(0.7,4.5,-1,4.5).curveTo(-2.3,4.5,-3.1,3.7).closePath().moveTo(-0.4,0.8).curveTo(-1.3,0.9,-1.3,1.7).curveTo(-1.3,2.6,-0.3,2.6).curveTo(1.3,2.6,1.3,0.9).lineTo(1.3,0.5).closePath();
	this.shape_5.setTransform(-1.35,18.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3,3.2).curveTo(-4.3,2,-4.3,0).curveTo(-4.3,-1.9,-3,-3.2).curveTo(-1.7,-4.5,0.2,-4.5).curveTo(1.8,-4.5,3,-3.6).curveTo(3.9,-2.8,4.2,-1.5).lineTo(1.9,-0.8).curveTo(1.6,-2.1,0.3,-2.1).curveTo(-0.6,-2.1,-1.2,-1.6).curveTo(-1.7,-1,-1.7,0).curveTo(-1.7,1,-1.1,1.6).curveTo(-0.6,2.1,0.3,2.1).curveTo(1.7,2.1,2,0.8).lineTo(4.3,1.5).curveTo(4,2.8,3,3.6).curveTo(1.8,4.5,0.3,4.5).curveTo(-1.7,4.5,-3,3.2).closePath();
	this.shape_6.setTransform(-10.55,18.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.1,3.7).curveTo(-3.8,3,-3.8,1.9).curveTo(-3.9,0.8,-3.1,0.1).curveTo(-2.5,-0.5,-1.3,-0.7).lineTo(0.6,-1).curveTo(1.3,-1.1,1.3,-1.5).curveTo(1.3,-1.9,0.9,-2.2).curveTo(0.5,-2.5,0,-2.5).curveTo(-0.7,-2.5,-1.1,-2.1).curveTo(-1.4,-1.7,-1.4,-1.2).lineTo(-3.7,-1.7).curveTo(-3.6,-2.7,-2.8,-3.5).curveTo(-1.7,-4.5,0,-4.5).curveTo(1.9,-4.5,2.9,-3.5).curveTo(3.8,-2.6,3.7,-1.2).lineTo(3.7,2.9).lineTo(3.8,4.2).lineTo(1.5,4.2).lineTo(1.5,3.3).curveTo(0.7,4.5,-1,4.5).curveTo(-2.3,4.5,-3.1,3.7).closePath().moveTo(-0.3,0.8).curveTo(-1.3,0.9,-1.3,1.7).curveTo(-1.3,2.6,-0.3,2.6).curveTo(1.2,2.6,1.3,0.9).lineTo(1.3,0.5).closePath();
	this.shape_7.setTransform(-20.1,18.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#FFFFFF").beginStroke().moveTo(4.2,6).lineTo(4.2,-2).lineTo(1.1,6).lineTo(-1.1,6).lineTo(-4.3,-1.9).lineTo(-4.3,6).lineTo(-6.8,6).lineTo(-6.8,-6).lineTo(-3.3,-6).lineTo(0,2.1).lineTo(3.1,-6).lineTo(6.8,-6).lineTo(6.8,6).closePath();
	this.shape_8.setTransform(-32.725,16.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-2.9,3.3).curveTo(-4.2,2,-4.2,-0).curveTo(-4.2,-2,-2.9,-3.3).curveTo(-1.7,-4.5,0,-4.5).curveTo(2,-4.5,3.1,-3.3).curveTo(4.2,-2.2,4.2,-0.1).lineTo(4.2,0.7).lineTo(-1.7,0.7).curveTo(-1.6,1.4,-1.1,1.8).curveTo(-0.5,2.3,0.2,2.3).curveTo(1.5,2.3,1.9,1.2).lineTo(4.1,1.8).curveTo(3.8,3,2.8,3.7).curveTo(1.7,4.5,0.2,4.5).curveTo(-1.6,4.5,-2.9,3.3).closePath().moveTo(1.7,-1).curveTo(1.7,-1.6,1.4,-2).curveTo(0.9,-2.4,0,-2.4).curveTo(-0.7,-2.4,-1.2,-2).curveTo(-1.6,-1.6,-1.6,-1).lineTo(1.7,-1).lineTo(1.7,-1).closePath();
	this.shape_9.setTransform(66.975,-0.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.4,6.2).lineTo(1.4,1.3).curveTo(1.4,-0.2,-0,-0.2).curveTo(-0.6,-0.2,-1,0.2).curveTo(-1.4,0.6,-1.4,1.2).lineTo(-1.4,6.2).lineTo(-4,6.2).lineTo(-4,-6.2).lineTo(-1.4,-6.2).lineTo(-1.4,-1.7).curveTo(-0.6,-2.5,0.8,-2.5).curveTo(2.3,-2.5,3.2,-1.6).curveTo(4,-0.6,4,0.9).lineTo(4,6.2).closePath();
	this.shape_10.setTransform(57.275,-1.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.6,4.8).curveTo(-1.4,4.1,-1.3,2.8).lineTo(-1.3,-0.8).lineTo(-2.9,-0.8).lineTo(-2.9,-3.1).lineTo(-2.5,-3.1).curveTo(-1.2,-3.1,-1.1,-4.5).lineTo(-1.1,-5.5).lineTo(1.2,-5.5).lineTo(1.2,-3.1).lineTo(2.8,-3.1).lineTo(2.8,-0.8).lineTo(1.2,-0.8).lineTo(1.2,2.3).curveTo(1.2,3.2,2.1,3.2).lineTo(2.8,3.2).lineTo(2.8,5.3).curveTo(2.3,5.5,1.5,5.5).curveTo(0.2,5.5,-0.6,4.8).closePath();
	this.shape_11.setTransform(48.75,-1.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.4,4.3).lineTo(1.4,-0.5).curveTo(1.4,-2,-0,-2).curveTo(-0.6,-2,-1,-1.6).curveTo(-1.4,-1.2,-1.4,-0.5).lineTo(-1.4,4.3).lineTo(-4,4.3).lineTo(-4,-4.1).lineTo(-1.5,-4.1).lineTo(-1.5,-3.2).curveTo(-1.2,-3.7,-0.5,-4.1).curveTo(0.2,-4.3,0.9,-4.3).curveTo(2.4,-4.3,3.2,-3.4).curveTo(4,-2.5,4,-1).lineTo(4,4.3).closePath();
	this.shape_12.setTransform(36.575,-0.125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.3,6.3).lineTo(-1.3,-2.2).lineTo(1.3,-2.2).lineTo(1.3,6.3).closePath().moveTo(-1.1,-3.7).curveTo(-1.5,-4.1,-1.5,-4.8).curveTo(-1.5,-5.4,-1.1,-5.8).curveTo(-0.6,-6.3,-0,-6.3).curveTo(0.6,-6.3,1.1,-5.8).curveTo(1.5,-5.4,1.5,-4.8).curveTo(1.5,-4.1,1.1,-3.7).curveTo(0.6,-3.2,-0,-3.2).curveTo(-0.6,-3.2,-1.1,-3.7).closePath();
	this.shape_13.setTransform(29.075,-2.075);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.1,5.9).lineTo(-1.2,1.5).lineTo(-4.8,-5.8).lineTo(-1.9,-5.8).lineTo(0.2,-1.3).lineTo(2,-5.8).lineTo(4.8,-5.8).lineTo(-0.4,5.9).closePath();
	this.shape_14.setTransform(17.575,1.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.6,4.8).curveTo(-1.4,4.1,-1.4,2.8).lineTo(-1.4,-0.8).lineTo(-2.8,-0.8).lineTo(-2.8,-3.1).lineTo(-2.5,-3.1).curveTo(-1.1,-3.1,-1.1,-4.5).lineTo(-1.1,-5.5).lineTo(1.2,-5.5).lineTo(1.2,-3.1).lineTo(2.8,-3.1).lineTo(2.8,-0.8).lineTo(1.2,-0.8).lineTo(1.2,2.3).curveTo(1.2,3.2,2.1,3.2).lineTo(2.8,3.2).lineTo(2.8,5.3).curveTo(2.3,5.5,1.4,5.5).curveTo(0.1,5.5,-0.6,4.8).closePath();
	this.shape_15.setTransform(9.3,-1.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.3,6.3).lineTo(-1.3,-2.2).lineTo(1.3,-2.2).lineTo(1.3,6.3).closePath().moveTo(-1.1,-3.7).curveTo(-1.5,-4.1,-1.5,-4.8).curveTo(-1.5,-5.4,-1.1,-5.8).curveTo(-0.6,-6.3,-0,-6.3).curveTo(0.6,-6.3,1.1,-5.8).curveTo(1.5,-5.4,1.5,-4.8).curveTo(1.5,-4.1,1.1,-3.7).curveTo(0.6,-3.2,-0,-3.2).curveTo(-0.6,-3.2,-1.1,-3.7).closePath();
	this.shape_16.setTransform(3.875,-2.075);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.4,4.3).lineTo(1.4,-0.5).curveTo(1.4,-2,-0,-2).curveTo(-0.6,-2,-1,-1.6).curveTo(-1.4,-1.2,-1.4,-0.5).lineTo(-1.4,4.3).lineTo(-4,4.3).lineTo(-4,-4.1).lineTo(-1.5,-4.1).lineTo(-1.5,-3.2).curveTo(-1.2,-3.7,-0.5,-4.1).curveTo(0.2,-4.3,0.9,-4.3).curveTo(2.4,-4.3,3.2,-3.4).curveTo(4,-2.5,4,-1).lineTo(4,4.3).closePath();
	this.shape_17.setTransform(-3.525,-0.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.2,3.3).curveTo(-4,2.4,-4,1).lineTo(-4,-4.3).lineTo(-1.4,-4.3).lineTo(-1.4,0.5).curveTo(-1.4,1.1,-1.1,1.5).curveTo(-0.7,1.9,-0.1,1.9).curveTo(0.6,1.9,1,1.5).curveTo(1.3,1.1,1.3,0.5).lineTo(1.3,-4.3).lineTo(3.9,-4.3).lineTo(3.9,2.6).lineTo(4,4.1).lineTo(1.5,4.1).lineTo(1.4,3.3).curveTo(0.8,4.3,-0.8,4.3).curveTo(-2.3,4.3,-3.2,3.3).closePath();
	this.shape_18.setTransform(-13.675,0.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginFill("#FFFFFF").beginStroke().moveTo(4.1,4.4).lineTo(4.1,-0.6).curveTo(4.1,-2,2.7,-2).curveTo(2.1,-2,1.7,-1.6).curveTo(1.3,-1.2,1.3,-0.6).lineTo(1.3,4.4).lineTo(-1.3,4.4).lineTo(-1.3,-0.6).curveTo(-1.3,-2,-2.6,-2).curveTo(-3.3,-2,-3.6,-1.6).curveTo(-4,-1.1,-4,-0.5).lineTo(-4,4.4).lineTo(-6.6,4.4).lineTo(-6.6,-4.1).lineTo(-4.1,-4.1).lineTo(-4.1,-3.2).curveTo(-3.8,-3.7,-3.1,-4.1).curveTo(-2.4,-4.4,-1.7,-4.4).curveTo(0.1,-4.4,0.8,-3.1).curveTo(1.7,-4.4,3.4,-4.4).curveTo(4.7,-4.3,5.6,-3.6).curveTo(6.6,-2.7,6.6,-1.1).lineTo(6.6,4.4).closePath();
	this.shape_19.setTransform(-26.325,-0.15);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginFill("#FFFFFF").beginStroke().moveTo(4.1,4.4).lineTo(4.1,-0.6).curveTo(4.1,-2,2.7,-2).curveTo(2.1,-2,1.7,-1.6).curveTo(1.3,-1.2,1.3,-0.6).lineTo(1.3,4.4).lineTo(-1.3,4.4).lineTo(-1.3,-0.6).curveTo(-1.3,-2,-2.6,-2).curveTo(-3.3,-2,-3.6,-1.6).curveTo(-4,-1.1,-4,-0.5).lineTo(-4,4.4).lineTo(-6.6,4.4).lineTo(-6.6,-4.1).lineTo(-4.1,-4.1).lineTo(-4.1,-3.2).curveTo(-3.8,-3.7,-3.1,-4.1).curveTo(-2.4,-4.4,-1.7,-4.4).curveTo(0.1,-4.4,0.8,-3.1).curveTo(1.7,-4.4,3.4,-4.4).curveTo(4.7,-4.3,5.6,-3.6).curveTo(6.6,-2.7,6.6,-1.1).lineTo(6.6,4.4).closePath();
	this.shape_20.setTransform(-41.625,-0.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.2,3.2).curveTo(-4.5,1.9,-4.5,-0).curveTo(-4.5,-2,-3.2,-3.2).curveTo(-1.9,-4.5,-0,-4.5).curveTo(2,-4.5,3.2,-3.2).curveTo(4.5,-2,4.5,-0).curveTo(4.5,1.9,3.2,3.2).curveTo(2,4.5,-0,4.5).curveTo(-1.9,4.5,-3.2,3.2).closePath().moveTo(-1.3,-1.6).curveTo(-1.9,-1,-1.9,-0).curveTo(-1.9,1,-1.3,1.6).curveTo(-0.7,2.1,-0,2.1).curveTo(0.8,2.1,1.3,1.6).curveTo(1.9,1,1.9,-0).curveTo(1.9,-1,1.3,-1.6).curveTo(0.8,-2.1,-0,-2.1).curveTo(-0.7,-2.1,-1.3,-1.6).closePath();
	this.shape_21.setTransform(-54.35,-0.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-2.9,3.2).curveTo(-4.3,2,-4.3,0).curveTo(-4.3,-1.9,-2.9,-3.2).curveTo(-1.7,-4.5,0.2,-4.5).curveTo(1.8,-4.5,2.9,-3.6).curveTo(3.9,-2.8,4.3,-1.5).lineTo(1.9,-0.8).curveTo(1.6,-2.1,0.2,-2.1).curveTo(-0.6,-2.1,-1.1,-1.6).curveTo(-1.7,-1,-1.7,0).curveTo(-1.7,1,-1.1,1.6).curveTo(-0.5,2.1,0.2,2.1).curveTo(1.6,2.1,2,0.8).lineTo(4.3,1.5).curveTo(4,2.8,3,3.6).curveTo(1.8,4.5,0.2,4.5).curveTo(-1.6,4.5,-2.9,3.2).closePath();
	this.shape_22.setTransform(-64.05,-0.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-4.5,5.9).lineTo(-4.5,-5.8).lineTo(-1.9,-5.8).lineTo(-1.9,-4.9).curveTo(-1.7,-5.4,-1,-5.6).curveTo(-0.4,-5.9,0.5,-6).curveTo(2.3,-6,3.4,-4.7).curveTo(4.4,-3.5,4.4,-1.5).curveTo(4.4,0.4,3.3,1.6).curveTo(2.2,2.9,0.4,2.9).curveTo(-1.2,2.9,-1.8,2.1).lineTo(-1.8,5.9).closePath().moveTo(-1.3,-3.1).curveTo(-1.9,-2.6,-1.9,-1.5).curveTo(-1.9,-0.6,-1.3,0.1).curveTo(-0.8,0.6,0,0.6).curveTo(0.8,0.6,1.4,0.1).curveTo(1.9,-0.5,1.9,-1.5).curveTo(1.9,-2.6,1.4,-3.1).curveTo(0.8,-3.7,0,-3.6).curveTo(-0.8,-3.7,-1.3,-3.1).closePath();
	this.shape_23.setTransform(55.85,-17);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.3,6.3).lineTo(-1.3,-2.2).lineTo(1.3,-2.2).lineTo(1.3,6.3).closePath().moveTo(-1.1,-3.7).curveTo(-1.5,-4.1,-1.5,-4.8).curveTo(-1.5,-5.4,-1.1,-5.8).curveTo(-0.6,-6.3,-0,-6.3).curveTo(0.6,-6.3,1.1,-5.8).curveTo(1.5,-5.4,1.5,-4.8).curveTo(1.5,-4.1,1.1,-3.7).curveTo(0.6,-3.2,-0,-3.2).curveTo(-0.6,-3.2,-1.1,-3.7).closePath();
	this.shape_24.setTransform(47.875,-20.575);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.4,6.1).lineTo(1.4,1.3).curveTo(1.4,-0.2,-0,-0.2).curveTo(-0.6,-0.2,-1,0.2).curveTo(-1.4,0.6,-1.4,1.2).lineTo(-1.4,6.1).lineTo(-4,6.1).lineTo(-4,-6.2).lineTo(-1.4,-6.2).lineTo(-1.4,-1.8).curveTo(-0.6,-2.5,0.8,-2.5).curveTo(2.3,-2.5,3.2,-1.5).curveTo(4,-0.7,4,0.8).lineTo(4,6.1).closePath();
	this.shape_25.setTransform(40.475,-20.45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-2.7,3.5).curveTo(-3.4,2.8,-3.5,1.8).lineTo(-1.3,1.4).curveTo(-1.3,1.9,-0.9,2.2).curveTo(-0.6,2.6,0,2.6).curveTo(1,2.6,1,1.8).curveTo(1,1.3,0.2,1.1).lineTo(-0.8,0.9).curveTo(-3.3,0.4,-3.3,-1.7).curveTo(-3.3,-2.8,-2.4,-3.7).curveTo(-1.5,-4.5,-0,-4.5).curveTo(1.6,-4.5,2.5,-3.6).curveTo(3.3,-2.9,3.3,-2).lineTo(1.2,-1.6).curveTo(1.1,-2.6,-0,-2.6).curveTo(-0.4,-2.6,-0.7,-2.4).curveTo(-0.9,-2.2,-0.9,-1.9).curveTo(-0.9,-1.4,-0.3,-1.2).lineTo(0.8,-1).curveTo(2.1,-0.8,2.8,-0).curveTo(3.5,0.7,3.5,1.6).curveTo(3.5,2.8,2.6,3.6).curveTo(1.7,4.5,0.1,4.5).curveTo(-1.7,4.5,-2.7,3.5).closePath();
	this.shape_26.setTransform(31.375,-18.525);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.1,5.1).curveTo(-4.2,4.3,-4.4,3).lineTo(-2.1,2.4).curveTo(-2,3,-1.5,3.4).curveTo(-1,3.8,-0.3,3.8).curveTo(1.8,3.8,1.8,1.6).lineTo(1.8,1.3).curveTo(1.2,2.2,-0.5,2.2).curveTo(-2.1,2.2,-3.3,1).curveTo(-4.4,-0.2,-4.4,-1.9).curveTo(-4.4,-3.7,-3.3,-4.8).curveTo(-2.2,-6,-0.5,-6).curveTo(1.3,-6.1,1.9,-5).lineTo(1.9,-5.9).lineTo(4.4,-5.9).lineTo(4.4,1.5).curveTo(4.4,3.5,3.3,4.7).curveTo(2.1,6,-0.2,6).curveTo(-1.9,6,-3.1,5.1).closePath().moveTo(-1.2,-3.3).curveTo(-1.8,-2.7,-1.8,-1.9).curveTo(-1.8,-1.1,-1.3,-0.5).curveTo(-0.8,-0.1,0,-0.1).curveTo(0.8,-0.1,1.3,-0.5).curveTo(1.8,-1.1,1.8,-1.9).curveTo(1.8,-2.7,1.3,-3.3).curveTo(0.8,-3.8,0,-3.8).curveTo(-0.7,-3.8,-1.2,-3.3).closePath();
	this.shape_27.setTransform(22.075,-16.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.1,3.7).curveTo(-3.8,3,-3.8,1.9).curveTo(-3.9,0.8,-3.1,0.1).curveTo(-2.5,-0.5,-1.3,-0.7).lineTo(0.6,-1).curveTo(1.3,-1.1,1.3,-1.5).curveTo(1.3,-1.9,0.9,-2.2).curveTo(0.6,-2.5,0,-2.5).curveTo(-0.7,-2.5,-1.1,-2.1).curveTo(-1.4,-1.7,-1.4,-1.2).lineTo(-3.7,-1.7).curveTo(-3.6,-2.7,-2.8,-3.5).curveTo(-1.7,-4.5,0,-4.5).curveTo(1.9,-4.5,2.9,-3.5).curveTo(3.8,-2.6,3.7,-1.2).lineTo(3.7,2.9).lineTo(3.9,4.2).lineTo(1.5,4.2).lineTo(1.5,3.3).curveTo(0.7,4.5,-1,4.5).curveTo(-2.3,4.5,-3.1,3.7).closePath().moveTo(-0.3,0.8).curveTo(-1.3,0.9,-1.3,1.7).curveTo(-1.3,2.6,-0.3,2.6).curveTo(1.3,2.6,1.3,0.9).lineTo(1.3,0.5).closePath();
	this.shape_28.setTransform(12.4,-18.525);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.3,6.1).lineTo(-1.3,-6.2).lineTo(1.3,-6.2).lineTo(1.3,6.1).closePath();
	this.shape_29.setTransform(5.5,-20.45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.5,6.2).lineTo(-1.5,-0.1).lineTo(-2.9,-0.1).lineTo(-2.9,-2.2).lineTo(-1.5,-2.2).lineTo(-1.5,-3).curveTo(-1.6,-4.4,-0.7,-5.3).curveTo(0.1,-6.2,1.6,-6.2).curveTo(2.5,-6.2,2.9,-6).lineTo(2.9,-3.9).lineTo(2.1,-4).curveTo(1,-4,1,-2.9).lineTo(1,-2.2).lineTo(2.9,-2.2).lineTo(2.9,-0.1).lineTo(1,-0.1).lineTo(1,6.2).closePath();
	this.shape_30.setTransform(0,-20.525);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.8,4.2).lineTo(-0,-1.2).lineTo(-1.8,4.2).lineTo(-4.4,4.2).lineTo(-7.1,-4.2).lineTo(-4.4,-4.2).lineTo(-2.9,0.8).lineTo(-1.3,-4.2).lineTo(1.5,-4.2).lineTo(3.1,0.8).lineTo(4.5,-4.2).lineTo(7.1,-4.2).lineTo(4.4,4.2).closePath();
	this.shape_31.setTransform(-14.45,-18.525);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-2.9,3.3).curveTo(-4.2,2,-4.2,-0).curveTo(-4.2,-2,-2.9,-3.3).curveTo(-1.7,-4.5,0,-4.5).curveTo(2,-4.5,3.1,-3.3).curveTo(4.2,-2.2,4.2,-0.1).lineTo(4.2,0.7).lineTo(-1.7,0.7).curveTo(-1.6,1.4,-1.1,1.8).curveTo(-0.5,2.3,0.2,2.3).curveTo(1.5,2.3,1.9,1.2).lineTo(4.1,1.8).curveTo(3.8,3,2.8,3.7).curveTo(1.7,4.5,0.2,4.5).curveTo(-1.6,4.5,-2.9,3.3).closePath().moveTo(1.7,-1).curveTo(1.7,-1.6,1.4,-2).curveTo(0.9,-2.4,0,-2.4).curveTo(-0.7,-2.4,-1.2,-2).curveTo(-1.6,-1.6,-1.6,-1).lineTo(1.7,-1).lineTo(1.7,-1).closePath();
	this.shape_32.setTransform(-26.475,-18.525);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.4,4.3).lineTo(1.4,-0.5).curveTo(1.4,-2,-0,-2).curveTo(-0.6,-2,-1,-1.6).curveTo(-1.4,-1.2,-1.4,-0.5).lineTo(-1.4,4.3).lineTo(-4,4.3).lineTo(-4,-4.1).lineTo(-1.5,-4.1).lineTo(-1.5,-3.2).curveTo(-1.2,-3.7,-0.5,-4.1).curveTo(0.2,-4.3,0.9,-4.3).curveTo(2.4,-4.3,3.2,-3.4).curveTo(4,-2.5,4,-1).lineTo(4,4.3).closePath();
	this.shape_33.setTransform(-36.175,-18.625);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.beginFill("#FFFFFF").beginStroke().moveTo(3.2,6).lineTo(2.3,3.6).lineTo(-2.4,3.6).lineTo(-3.2,6).lineTo(-6.1,6).lineTo(-1.5,-6).lineTo(1.6,-6).lineTo(6.1,6).closePath().moveTo(1.4,1.1).lineTo(0,-3).lineTo(-1.5,1.1).lineTo(1.4,1.1).closePath();
	this.shape_34.setTransform(-51.675,-20.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-73.2,-33.2,149.4,62.5), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.5,6.6).lineTo(-1.4,1.7).lineTo(-5.3,-6.6).lineTo(-2.1,-6.6).lineTo(0.2,-1.5).lineTo(2.3,-6.6).lineTo(5.4,-6.6).lineTo(-0.5,6.6).closePath();
	this.shape.setTransform(66,15.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.4,6.9).lineTo(-1.4,-6.9).lineTo(1.5,-6.9).lineTo(1.5,6.9).closePath();
	this.shape_1.setTransform(57.85,11.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.4,6.9).lineTo(-1.4,-6.9).lineTo(1.5,-6.9).lineTo(1.5,6.9).closePath();
	this.shape_2.setTransform(52.45,11.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.5,4.2).curveTo(-4.3,3.3,-4.3,2.2).curveTo(-4.3,0.9,-3.5,0.2).curveTo(-2.8,-0.5,-1.5,-0.7).lineTo(0.7,-1.1).curveTo(1.4,-1.2,1.4,-1.7).curveTo(1.4,-2.1,1,-2.4).curveTo(0.6,-2.7,-0,-2.7).curveTo(-0.7,-2.7,-1.2,-2.3).curveTo(-1.6,-1.9,-1.6,-1.3).lineTo(-4.1,-1.9).curveTo(-4,-3,-3.1,-3.9).curveTo(-1.9,-5,0,-5).curveTo(2.2,-5,3.3,-3.9).curveTo(4.2,-3,4.2,-1.3).lineTo(4.2,3.3).curveTo(4.2,4.2,4.3,4.7).lineTo(1.7,4.7).lineTo(1.6,3.7).curveTo(0.8,5,-1.1,5).curveTo(-2.5,5,-3.5,4.2).closePath().moveTo(-0.4,0.9).curveTo(-1.5,1.1,-1.5,1.9).curveTo(-1.5,2.9,-0.3,2.9).curveTo(1.4,2.9,1.4,1).lineTo(1.4,0.7).closePath();
	this.shape_3.setTransform(44.425,13.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3,4.8).lineTo(-3,-4.7).lineTo(-0.2,-4.7).lineTo(-0.2,-3.4).curveTo(0.4,-4.8,2.2,-4.8).lineTo(3,-4.7).lineTo(3,-1.8).lineTo(2.1,-1.9).curveTo(1.2,-1.9,0.5,-1.3).curveTo(-0.1,-0.7,-0.1,0.7).lineTo(-0.1,4.8).closePath();
	this.shape_4.setTransform(36,13.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,3.7).curveTo(-4.5,2.7,-4.5,1.1).lineTo(-4.5,-4.8).lineTo(-1.6,-4.8).lineTo(-1.6,0.5).curveTo(-1.6,1.3,-1.2,1.7).curveTo(-0.8,2.2,-0.1,2.2).curveTo(0.6,2.2,1.1,1.7).curveTo(1.5,1.3,1.5,0.6).lineTo(1.5,-4.8).lineTo(4.4,-4.8).lineTo(4.4,2.9).lineTo(4.5,4.6).lineTo(1.7,4.6).lineTo(1.6,3.7).curveTo(0.9,4.8,-0.9,4.8).curveTo(-2.6,4.8,-3.6,3.7).closePath();
	this.shape_5.setTransform(26.125,13.325);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,5.4).curveTo(-1.5,4.6,-1.5,3.2).lineTo(-1.5,-0.9).lineTo(-3.2,-0.9).lineTo(-3.2,-3.4).lineTo(-2.7,-3.4).curveTo(-1.2,-3.4,-1.2,-5).lineTo(-1.2,-6.2).lineTo(1.3,-6.2).lineTo(1.3,-3.4).lineTo(3.2,-3.4).lineTo(3.2,-0.9).lineTo(1.3,-0.9).lineTo(1.3,2.6).curveTo(1.3,3.6,2.4,3.6).lineTo(3.1,3.5).lineTo(3.1,5.9).curveTo(2.6,6.2,1.7,6.2).curveTo(0.2,6.2,-0.7,5.4).closePath();
	this.shape_6.setTransform(16.6,11.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.5,4.2).curveTo(-4.3,3.3,-4.3,2.2).curveTo(-4.3,0.9,-3.5,0.2).curveTo(-2.8,-0.5,-1.5,-0.7).lineTo(0.7,-1.1).curveTo(1.4,-1.2,1.4,-1.7).curveTo(1.4,-2.1,1,-2.4).curveTo(0.6,-2.7,-0,-2.7).curveTo(-0.7,-2.7,-1.2,-2.3).curveTo(-1.6,-1.9,-1.6,-1.3).lineTo(-4.1,-1.9).curveTo(-4,-3,-3.1,-3.9).curveTo(-1.9,-5,0,-5).curveTo(2.2,-5,3.3,-3.9).curveTo(4.2,-3,4.2,-1.3).lineTo(4.2,3.3).curveTo(4.2,4.2,4.3,4.7).lineTo(1.7,4.7).lineTo(1.6,3.7).curveTo(0.8,5,-1.1,5).curveTo(-2.5,5,-3.5,4.2).closePath().moveTo(-0.4,0.9).curveTo(-1.5,1.1,-1.5,1.9).curveTo(-1.5,2.9,-0.3,2.9).curveTo(1.4,2.9,1.4,1).lineTo(1.4,0.7).closePath();
	this.shape_7.setTransform(7.875,13.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.6,4.8).lineTo(1.6,-0.6).curveTo(1.6,-2.2,-0,-2.2).curveTo(-0.7,-2.2,-1.1,-1.8).curveTo(-1.5,-1.3,-1.6,-0.6).lineTo(-1.6,4.8).lineTo(-4.5,4.8).lineTo(-4.5,-4.6).lineTo(-1.7,-4.6).lineTo(-1.7,-3.5).curveTo(-1.3,-4.2,-0.5,-4.5).curveTo(0.2,-4.9,1,-4.8).curveTo(2.7,-4.8,3.6,-3.7).curveTo(4.5,-2.7,4.5,-1.1).lineTo(4.5,4.8).closePath();
	this.shape_8.setTransform(-2.75,13.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3,3.9).curveTo(-3.8,3.1,-3.9,2).lineTo(-1.4,1.6).curveTo(-1.4,2.1,-1,2.5).curveTo(-0.6,2.9,0.1,2.9).curveTo(1.2,2.9,1.2,2.1).curveTo(1.2,1.5,0.2,1.3).lineTo(-0.9,1).curveTo(-3.7,0.4,-3.7,-1.9).curveTo(-3.7,-3.2,-2.6,-4.1).curveTo(-1.6,-5,-0,-5).curveTo(1.8,-5,2.8,-4).curveTo(3.6,-3.2,3.7,-2.2).lineTo(1.3,-1.8).curveTo(1.2,-2.9,-0,-2.9).curveTo(-0.4,-2.9,-0.7,-2.7).curveTo(-1,-2.5,-1,-2.1).curveTo(-1,-1.5,-0.3,-1.4).lineTo(1,-1.1).curveTo(2.4,-0.9,3.1,-0).curveTo(3.9,0.7,3.9,1.8).curveTo(3.9,3.1,2.9,4).curveTo(1.9,5,0.1,5).curveTo(-1.9,5,-3,3.9).closePath();
	this.shape_9.setTransform(-17.575,13.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,3.7).curveTo(-4.7,2.3,-4.7,-0).curveTo(-4.7,-2.2,-3.3,-3.7).curveTo(-1.9,-5,-0,-5).curveTo(2.2,-5,3.4,-3.7).curveTo(4.7,-2.4,4.7,-0.2).lineTo(4.6,0.7).lineTo(-1.9,0.7).curveTo(-1.9,1.5,-1.3,2).curveTo(-0.6,2.6,0.2,2.6).curveTo(1.7,2.6,2.1,1.3).lineTo(4.5,2).curveTo(4.2,3.3,3.1,4.1).curveTo(1.9,5,0.2,5).curveTo(-1.9,5,-3.3,3.7).closePath().moveTo(1.9,-1.1).curveTo(1.9,-1.8,1.5,-2.2).curveTo(1,-2.7,0,-2.7).curveTo(-0.8,-2.7,-1.4,-2.2).curveTo(-1.8,-1.7,-1.9,-1.1).lineTo(1.9,-1.1).lineTo(1.9,-1.1).closePath();
	this.shape_10.setTransform(-27.225,13.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#FFFFFF").beginStroke().moveTo(4.5,4.9).lineTo(4.5,-0.6).curveTo(4.5,-2.2,3.1,-2.2).curveTo(2.3,-2.2,1.9,-1.7).curveTo(1.5,-1.2,1.5,-0.6).lineTo(1.5,4.9).lineTo(-1.3,4.9).lineTo(-1.3,-0.6).curveTo(-1.3,-2.2,-2.9,-2.2).curveTo(-3.6,-2.2,-4,-1.7).curveTo(-4.4,-1.2,-4.5,-0.6).lineTo(-4.5,4.9).lineTo(-7.4,4.9).lineTo(-7.4,-4.6).lineTo(-4.6,-4.6).lineTo(-4.6,-3.5).curveTo(-4.2,-4.1,-3.4,-4.5).curveTo(-2.6,-4.9,-1.9,-4.9).curveTo(0.2,-4.9,0.9,-3.4).curveTo(1.9,-4.9,3.9,-4.9).curveTo(5.3,-4.9,6.3,-4).curveTo(7.4,-3,7.4,-1.2).lineTo(7.4,4.9).closePath();
	this.shape_11.setTransform(-41.05,13.075);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.5,3.6).curveTo(-5,2.2,-5,-0).curveTo(-5,-2.2,-3.5,-3.6).curveTo(-2.1,-5,-0,-5).curveTo(2.2,-5,3.6,-3.6).curveTo(5,-2.2,5,-0).curveTo(5,2.2,3.6,3.6).curveTo(2.2,5,-0,5).curveTo(-2.1,5,-3.5,3.6).closePath().moveTo(-1.5,-1.8).curveTo(-2.1,-1.1,-2.1,-0).curveTo(-2.1,1.1,-1.5,1.8).curveTo(-0.9,2.4,-0,2.4).curveTo(0.9,2.4,1.5,1.8).curveTo(2.1,1.1,2.1,-0).curveTo(2.1,-1.1,1.5,-1.8).curveTo(0.9,-2.3,-0,-2.3).curveTo(-0.9,-2.3,-1.5,-1.8).closePath();
	this.shape_12.setTransform(-55.25,13.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,3.6).curveTo(-4.8,2.2,-4.8,0).curveTo(-4.8,-2.2,-3.3,-3.6).curveTo(-1.9,-5,0.2,-5).curveTo(2,-5,3.3,-4).curveTo(4.4,-3.1,4.7,-1.7).lineTo(2.1,-0.9).curveTo(1.7,-2.3,0.2,-2.3).curveTo(-0.7,-2.3,-1.3,-1.7).curveTo(-1.9,-1.1,-1.9,0).curveTo(-1.9,1.1,-1.3,1.7).curveTo(-0.7,2.4,0.3,2.4).curveTo(1.8,2.4,2.2,0.9).lineTo(4.8,1.7).curveTo(4.4,3.1,3.3,4).curveTo(2.1,5,0.3,5).curveTo(-1.8,5,-3.3,3.6).closePath();
	this.shape_13.setTransform(-66.125,13.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,3.7).curveTo(-4.7,2.3,-4.7,-0).curveTo(-4.7,-2.2,-3.3,-3.7).curveTo(-1.9,-5,-0,-5).curveTo(2.2,-5,3.4,-3.7).curveTo(4.7,-2.4,4.7,-0.2).lineTo(4.6,0.7).lineTo(-1.9,0.7).curveTo(-1.9,1.5,-1.3,2).curveTo(-0.6,2.6,0.2,2.6).curveTo(1.7,2.6,2.1,1.3).lineTo(4.5,2).curveTo(4.2,3.3,3.1,4.1).curveTo(1.9,5,0.2,5).curveTo(-1.9,5,-3.3,3.7).closePath().moveTo(1.9,-1.1).curveTo(1.9,-1.8,1.5,-2.2).curveTo(1,-2.7,0,-2.7).curveTo(-0.8,-2.7,-1.4,-2.2).curveTo(-1.8,-1.7,-1.9,-1.1).lineTo(1.9,-1.1).lineTo(1.9,-1.1).closePath();
	this.shape_14.setTransform(41.075,-8.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.7,6.9).lineTo(-1.7,-0).lineTo(-3.3,-0).lineTo(-3.3,-2.5).lineTo(-1.7,-2.5).lineTo(-1.7,-3.3).curveTo(-1.8,-5,-0.8,-6).curveTo(0.2,-7,1.9,-7).curveTo(2.8,-7,3.3,-6.8).lineTo(3.3,-4.4).lineTo(2.4,-4.5).curveTo(1.1,-4.5,1.1,-3.2).lineTo(1.1,-2.5).lineTo(3.2,-2.5).lineTo(3.2,-0).lineTo(1.1,-0).lineTo(1.1,6.9).closePath();
	this.shape_15.setTransform(32.35,-11.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.5,7).lineTo(-1.5,-2.5).lineTo(1.4,-2.5).lineTo(1.4,7).closePath().moveTo(-1.2,-4.1).curveTo(-1.7,-4.7,-1.7,-5.4).curveTo(-1.7,-6,-1.2,-6.5).curveTo(-0.7,-7,-0,-7).curveTo(0.7,-7,1.2,-6.5).curveTo(1.7,-6,1.7,-5.4).curveTo(1.7,-4.7,1.2,-4.1).curveTo(0.7,-3.7,-0,-3.7).curveTo(-0.7,-3.7,-1.2,-4.1).closePath();
	this.shape_16.setTransform(26.225,-11.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.4,6.9).lineTo(-1.4,-6.9).lineTo(1.4,-6.9).lineTo(1.4,6.9).closePath();
	this.shape_17.setTransform(20.8,-10.975);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,3.7).curveTo(-4.7,2.3,-4.7,-0).curveTo(-4.7,-2.2,-3.3,-3.7).curveTo(-1.9,-5,-0,-5).curveTo(2.2,-5,3.4,-3.7).curveTo(4.7,-2.4,4.7,-0.2).lineTo(4.6,0.7).lineTo(-1.9,0.7).curveTo(-1.9,1.5,-1.3,2).curveTo(-0.6,2.6,0.2,2.6).curveTo(1.7,2.6,2.1,1.3).lineTo(4.5,2).curveTo(4.2,3.3,3.1,4.1).curveTo(1.9,5,0.2,5).curveTo(-1.9,5,-3.3,3.7).closePath().moveTo(1.9,-1.1).curveTo(1.9,-1.8,1.5,-2.2).curveTo(1,-2.7,0,-2.7).curveTo(-0.8,-2.7,-1.4,-2.2).curveTo(-1.8,-1.7,-1.9,-1.1).lineTo(1.9,-1.1).lineTo(1.9,-1.1).closePath();
	this.shape_18.setTransform(8.175,-8.825);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3,4.8).lineTo(-3,-4.7).lineTo(-0.2,-4.7).lineTo(-0.2,-3.4).curveTo(0.5,-4.8,2.3,-4.8).lineTo(3,-4.7).lineTo(3,-1.8).lineTo(2.1,-1.9).curveTo(1.2,-1.9,0.5,-1.3).curveTo(-0.1,-0.7,-0.1,0.7).lineTo(-0.1,4.8).closePath();
	this.shape_19.setTransform(-0.55,-8.875);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,3.7).curveTo(-4.7,2.3,-4.7,-0).curveTo(-4.7,-2.2,-3.3,-3.7).curveTo(-1.9,-5,-0,-5).curveTo(2.2,-5,3.4,-3.7).curveTo(4.7,-2.4,4.7,-0.2).lineTo(4.6,0.7).lineTo(-1.9,0.7).curveTo(-1.9,1.5,-1.3,2).curveTo(-0.6,2.6,0.2,2.6).curveTo(1.7,2.6,2.1,1.3).lineTo(4.5,2).curveTo(4.2,3.3,3.1,4.1).curveTo(1.9,5,0.2,5).curveTo(-1.9,5,-3.3,3.7).closePath().moveTo(1.9,-1.1).curveTo(1.9,-1.8,1.5,-2.2).curveTo(1,-2.7,0,-2.7).curveTo(-0.8,-2.7,-1.4,-2.2).curveTo(-1.8,-1.7,-1.9,-1.1).lineTo(1.9,-1.1).lineTo(1.9,-1.1).closePath();
	this.shape_20.setTransform(-10.075,-8.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.6,6.9).lineTo(1.6,1.4).curveTo(1.6,-0.2,0,-0.2).curveTo(-0.6,-0.2,-1.1,0.2).curveTo(-1.5,0.7,-1.6,1.3).lineTo(-1.6,6.9).lineTo(-4.5,6.9).lineTo(-4.5,-6.9).lineTo(-1.6,-6.9).lineTo(-1.6,-2).curveTo(-0.7,-2.8,0.9,-2.8).curveTo(2.6,-2.8,3.6,-1.7).curveTo(4.4,-0.7,4.4,0.9).lineTo(4.4,6.9).closePath();
	this.shape_21.setTransform(-21,-10.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill("#FFFFFF").beginStroke().moveTo(2.9,6.7).lineTo(0,-2.2).lineTo(-2.8,6.7).lineTo(-6,6.7).lineTo(-9.7,-6.7).lineTo(-6.5,-6.7).lineTo(-4.3,1.9).lineTo(-1.5,-6.7).lineTo(1.6,-6.7).lineTo(4.4,1.9).lineTo(6.6,-6.7).lineTo(9.7,-6.7).lineTo(6,6.7).closePath();
	this.shape_22.setTransform(-36.525,-10.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-78.6,-25,157.2,50.1), null);


(lib.planebyitself = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(9).moveTo(-104.3,-6.2).lineTo(-117.7,-14.3).curveTo(-133.5,-24,-141.1,-29.4).curveTo(-143.9,-31.4,-144.4,-33.4).curveTo(-143.5,-34.1,-143.3,-34.3).curveTo(-142.6,-34.7,-141.9,-34.7).curveTo(-121.1,-36,-95.6,-38.2).curveTo(-44.6,-42.4,-21,-46).curveTo(-0.5,-49.2,121.9,-64.1).curveTo(126.3,-64.6,126.4,-64.6).curveTo(129,-64.5,130.6,-62.7).curveTo(124.3,-60.6,104.2,-55.8).curveTo(80.3,-50,77.6,-49.3).lineTo(-26.3,-21.4).curveTo(-48.3,-15.6,-53,-14.3).curveTo(-62.8,-11.6,-67.7,-10.2).curveTo(-76.3,-7.7,-82.3,-5.6).curveTo(-86.2,-4.4,-88.2,-3.5).curveTo(-91.8,-1.7,-92.8,1.6).curveTo(-93.8,4.8,-90.1,23.7).curveTo(-88.3,33.2,-86.3,42).curveTo(-85.6,44.4,-83.6,45.4).curveTo(-83.1,45.5,-82.8,44.8).curveTo(-82.7,44.6,-82.7,44.4).curveTo(-82.5,43.8,-82.4,42.8).lineTo(-82.3,39.8).curveTo(-81.7,33.6,-80.4,29.4).curveTo(-78.7,23.1,-73.5,21.3).curveTo(-59.5,16.3,-46.9,11.6).curveTo(-37.2,8,-6.2,-4.2).curveTo(7,-9.4,30.4,-19.2).curveTo(58,-30.7,71.7,-36.7).curveTo(78.7,-39.8,107.8,-51.2).curveTo(137.4,-62.9,143.8,-65.7).curveTo(143.7,-65,143.1,-64.3).curveTo(143,-64.2,142,-63.2).curveTo(136,-57.1,132.7,-53.7).curveTo(126.7,-47.8,123,-44.6).curveTo(117.1,-39.5,100,-25.3).curveTo(84.9,-12.7,76.6,-6).lineTo(49.1,16.2).curveTo(24.2,36.2,11.7,46.1).curveTo(3.8,52.4,-0.2,55.4).curveTo(-6.9,60.5,-12.5,64.2).curveTo(-16.5,66.8,-19.4,67.9).curveTo(-24.5,69.8,-28,66).curveTo(-38.6,54,-43.3,48.8).curveTo(-51.1,40.1,-52.4,38.7).curveTo(-57.6,33.2,-62.4,29.2).curveTo(-63.8,28,-65.6,27).curveTo(-68,25.7,-69.9,25.8).curveTo(-72.2,25.9,-73.3,28).curveTo(-74,29.7,-76.2,32.9).curveTo(-78.2,35.8,-78.6,37.2).curveTo(-79.1,38.6,-80.7,41).curveTo(-82.1,43.1,-82.7,44.4);
	this.shape.setTransform(0.2826,-1.4454);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.planebyitself, new cjs.Rectangle(-149.1,-74.2,298.79999999999995,153.7), null);


(lib.lendlease_logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.5,-3.6).curveTo(0.8,-4.1,1.4,-4).curveTo(2,-4,2.3,-3.4).lineTo(4.1,0.7).curveTo(4.3,1.2,4.8,1.4).lineTo(-4.8,4).closePath();
	this.shape.setTransform(-37.125,1.6673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.4,8.5).lineTo(-14.8,-3.2).lineTo(-14.3,-3.6).lineTo(-9.2,-8.8).curveTo(-8.8,-9.2,-8.1,-9.2).lineTo(-7.9,-9.2).lineTo(14.8,-6.1).lineTo(14.8,-6).lineTo(5.1,7.9).curveTo(4.2,9.2,2.5,9.2).curveTo(1.3,9.2,0.4,8.5).closePath();
	this.shape_1.setTransform(-51.95,3.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-5.9,6.2).curveTo(-6.3,6.2,-6.6,5.8).curveTo(-6.8,5.5,-6.7,5.1).lineTo(-5.1,-5.2).curveTo(-5.1,-5.7,-5.4,-6.2).lineTo(6.7,0.8).lineTo(1.5,0.1).curveTo(0.5,0.1,-0.1,0.8).lineTo(-5.1,5.9).curveTo(-5.4,6.2,-5.8,6.2).closePath();
	this.shape_2.setTransform(-61.63,-6.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#FFFFFF").beginStroke().moveTo(39.4,7.8).curveTo(37.7,6.4,37.7,3.7).lineTo(37.7,1).curveTo(37.7,-1.5,39.2,-3).curveTo(40.6,-4.5,43,-4.5).curveTo(45.4,-4.5,46.7,-3).curveTo(48,-1.6,48,0.7).lineTo(48,3.4).lineTo(41.2,3.4).lineTo(41.2,3.6).curveTo(41.2,6,43.6,6).curveTo(45.1,6,46.8,5.1).lineTo(47.8,7.9).curveTo(45.6,9,43.2,9).curveTo(40.9,9,39.4,7.8).closePath().moveTo(41.2,0.6).lineTo(41.2,0.8).lineTo(44.7,0.8).lineTo(44.7,0.6).curveTo(44.7,-1.5,43,-1.5).curveTo(41.2,-1.5,41.2,0.6).closePath().moveTo(26.3,7.8).lineTo(27.8,5.1).curveTo(29.3,6.1,31.2,6.1).curveTo(32.7,6.1,32.7,5.2).curveTo(32.7,4.5,31.4,4.1).lineTo(29.8,3.5).curveTo(26.5,2.5,26.6,-0.4).curveTo(26.6,-2.2,28,-3.4).curveTo(29.4,-4.5,31.6,-4.5).curveTo(34.4,-4.5,36.3,-3.3).lineTo(34.8,-0.7).curveTo(33.3,-1.5,31.6,-1.5).curveTo(30.2,-1.5,30.2,-0.7).curveTo(30.1,-0.1,31.2,0.3).lineTo(33.1,0.9).curveTo(34.7,1.5,35.5,2.3).curveTo(36.4,3.3,36.4,4.8).curveTo(36.4,6.7,34.9,7.9).curveTo(33.5,9,31.2,9).curveTo(28.3,9,26.3,7.8).closePath().moveTo(15.8,7.9).curveTo(14.4,6.8,14.4,4.7).curveTo(14.5,3,15.6,1.9).curveTo(16.9,0.8,19,0.8).lineTo(21.5,0.8).lineTo(21.5,0.3).curveTo(21.5,-1.4,19.3,-1.4).curveTo(17.5,-1.4,15.5,-0.3).lineTo(15.2,-3.4).curveTo(17.5,-4.5,20,-4.5).curveTo(22,-4.5,23.3,-3.7).curveTo(24.9,-2.6,24.9,-0.4).lineTo(24.9,7.9).curveTo(22.2,9,19.7,9).curveTo(17.2,9,15.8,7.9).closePath().moveTo(18.3,3.8).curveTo(17.9,4.1,17.9,4.7).curveTo(17.9,5.4,18.5,5.8).curveTo(19,6.2,19.9,6.2).curveTo(20.6,6.2,21.5,5.9).lineTo(21.5,3.4).lineTo(19.6,3.4).curveTo(18.9,3.4,18.3,3.8).closePath().moveTo(4.5,7.8).curveTo(2.8,6.4,2.8,3.7).lineTo(2.8,1).curveTo(2.8,-1.5,4.2,-3).curveTo(5.6,-4.5,8.1,-4.5).curveTo(10.5,-4.5,11.8,-3).curveTo(13.2,-1.6,13.2,0.7).lineTo(13.2,3.4).lineTo(6.2,3.4).lineTo(6.2,3.6).curveTo(6.3,4.8,6.9,5.4).curveTo(7.6,6,8.7,6).curveTo(10.2,6,11.9,5.1).lineTo(12.8,7.9).curveTo(10.8,9,8.2,9).curveTo(6,9,4.5,7.8).closePath().moveTo(6.3,0.6).lineTo(6.3,0.8).lineTo(9.8,0.8).lineTo(9.8,0.6).curveTo(9.8,-1.5,8.1,-1.5).curveTo(6.3,-1.5,6.3,0.6).closePath().moveTo(-3.8,5.9).lineTo(-3.8,-9).lineTo(-0.4,-9).lineTo(-0.4,4.9).curveTo(-0.4,6,0.6,6).curveTo(1.2,6,1.8,5.8).lineTo(2.1,8.6).curveTo(1.1,9,-0.5,9).curveTo(-3.9,9,-3.8,5.9).closePath().moveTo(-15.4,7.6).curveTo(-16.7,6.3,-16.7,4.3).lineTo(-16.7,-0).curveTo(-16.7,-2,-15.4,-3.2).curveTo(-14.1,-4.5,-12,-4.5).curveTo(-10.7,-4.5,-9.6,-4.1).lineTo(-9.6,-9).lineTo(-6.1,-9).lineTo(-6.1,7.9).curveTo(-8.8,9,-11.4,9).curveTo(-13.9,9,-15.4,7.6).closePath().moveTo(-13.3,0.7).lineTo(-13.3,3.8).curveTo(-13.3,6,-10.9,6).curveTo(-10.2,6,-9.6,5.8).lineTo(-9.6,-1.2).curveTo(-10.3,-1.5,-11.2,-1.5).curveTo(-13.2,-1.5,-13.3,0.7).closePath().moveTo(-39.7,7.8).curveTo(-41.4,6.4,-41.4,3.7).lineTo(-41.4,1).curveTo(-41.4,-1.5,-40,-3).curveTo(-38.6,-4.5,-36.2,-4.5).curveTo(-33.8,-4.5,-32.4,-3).curveTo(-31.1,-1.6,-31.1,0.7).lineTo(-31.1,3.4).lineTo(-37.9,3.4).lineTo(-37.9,3.6).curveTo(-37.9,4.8,-37.3,5.4).curveTo(-36.6,6,-35.5,6).curveTo(-34.1,6,-32.3,5.1).lineTo(-31.4,7.9).curveTo(-33.4,9,-36,9).curveTo(-38.2,9,-39.7,7.8).closePath().moveTo(-37.9,0.6).lineTo(-37.9,0.8).lineTo(-34.4,0.8).lineTo(-34.4,0.6).curveTo(-34.4,-1.5,-36.1,-1.5).curveTo(-37.9,-1.5,-37.9,0.6).closePath().moveTo(-48,5.9).lineTo(-48,-9).lineTo(-44.6,-9).lineTo(-44.6,4.9).curveTo(-44.6,6,-43.6,6).curveTo(-43,6,-42.4,5.8).lineTo(-42.1,8.6).curveTo(-43.3,9,-44.7,9).curveTo(-48.1,9,-48,5.9).closePath().moveTo(-22.2,8.8).lineTo(-22.2,0.6).curveTo(-22.2,-1.4,-24.2,-1.4).curveTo(-25,-1.4,-25.8,-1.1).lineTo(-25.8,8.8).lineTo(-29.2,8.8).lineTo(-29.2,-3.3).curveTo(-26.3,-4.5,-23.8,-4.5).curveTo(-21.3,-4.5,-19.9,-3.3).curveTo(-18.7,-2.2,-18.7,-0.1).lineTo(-18.7,8.8).closePath();
	this.shape_3.setTransform(20.35,0.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.lendlease_logo, new cjs.Rectangle(-68.3,-12.7,136.7,25.5), null);


(lib.FHlogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#2E2E2E").beginStroke().moveTo(1.9,5.2).lineTo(-0.8,1.3).lineTo(-2.1,1.3).lineTo(-2.1,5.2).lineTo(-3.6,5.2).lineTo(-3.6,-5.2).lineTo(0.4,-5.2).curveTo(2,-5.2,2.8,-4.2).curveTo(3.5,-3.2,3.5,-1.9).curveTo(3.5,-0.7,2.9,0.2).curveTo(2.1,1.1,0.8,1.2).lineTo(3.6,5.2).closePath().moveTo(-2.1,-0).lineTo(0.3,-0).curveTo(2.1,0,2,-1.9).curveTo(2,-3.8,0.4,-3.8).lineTo(-2.1,-3.8).closePath();
	this.shape.setTransform(10.1,19.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.5,3.8).curveTo(-5.1,2.3,-5,0.1).curveTo(-5.1,-2.2,-3.5,-3.7).curveTo(-2,-5.3,0.2,-5.3).curveTo(2.1,-5.3,3.7,-3.9).lineTo(2.6,-3).curveTo(1.6,-4,0.2,-4).curveTo(-1.5,-4,-2.5,-2.7).curveTo(-3.7,-1.6,-3.7,0.1).curveTo(-3.7,1.7,-2.5,2.8).curveTo(-1.5,4,0.2,4).curveTo(1.6,4,2.5,3.2).curveTo(3.4,2.5,3.4,1.2).lineTo(0.5,1.2).lineTo(0.5,-0).lineTo(5,-0).curveTo(5,2.6,3.7,4).curveTo(2.4,5.3,0.2,5.3).curveTo(-2,5.3,-3.5,3.8).closePath();
	this.shape_1.setTransform(-14.15,19.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#2E2E2E").beginStroke().moveTo(41.4,23.7).curveTo(33.7,20.3,18.5,18.2).lineTo(13.1,17.8).curveTo(-0.7,17.8,-15.3,19.1).curveTo(-31.9,20.6,-41.7,23.1).curveTo(-42.3,23.3,-42.5,22.6).lineTo(-42.5,22.2).curveTo(-42.3,21.8,-42,21.7).curveTo(-33.3,18.7,-24.4,17).curveTo(-14.3,14.9,-4.1,14.9).lineTo(-3.7,14.2).curveTo(-3,12.7,-2.9,12.2).curveTo(-2.6,10.4,-3,8.9).curveTo(-3.4,7.1,-4.5,6).curveTo(-5.6,4.9,-7.2,4.7).curveTo(-8.9,4.5,-12.3,5.6).curveTo(-13.9,6.2,-15,6.4).curveTo(-17.3,6.9,-19.2,6.4).curveTo(-21.4,5.8,-22.2,4).lineTo(-22.3,3.8).lineTo(-22.9,3.9).curveTo(-25.6,3.7,-26.3,1.7).curveTo(-26.8,0.4,-25.9,-0.6).curveTo(-25.5,-1.1,-24.4,-1.8).curveTo(-22.9,-2.7,-23.2,-4.1).lineTo(-23.6,-4.9).curveTo(-24.9,-7.2,-23.7,-8.1).curveTo(-22.9,-8.6,-21.7,-8.7).curveTo(-20.8,-8.8,-20.5,-8.9).curveTo(-19.7,-9.3,-19.3,-11.4).lineTo(-19.1,-12.1).curveTo(-18.7,-14.6,-17.5,-15.4).curveTo(-16.2,-16.2,-14,-15.1).lineTo(-13.3,-14.8).curveTo(-11.7,-14.2,-8.7,-14.9).curveTo(-8.8,-15.5,-8.7,-16.2).curveTo(-8.4,-17.6,-6.4,-19.2).lineTo(-5.5,-20).lineTo(-5.8,-20.6).lineTo(-6,-21.4).curveTo(-6.3,-22.5,-5.9,-23.1).curveTo(-5.5,-23.9,-4.6,-23.7).curveTo(-3.8,-23.6,-3.5,-23).curveTo(-2.8,-21.8,-3.5,-20.5).lineTo(-3.6,-20.2).curveTo(-2.2,-19.3,-0.5,-19.5).curveTo(0.6,-19.6,2.6,-20.5).lineTo(4.6,-21.2).curveTo(6.3,-21.8,7.3,-21).curveTo(8.4,-20.1,8.4,-17.3).lineTo(8.4,-16.6).curveTo(8.4,-14.6,8.6,-13.7).curveTo(8.9,-12.3,10.1,-11.6).curveTo(11.1,-11.1,12,-11.8).lineTo(12.6,-12.5).curveTo(13.6,-13.8,14.7,-14).curveTo(15.7,-14.2,16.3,-13.7).curveTo(17,-13.1,17,-11.8).curveTo(16.9,-9.7,17.6,-8.7).lineTo(18.2,-8).lineTo(18.4,-8.1).curveTo(19.6,-9.2,20.9,-8.9).curveTo(21.7,-8.7,21.9,-7.9).curveTo(22.2,-7.2,21.7,-6.6).curveTo(21.3,-6.1,20.6,-5.9).curveTo(19.9,-5.7,19.4,-5.8).lineTo(18.8,-6).curveTo(18.6,-5.3,19,-4.8).curveTo(19.8,-3.9,21.5,-3.8).curveTo(24.1,-3.7,25.3,-2.1).curveTo(26.4,-0.5,26.5,1.6).curveTo(26.5,2.9,26,4.1).curveTo(25.4,5.6,24.4,6.2).curveTo(23.1,7,21.6,6.3).curveTo(20.8,5.9,20.2,5.2).curveTo(19.4,4.5,19,4.3).curveTo(18.6,4.2,18.2,4.3).curveTo(17.8,4.4,17.3,5.2).curveTo(15.1,8.2,11.1,7.6).curveTo(10.1,7.5,7.8,6.4).lineTo(7.4,6.2).curveTo(5.8,5.4,4.7,5.1).curveTo(3.7,4.9,3.1,5.2).curveTo(2.3,5.5,2,6.2).curveTo(1.7,7,1.9,7.8).curveTo(2.6,9.7,3,10).curveTo(3.5,10.3,3.2,10.8).curveTo(3,11.3,2.4,11.1).lineTo(2.4,11.1).curveTo(1.2,10.7,0.7,8.8).curveTo(0.2,7.1,0.5,6).curveTo(0.8,4.7,1.9,4.1).curveTo(3.1,3.3,4.8,3.8).lineTo(5,3.8).curveTo(5.9,4,8.3,5.1).lineTo(8.4,5.2).curveTo(10.2,6.1,11.3,6.3).curveTo(12.8,6.6,14.2,6).curveTo(14.8,5.7,15.7,4.7).lineTo(16.6,3.7).curveTo(17.1,3.2,17.9,3).curveTo(18.5,2.8,19.3,3.1).lineTo(19.5,3.1).curveTo(20.3,3.5,20.8,4).lineTo(21,4.2).lineTo(22.3,5.1).curveTo(22.8,5.3,23.3,5.2).curveTo(24.5,4.8,24.9,3.1).curveTo(25.3,1.7,24.9,0.2).curveTo(24.4,-1.6,23.1,-2.1).curveTo(22.7,-2.4,21.5,-2.4).curveTo(20.2,-2.4,19.4,-2.7).curveTo(17.7,-3.5,17.4,-5.1).curveTo(17.3,-5.9,17.5,-6.7).curveTo(17.1,-7,16.6,-7.7).curveTo(15.5,-9.2,15.5,-10.7).lineTo(15.6,-11.5).curveTo(15.7,-12.4,15.5,-12.6).lineTo(15.3,-12.7).curveTo(14.7,-12.7,14,-12).lineTo(13.7,-11.6).curveTo(12.4,-10.2,11.2,-10).curveTo(9.8,-9.9,8.8,-10.8).curveTo(7.1,-12.3,7,-15.4).lineTo(7,-16.1).curveTo(7,-19.4,6.3,-19.9).curveTo(5.9,-20.1,5.3,-20).lineTo(3.3,-19.2).curveTo(1.6,-18.5,0.7,-18.3).curveTo(-0.8,-17.9,-2.1,-18.1).curveTo(-3.4,-18.3,-4.5,-19.1).lineTo(-5.5,-18.2).curveTo(-7.5,-16.5,-7.3,-15.2).curveTo(-4.5,-15.9,-2.6,-15.3).curveTo(-0.7,-14.7,-0.1,-13.1).curveTo(0.5,-11.4,-0.7,-10.6).curveTo(-1.4,-10.1,-2.6,-10.3).curveTo(-3.1,-10.3,-4,-10.6).curveTo(-5.1,-10.9,-6.3,-11.7).curveTo(-7.6,-12.6,-8.2,-13.6).curveTo(-11.3,-12.8,-13.1,-13.3).lineTo(-14.5,-13.8).curveTo(-15.5,-14.3,-15.9,-14.3).curveTo(-16.5,-14.5,-16.9,-14.1).curveTo(-17.5,-13.6,-17.9,-11.5).lineTo(-18.2,-10).curveTo(-18.8,-8.4,-19.6,-7.8).curveTo(-20.2,-7.4,-21.5,-7.3).lineTo(-22.2,-7.2).curveTo(-22.8,-7,-22.8,-6.9).curveTo(-22.8,-6.8,-22.4,-5.8).lineTo(-21.9,-4.7).curveTo(-21.1,-2,-23.9,-0.5).curveTo(-24.9,0.1,-25,0.9).curveTo(-25.1,1.4,-24.5,1.9).curveTo(-23.9,2.5,-22.5,2.6).curveTo(-22.5,2.1,-22.2,1.7).curveTo(-21.9,1.1,-21.1,1).curveTo(-20.5,0.9,-20,1.3).curveTo(-19.3,1.9,-19.5,2.7).curveTo(-19.7,3.2,-20.7,3.6).lineTo(-20.9,3.6).curveTo(-20.5,4.4,-19.8,4.8).curveTo(-18.7,5.4,-16.8,5.2).curveTo(-15.1,5.1,-13.5,4.6).lineTo(-13.2,4.5).curveTo(-10,3.4,-8.3,3.3).curveTo(-5.4,3.2,-3.5,5).curveTo(-1.8,6.6,-1.5,9.2).curveTo(-1.2,11.4,-1.9,13.6).lineTo(-1.9,13.7).lineTo(-2.4,14.9).lineTo(0.6,15).curveTo(9.3,15.5,18.6,16.9).lineTo(29.9,17.3).lineTo(41.9,17.7).curveTo(42.5,17.8,42.5,18.4).curveTo(42.4,19.1,41.8,19).lineTo(29.8,18.6).lineTo(28.2,18.5).curveTo(37.1,20.4,41.9,22.5).curveTo(42.5,22.7,42.2,23.3).curveTo(42.1,23.7,41.6,23.7).closePath().moveTo(-24.2,18.3).lineTo(-29.4,19.4).curveTo(-13.9,17.1,5.1,16.6).lineTo(-3.7,16.2).curveTo(-14.3,16.2,-24.2,18.3).closePath().moveTo(20,-7.5).lineTo(19.6,-7.3).curveTo(20.4,-7.1,20.6,-7.4).lineTo(20.6,-7.5).lineTo(20.4,-7.5).lineTo(20,-7.5).closePath().moveTo(-6.7,-13.9).curveTo(-6.4,-13.4,-5.6,-12.8).curveTo(-5,-12.4,-4.5,-12.3).lineTo(-4.4,-12.2).curveTo(-3.2,-11.7,-2.5,-11.6).lineTo(-1.6,-11.7).lineTo(-1.4,-12).curveTo(-1.2,-12.5,-1.6,-13).curveTo(-2.4,-14.2,-4.5,-14.2).curveTo(-5.5,-14.2,-6.7,-13.9).closePath().moveTo(-4.8,-21.9).lineTo(-4.7,-21.3).curveTo(-4.5,-21.8,-4.7,-22.2).lineTo(-4.7,-22.3).closePath();
	this.shape_2.setTransform(0.025,-16.7375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-2.8,5.2).lineTo(-2.8,-5.2).lineTo(-1.4,-5.2).lineTo(-1.4,3.8).lineTo(2.8,3.8).lineTo(2.8,5.2).closePath();
	this.shape_3.setTransform(15.45,35.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-2.8,5.2).lineTo(-2.8,-5.2).lineTo(-1.4,-5.2).lineTo(-1.4,3.8).lineTo(2.8,3.8).lineTo(2.8,5.2).closePath();
	this.shape_4.setTransform(5.25,35.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-0.7,5.2).lineTo(-0.7,-5.2).lineTo(0.7,-5.2).lineTo(0.7,5.2).closePath();
	this.shape_5.setTransform(-3.95,35.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#2E2E2E").beginStroke().moveTo(2.5,5.2).lineTo(2.5,0.7).lineTo(-2.5,0.7).lineTo(-2.5,5.2).lineTo(-3.9,5.2).lineTo(-3.9,-5.2).lineTo(-2.5,-5.2).lineTo(-2.5,-0.6).lineTo(2.5,-0.6).lineTo(2.5,-5.2).lineTo(3.9,-5.2).lineTo(3.9,5.2).closePath();
	this.shape_6.setTransform(-14.3,35.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.2,5.2).lineTo(-3.2,-5.2).lineTo(3,-5.2).lineTo(3,-3.8).lineTo(-1.7,-3.8).lineTo(-1.7,-0.6).lineTo(2.4,-0.6).lineTo(2.4,0.8).lineTo(-1.7,0.8).lineTo(-1.7,3.8).lineTo(3.1,3.8).lineTo(3.1,5.2).closePath();
	this.shape_7.setTransform(33.2,19.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.1,5.2).lineTo(-3.1,-5.2).lineTo(3,-5.2).lineTo(3,-3.8).lineTo(-1.7,-3.8).lineTo(-1.7,-0.6).lineTo(2.4,-0.6).lineTo(2.4,0.8).lineTo(-1.7,0.8).lineTo(-1.7,3.8).lineTo(3.1,3.8).lineTo(3.1,5.2).closePath();
	this.shape_8.setTransform(21.925,19.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-0.7,5.2).lineTo(-0.7,-3.8).lineTo(-3.8,-3.8).lineTo(-3.8,-5.2).lineTo(3.8,-5.2).lineTo(3.8,-3.8).lineTo(0.7,-3.8).lineTo(0.7,5.2).closePath();
	this.shape_9.setTransform(-1.85,19.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-0.7,5.2).lineTo(-0.7,-5.2).lineTo(0.7,-5.2).lineTo(0.7,5.2).closePath();
	this.shape_10.setTransform(-24.975,19.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3,5.2).lineTo(-3,-5.2).lineTo(3,-5.2).lineTo(3,-3.8).lineTo(-1.6,-3.8).lineTo(-1.6,-0.6).lineTo(2.1,-0.6).lineTo(2.1,0.8).lineTo(-1.6,0.8).lineTo(-1.6,5.2).closePath();
	this.shape_11.setTransform(-33.275,19.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.FHlogo, new cjs.Rectangle(-42.5,-40.5,85.1,81.1), null);


(lib.Plane = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_17
	this.instance = new lib.planebyitself();
	this.instance.parent = this;
	this.instance.setTransform(-409.55,214.9,0.8587,0.8587,0,0,0,0.1,3.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Plane, new cjs.Rectangle(-537.7,148.5,256.6,131.89999999999998), null);


// stage content:
(lib.FHLeaderboard_728x90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{lineout:71,"lineout":169,"lineout":267});

	// trace_idn
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(9.8,-1.6).curveTo(9.3,-1.5,8.9,-1.4).curveTo(8,-1.3,7.3,-1.2).curveTo(4.6,-0.8,3.1,-0.5).curveTo(-1.5,0.3,-3.7,0.7).curveTo(-5.8,0.9,-9.9,1.6);
	this.shape.setTransform(-4.729,90.1398);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(12.4,-2).curveTo(11.1,-1.8,10.1,-1.7).curveTo(8.6,-1.4,7.6,-1.2).curveTo(7,-1.1,6.5,-1).curveTo(5.6,-0.9,4.9,-0.8).curveTo(2.2,-0.4,0.7,-0.1).curveTo(-3.9,0.7,-6.1,1.1).curveTo(-8.2,1.3,-12.3,2);
	this.shape_1.setTransform(-2.306,89.724);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(14.4,-2.4).curveTo(13.1,-2.2,12.1,-2).curveTo(9.8,-1.6,8.1,-1.3).curveTo(6.6,-1,5.6,-0.9).curveTo(5,-0.8,4.5,-0.7).curveTo(3.6,-0.6,2.9,-0.5).curveTo(0.2,-0.1,-1.3,0.2).curveTo(-5.9,1.1,-8.1,1.4).curveTo(-10.2,1.7,-14.3,2.4);
	this.shape_2.setTransform(-0.3056,89.3866);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(17.2,-2.8).curveTo(16.8,-2.8,16.4,-2.7).curveTo(11.5,-2,9,-1.5).curveTo(6.6,-1.1,5,-0.9).curveTo(3.4,-0.6,2.4,-0.4).curveTo(1.8,-0.3,1.3,-0.2).curveTo(0.5,-0.1,-0.3,-0).curveTo(-2.9,0.4,-4.4,0.7).curveTo(-9,1.5,-11.3,1.9).curveTo(-13.3,2.1,-17.5,2.8);
	this.shape_3.setTransform(2.821,88.9105);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(19.3,-3.2).curveTo(16.2,-2.6,14.5,-2.4).curveTo(9.6,-1.6,7.1,-1.2).curveTo(4.7,-0.8,3.1,-0.5).curveTo(1.5,-0.2,0.5,-0.1).curveTo(-0.1,0,-0.6,0.1).curveTo(-1.4,0.2,-2.2,0.3).curveTo(-4.8,0.7,-6.3,1).curveTo(-10.9,1.9,-13.2,2.2).curveTo(-15.2,2.5,-19.4,3.2);
	this.shape_4.setTransform(4.7084,88.5515);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(22.3,-3.8).curveTo(19.2,-3.2,17.9,-3).curveTo(13.7,-2.2,11.6,-1.8).curveTo(6.7,-1.1,4.1,-0.6).curveTo(1.8,-0.2,0.1,0).curveTo(-1.4,0.3,-2.4,0.5).curveTo(-3,0.6,-3.5,0.7).curveTo(-4.4,0.8,-5.1,0.9).curveTo(-7.8,1.3,-9.3,1.6).curveTo(-13.9,2.4,-16.1,2.8).curveTo(-18.2,3,-22.3,3.7);
	this.shape_5.setTransform(7.6802,88.0009);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(23.3,-4).curveTo(22.2,-3.8,20.9,-3.6).curveTo(20.6,-3.6,20.3,-3.5).curveTo(17.2,-2.9,15.9,-2.7).curveTo(11.6,-1.9,9.5,-1.5).curveTo(4.6,-0.8,2.1,-0.3).curveTo(-0.3,0.1,-1.9,0.3).curveTo(-3.5,0.6,-4.5,0.8).curveTo(-5.1,0.9,-5.6,1).curveTo(-6.4,1.1,-7.2,1.2).curveTo(-9.8,1.6,-11.3,1.9).curveTo(-15.9,2.7,-18.2,3.1).curveTo(-20.2,3.3,-24.4,4);
	this.shape_6.setTransform(9.721,87.7038);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(26.3,-4.6).curveTo(24.7,-4.3,23,-4).curveTo(21.2,-3.6,17.9,-3.1).curveTo(17.6,-3,17.3,-2.9).curveTo(14.2,-2.4,12.9,-2.1).curveTo(8.6,-1.3,6.5,-1).curveTo(1.6,-0.2,-0.9,0.2).curveTo(-3.3,0.6,-4.9,0.9).curveTo(-6.5,1.2,-7.5,1.3).curveTo(-8.1,1.4,-8.6,1.5).curveTo(-9.4,1.6,-10.2,1.7).curveTo(-12.8,2.1,-14.3,2.4).curveTo(-18.9,3.3,-21.2,3.6).curveTo(-23.2,3.9,-27.4,4.6);
	this.shape_7.setTransform(12.721,87.1518);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(29.3,-5.2).curveTo(24.7,-4.2,20,-3.4).curveTo(18.2,-3,14.9,-2.4).curveTo(14.6,-2.4,14.3,-2.3).curveTo(11.2,-1.7,9.9,-1.5).curveTo(5.6,-0.7,3.5,-0.3).curveTo(-1.4,0.4,-3.9,0.9).curveTo(-6.3,1.3,-7.9,1.5).curveTo(-9.5,1.8,-10.5,2).curveTo(-11.1,2.1,-11.6,2.2).curveTo(-12.4,2.3,-13.2,2.4).curveTo(-15.8,2.8,-17.3,3.1).curveTo(-21.9,3.9,-24.2,4.3).curveTo(-26.2,4.5,-30.4,5.2);
	this.shape_8.setTransform(15.721,86.5428);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(35.9,-6.5).curveTo(30.6,-5.4,24,-4.1).curveTo(18.8,-3,13.5,-2).curveTo(11.7,-1.6,8.4,-1.1).curveTo(8.1,-1,7.7,-0.9).curveTo(4.6,-0.4,3.3,-0.1).curveTo(-0.9,0.7,-3,1).curveTo(-7.9,1.8,-10.5,2.2).curveTo(-12.8,2.6,-14.5,2.9).curveTo(-16,3.2,-17,3.3).curveTo(-17.6,3.4,-18.1,3.5).curveTo(-19,3.6,-19.7,3.7).curveTo(-22.4,4.1,-23.9,4.4).curveTo(-28.5,5.3,-30.7,5.6).curveTo(-32.8,5.9,-36.9,6.6);
	this.shape_9.setTransform(22.271,85.1913);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(37.8,-7).curveTo(31.2,-5.5,22.2,-3.7).curveTo(17,-2.6,11.6,-1.6).curveTo(9.8,-1.2,6.5,-0.7).curveTo(6.2,-0.6,5.9,-0.5).curveTo(2.8,0,1.5,0.3).curveTo(-2.8,1.1,-4.9,1.4).curveTo(-9.8,2.2,-12.3,2.6).curveTo(-14.7,3,-16.3,3.3).curveTo(-17.9,3.6,-18.9,3.7).curveTo(-19.5,3.8,-20,3.9).curveTo(-20.8,4,-21.6,4.1).curveTo(-24.2,4.5,-25.7,4.8).curveTo(-30.3,5.7,-32.6,6).curveTo(-34.6,6.3,-38.8,7);
	this.shape_10.setTransform(24.146,84.7663);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(40.3,-7.6).curveTo(39.3,-7.3,38.3,-7).curveTo(30.8,-5.3,19.7,-3.1).curveTo(14.5,-2,9.1,-1).curveTo(7.3,-0.6,4,-0.1).curveTo(3.7,-0,3.4,0.1).curveTo(0.3,0.6,-1,0.9).curveTo(-5.3,1.7,-7.4,2).curveTo(-12.3,2.8,-14.8,3.2).curveTo(-17.2,3.6,-18.8,3.9).curveTo(-20.4,4.2,-21.4,4.3).curveTo(-22,4.4,-22.5,4.5).curveTo(-23.3,4.6,-24.1,4.7).curveTo(-26.7,5.1,-28.2,5.4).curveTo(-32.8,6.3,-35.1,6.6).curveTo(-37.1,6.9,-41.3,7.6);
	this.shape_11.setTransform(26.646,84.1663);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(42.6,-8.2).curveTo(39.4,-7.4,35.9,-6.4).curveTo(28.4,-4.7,17.3,-2.5).curveTo(12.1,-1.4,6.7,-0.4).curveTo(4.9,-0,1.6,0.5).curveTo(1.3,0.6,1,0.7).curveTo(-2.1,1.2,-3.4,1.5).curveTo(-7.7,2.3,-9.8,2.6).curveTo(-14.7,3.4,-17.2,3.8).curveTo(-19.6,4.2,-21.2,4.5).curveTo(-22.8,4.8,-23.8,4.9).curveTo(-24.4,5,-24.9,5.1).curveTo(-25.7,5.2,-26.5,5.3).curveTo(-29.1,5.7,-30.6,6).curveTo(-35.2,6.9,-37.5,7.2).curveTo(-39.5,7.5,-43.7,8.2);
	this.shape_12.setTransform(29.021,83.5663);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(44.5,-8.7).curveTo(39.7,-7.3,34,-5.9).curveTo(26.6,-4.2,15.4,-2).curveTo(10.2,-0.8,4.9,0.1).curveTo(3.1,0.5,-0.2,1.1).curveTo(-0.5,1.1,-0.9,1.2).curveTo(-4,1.8,-5.3,2).curveTo(-9.5,2.8,-11.6,3.2).curveTo(-16.5,3.9,-19.1,4.4).curveTo(-21.4,4.8,-23.1,5).curveTo(-24.6,5.3,-25.6,5.5).curveTo(-26.2,5.6,-26.7,5.7).curveTo(-27.6,5.8,-28.3,5.9).curveTo(-31,6.3,-32.5,6.6).curveTo(-37.1,7.4,-39.3,7.8).curveTo(-41.4,8,-45.5,8.7);
	this.shape_13.setTransform(30.896,83.0413);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(48.8,-10).curveTo(47.2,-9.5,45.5,-8.9).curveTo(38.6,-6.8,29.7,-4.6).curveTo(22.3,-2.9,11.1,-0.7).curveTo(5.9,0.4,0.6,1.4).curveTo(-1.2,1.8,-4.5,2.3).curveTo(-4.8,2.4,-5.2,2.5).curveTo(-8.3,3,-9.6,3.3).curveTo(-13.8,4.1,-15.9,4.4).curveTo(-20.8,5.2,-23.4,5.6).curveTo(-25.7,6,-27.4,6.3).curveTo(-28.9,6.6,-29.9,6.7).curveTo(-30.5,6.8,-31,6.9).curveTo(-31.9,7,-32.6,7.1).curveTo(-35.3,7.5,-36.8,7.8).curveTo(-41.4,8.7,-43.6,9).curveTo(-45.7,9.3,-49.8,10);
	this.shape_14.setTransform(35.196,81.7663);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(51.4,-10.9).curveTo(47.8,-9.5,42.9,-8).curveTo(36,-5.8,27.1,-3.7).curveTo(19.7,-2,8.5,0.2).curveTo(3.3,1.4,-2,2.3).curveTo(-3.8,2.7,-7.1,3.3).curveTo(-7.4,3.3,-7.8,3.4).curveTo(-10.9,4,-12.2,4.2).curveTo(-16.4,5,-18.5,5.4).curveTo(-23.4,6.1,-26,6.6).curveTo(-28.3,7,-30,7.2).curveTo(-31.5,7.5,-32.5,7.7).curveTo(-33.1,7.8,-33.6,7.9).curveTo(-34.5,8,-35.2,8.1).curveTo(-37.9,8.5,-39.4,8.8).curveTo(-44,9.6,-46.2,10).curveTo(-48.3,10.2,-52.4,10.9);
	this.shape_15.setTransform(37.796,80.8163);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(53.8,-12.1).curveTo(53.1,-11.7,52.2,-11.4).curveTo(47.8,-9.2,40.5,-7).curveTo(33.7,-4.8,24.8,-2.7).curveTo(17.3,-1,6.2,1.2).curveTo(1,2.4,-4.4,3.3).curveTo(-6.2,3.7,-9.5,4.3).curveTo(-9.8,4.3,-10.1,4.4).curveTo(-13.2,5,-14.5,5.2).curveTo(-18.8,6,-20.9,6.4).curveTo(-25.8,7.1,-28.3,7.6).curveTo(-30.7,8,-32.3,8.2).curveTo(-33.9,8.5,-34.9,8.7).curveTo(-35.5,8.8,-36,8.9).curveTo(-36.8,9,-37.6,9.1).curveTo(-40.2,9.5,-41.7,9.8).curveTo(-46.3,10.6,-48.6,11).curveTo(-50.6,11.2,-54.8,11.9);
	this.shape_16.setTransform(40.146,79.809);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(54.8,-12.6).curveTo(53.4,-11.7,51.2,-10.7).curveTo(46.8,-8.5,39.5,-6.3).curveTo(32.7,-4.1,23.8,-2).curveTo(16.3,-0.3,5.2,1.9).curveTo(-0,3.1,-5.4,4).curveTo(-7.2,4.4,-10.5,5).curveTo(-10.8,5,-11.1,5.1).curveTo(-14.2,5.7,-15.5,5.9).curveTo(-19.8,6.7,-21.9,7.1).curveTo(-26.8,7.8,-29.3,8.3).curveTo(-31.7,8.7,-33.3,8.9).curveTo(-34.9,9.2,-35.9,9.4).curveTo(-36.5,9.5,-37,9.6).curveTo(-37.8,9.7,-38.6,9.8).curveTo(-41.2,10.2,-42.7,10.5).curveTo(-47.3,11.3,-49.6,11.7).curveTo(-51.6,11.9,-55.8,12.6);
	this.shape_17.setTransform(41.146,79.1163);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(56.9,-15.5).curveTo(56.5,-14.4,55.7,-13.4).curveTo(54.4,-11.9,52.6,-10.7).curveTo(51.3,-9.8,49.1,-8.8).curveTo(44.6,-6.5,37.4,-4.3).curveTo(30.5,-2.2,21.6,-0).curveTo(14.2,1.7,3,3.9).curveTo(-2.2,5,-7.5,6).curveTo(-9.3,6.4,-12.6,6.9).curveTo(-12.9,7,-13.3,7.1).curveTo(-16.4,7.6,-17.7,7.9).curveTo(-21.9,8.7,-24,9).curveTo(-28.9,9.8,-31.5,10.2).curveTo(-33.8,10.6,-35.5,10.9).curveTo(-37,11.2,-38,11.3).curveTo(-38.6,11.4,-39.1,11.5).curveTo(-40,11.6,-40.7,11.7).curveTo(-43.4,12.1,-44.9,12.4).curveTo(-49.5,13.3,-51.7,13.6).curveTo(-53.8,13.9,-57.9,14.6);
	this.shape_18.setTransform(43.271,77.1518);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(57.1,-16.3).curveTo(56.9,-14.5,55.5,-12.7).curveTo(54.2,-11.2,52.4,-10).curveTo(51.1,-9.1,48.9,-8.1).curveTo(44.4,-5.9,37.2,-3.7).curveTo(30.3,-1.5,21.4,0.6).curveTo(14,2.3,2.8,4.5).curveTo(-2.4,5.7,-7.7,6.6).curveTo(-9.5,7,-12.8,7.6).curveTo(-13.1,7.6,-13.5,7.7).curveTo(-16.6,8.3,-17.9,8.5).curveTo(-22.1,9.3,-24.2,9.7).curveTo(-29.1,10.4,-31.7,10.9).curveTo(-34,11.3,-35.7,11.5).curveTo(-37.2,11.8,-38.2,12).curveTo(-38.8,12.1,-39.3,12.2).curveTo(-40.2,12.3,-40.9,12.4).curveTo(-43.6,12.8,-45.1,13.1).curveTo(-49.7,13.9,-51.9,14.3).curveTo(-54,14.5,-58.1,15.2);
	this.shape_19.setTransform(43.471,76.5408);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(54.9,-18.7).curveTo(55.9,-17.3,56.5,-16.1).curveTo(58,-12.7,55.5,-9.7).curveTo(54.2,-8.2,52.4,-7).curveTo(51.1,-6.1,48.9,-5.1).curveTo(44.4,-2.9,37.2,-0.7).curveTo(30.3,1.5,21.4,3.6).curveTo(14,5.3,2.8,7.5).curveTo(-2.4,8.7,-7.7,9.6).curveTo(-9.5,10,-12.8,10.6).curveTo(-13.1,10.6,-13.5,10.7).curveTo(-16.6,11.3,-17.9,11.5).curveTo(-22.1,12.3,-24.2,12.7).curveTo(-29.1,13.4,-31.7,13.9).curveTo(-34,14.3,-35.7,14.5).curveTo(-37.2,14.8,-38.2,15).curveTo(-38.8,15.1,-39.3,15.2).curveTo(-40.2,15.3,-40.9,15.4).curveTo(-43.6,15.8,-45.1,16.1).curveTo(-49.7,16.9,-51.9,17.3).curveTo(-54,17.5,-58.1,18.2);
	this.shape_20.setTransform(43.4523,73.5443);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(51.4,-20.2).curveTo(52.2,-19.5,52.9,-18.9).curveTo(55.4,-16.4,56.5,-14.1).curveTo(58,-10.7,55.5,-7.7).curveTo(54.2,-6.2,52.4,-5).curveTo(51.1,-4.1,48.9,-3.1).curveTo(44.4,-0.9,37.2,1.3).curveTo(30.3,3.5,21.4,5.6).curveTo(14,7.3,2.8,9.5).curveTo(-2.4,10.7,-7.7,11.6).curveTo(-9.5,12,-12.8,12.6).curveTo(-13.1,12.6,-13.5,12.7).curveTo(-16.6,13.3,-17.9,13.5).curveTo(-22.1,14.3,-24.2,14.7).curveTo(-29.1,15.4,-31.7,15.9).curveTo(-34,16.3,-35.7,16.5).curveTo(-37.2,16.8,-38.2,17).curveTo(-38.8,17.1,-39.3,17.2).curveTo(-40.2,17.3,-40.9,17.4).curveTo(-43.6,17.8,-45.1,18.1).curveTo(-49.7,18.9,-51.9,19.3).curveTo(-54,19.5,-58.1,20.2);
	this.shape_21.setTransform(43.4523,71.5413);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(49.2,-21.2).curveTo(51.3,-19.6,52.9,-18.1).curveTo(55.4,-15.7,56.5,-13.4).curveTo(58,-10,55.5,-7).curveTo(54.2,-5.5,52.4,-4.3).curveTo(51.1,-3.4,48.9,-2.4).curveTo(44.4,-0.1,37.2,2.1).curveTo(30.3,4.2,21.4,6.4).curveTo(14,8.1,2.8,10.3).curveTo(-2.4,11.4,-7.7,12.4).curveTo(-9.5,12.8,-12.8,13.3).curveTo(-13.1,13.4,-13.5,13.5).curveTo(-16.6,14,-17.9,14.3).curveTo(-22.1,15.1,-24.2,15.4).curveTo(-29.1,16.2,-31.7,16.6).curveTo(-34,17,-35.7,17.3).curveTo(-37.2,17.6,-38.2,17.7).curveTo(-38.8,17.8,-39.3,17.9).curveTo(-40.2,18,-40.9,18.1).curveTo(-43.6,18.5,-45.1,18.8).curveTo(-49.7,19.7,-51.9,20).curveTo(-54,20.3,-58.1,21);
	this.shape_22.setTransform(43.4523,70.7899);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(45,-22.5).curveTo(45.2,-22.4,45.3,-22.2).curveTo(47.9,-20.7,49.2,-19.6).curveTo(51.3,-18,52.9,-16.5).curveTo(55.4,-14.1,56.5,-11.8).curveTo(58,-8.4,55.5,-5.4).curveTo(54.2,-3.9,52.4,-2.7).curveTo(51.1,-1.8,48.9,-0.8).curveTo(44.4,1.5,37.2,3.7).curveTo(30.3,5.8,21.4,8).curveTo(14,9.7,2.8,11.9).curveTo(-2.4,13,-7.7,14).curveTo(-9.5,14.4,-12.8,14.9).curveTo(-13.1,15,-13.5,15.1).curveTo(-16.6,15.6,-17.9,15.9).curveTo(-22.1,16.7,-24.2,17).curveTo(-29.1,17.8,-31.7,18.2).curveTo(-34,18.6,-35.7,18.9).curveTo(-37.2,19.2,-38.2,19.3).curveTo(-38.8,19.4,-39.3,19.5).curveTo(-40.2,19.6,-40.9,19.7).curveTo(-43.6,20.1,-45.1,20.4).curveTo(-49.7,21.3,-51.9,21.6).curveTo(-54,21.9,-58.1,22.6);
	this.shape_23.setTransform(43.4523,69.1913);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(41.6,-23.6).curveTo(43.2,-22.5,45.3,-21.1).curveTo(47.9,-19.6,49.2,-18.5).curveTo(51.3,-16.9,52.9,-15.4).curveTo(55.4,-13,56.5,-10.7).curveTo(58,-7.3,55.5,-4.3).curveTo(54.2,-2.8,52.4,-1.6).curveTo(51.1,-0.7,48.9,0.3).curveTo(44.4,2.6,37.2,4.8).curveTo(30.3,6.9,21.4,9.1).curveTo(14,10.8,2.8,13).curveTo(-2.4,14.1,-7.7,15.1).curveTo(-9.5,15.5,-12.8,16).curveTo(-13.1,16.1,-13.5,16.2).curveTo(-16.6,16.7,-17.9,17).curveTo(-22.1,17.8,-24.2,18.1).curveTo(-29.1,18.9,-31.7,19.3).curveTo(-34,19.7,-35.7,20).curveTo(-37.2,20.3,-38.2,20.4).curveTo(-38.8,20.5,-39.3,20.6).curveTo(-40.2,20.7,-40.9,20.8).curveTo(-43.6,21.2,-45.1,21.5).curveTo(-49.7,22.4,-51.9,22.7).curveTo(-54,23,-58.1,23.7);
	this.shape_24.setTransform(43.4523,68.0913);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(41.2,-23.8).curveTo(42.9,-22.6,45.3,-21).curveTo(47.9,-19.5,49.2,-18.4).curveTo(51.3,-16.8,52.9,-15.3).curveTo(55.4,-12.9,56.5,-10.6).curveTo(58,-7.2,55.5,-4.2).curveTo(54.2,-2.7,52.4,-1.5).curveTo(51.1,-0.6,48.9,0.4).curveTo(44.4,2.7,37.2,4.9).curveTo(30.3,7,21.4,9.2).curveTo(14,10.9,2.8,13.1).curveTo(-2.4,14.2,-7.7,15.2).curveTo(-9.5,15.6,-12.8,16.1).curveTo(-13.1,16.2,-13.5,16.3).curveTo(-16.6,16.8,-17.9,17.1).curveTo(-22.1,17.9,-24.2,18.2).curveTo(-29.1,19,-31.7,19.4).curveTo(-34,19.8,-35.7,20.1).curveTo(-37.2,20.4,-38.2,20.5).curveTo(-38.8,20.6,-39.3,20.7).curveTo(-40.2,20.8,-40.9,20.9).curveTo(-43.6,21.3,-45.1,21.6).curveTo(-49.7,22.5,-51.9,22.8).curveTo(-54,23.1,-58.1,23.8);
	this.shape_25.setTransform(43.4523,67.9663);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(35.6,-25.6).curveTo(37.1,-24.6,38.9,-23.4).curveTo(41.1,-22,45.3,-19.1).curveTo(47.9,-17.6,49.2,-16.5).curveTo(51.3,-14.9,52.9,-13.4).curveTo(55.4,-11,56.5,-8.7).curveTo(58,-5.3,55.5,-2.3).curveTo(54.2,-0.8,52.4,0.4).curveTo(51.1,1.3,48.9,2.3).curveTo(44.4,4.6,37.2,6.8).curveTo(30.3,8.9,21.4,11.1).curveTo(14,12.8,2.8,15).curveTo(-2.4,16.1,-7.7,17.1).curveTo(-9.5,17.5,-12.8,18).curveTo(-13.1,18.1,-13.5,18.2).curveTo(-16.6,18.7,-17.9,19).curveTo(-22.1,19.8,-24.2,20.1).curveTo(-29.1,20.9,-31.7,21.3).curveTo(-34,21.7,-35.7,22).curveTo(-37.2,22.3,-38.2,22.4).curveTo(-38.8,22.5,-39.3,22.6).curveTo(-40.2,22.7,-40.9,22.8).curveTo(-43.6,23.2,-45.1,23.5).curveTo(-49.7,24.4,-51.9,24.7).curveTo(-54,25,-58.1,25.7);
	this.shape_26.setTransform(43.4523,66.0913);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(30.4,-27.8).curveTo(31.3,-26.8,32.7,-25.6).curveTo(33,-25.4,33.3,-25.1).curveTo(35.6,-23.4,38.9,-21.2).curveTo(41.1,-19.8,45.3,-17).curveTo(47.9,-15.4,49.2,-14.3).curveTo(51.3,-12.7,52.9,-11.3).curveTo(55.4,-8.8,56.5,-6.5).curveTo(58,-3.1,55.5,-0.1).curveTo(54.2,1.4,52.4,2.6).curveTo(51.1,3.5,48.9,4.5).curveTo(44.4,6.7,37.2,8.9).curveTo(30.3,11.1,21.4,13.2).curveTo(14,14.9,2.8,17.1).curveTo(-2.4,18.3,-7.7,19.2).curveTo(-9.5,19.6,-12.8,20.2).curveTo(-13.1,20.2,-13.5,20.3).curveTo(-16.6,20.9,-17.9,21.1).curveTo(-22.1,21.9,-24.2,22.3).curveTo(-29.1,23,-31.7,23.5).curveTo(-34,23.9,-35.7,24.1).curveTo(-37.2,24.4,-38.2,24.6).curveTo(-38.8,24.7,-39.3,24.8).curveTo(-40.2,24.9,-40.9,25).curveTo(-43.6,25.4,-45.1,25.7).curveTo(-49.7,26.5,-51.9,26.9).curveTo(-54,27.1,-58.1,27.8);
	this.shape_27.setTransform(43.4523,63.9163);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(30,-28.1).curveTo(31,-26.8,32.7,-25.3).curveTo(35.1,-23.4,38.9,-20.9).curveTo(41.1,-19.5,45.3,-16.7).curveTo(47.9,-15.1,49.2,-14).curveTo(51.3,-12.4,52.9,-11).curveTo(55.4,-8.5,56.5,-6.2).curveTo(58,-2.8,55.5,0.2).curveTo(54.2,1.7,52.4,2.9).curveTo(51.1,3.8,48.9,4.8).curveTo(44.4,7,37.2,9.2).curveTo(30.3,11.4,21.4,13.5).curveTo(14,15.2,2.8,17.4).curveTo(-2.4,18.6,-7.7,19.5).curveTo(-9.5,19.9,-12.8,20.5).curveTo(-13.1,20.5,-13.5,20.6).curveTo(-16.6,21.2,-17.9,21.4).curveTo(-22.1,22.2,-24.2,22.6).curveTo(-29.1,23.3,-31.7,23.8).curveTo(-34,24.2,-35.7,24.4).curveTo(-37.2,24.7,-38.2,24.9).curveTo(-38.8,25,-39.3,25.1).curveTo(-40.2,25.2,-40.9,25.3).curveTo(-43.6,25.7,-45.1,26).curveTo(-49.7,26.8,-51.9,27.2).curveTo(-54,27.4,-58.1,28.1);
	this.shape_28.setTransform(43.4523,63.6163);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(28.5,-30.2).curveTo(28.3,-28.9,29.1,-27.2).curveTo(30.3,-25.2,32.7,-23.2).curveTo(35.1,-21.2,38.9,-18.8).curveTo(41.1,-17.4,45.3,-14.5).curveTo(47.9,-13,49.2,-11.9).curveTo(51.3,-10.3,52.9,-8.8).curveTo(55.4,-6.4,56.5,-4.1).curveTo(58,-0.7,55.5,2.3).curveTo(54.2,3.8,52.4,5).curveTo(51.1,5.9,48.9,6.9).curveTo(44.4,9.2,37.2,11.4).curveTo(30.3,13.5,21.4,15.7).curveTo(14,17.4,2.8,19.6).curveTo(-2.4,20.7,-7.7,21.7).curveTo(-9.5,22.1,-12.8,22.6).curveTo(-13.1,22.7,-13.5,22.8).curveTo(-16.6,23.3,-17.9,23.6).curveTo(-22.1,24.4,-24.2,24.7).curveTo(-29.1,25.5,-31.7,25.9).curveTo(-34,26.3,-35.7,26.6).curveTo(-37.2,26.9,-38.2,27).curveTo(-38.8,27.1,-39.3,27.2).curveTo(-40.2,27.3,-40.9,27.4).curveTo(-43.6,27.8,-45.1,28.1).curveTo(-49.7,29,-51.9,29.3).curveTo(-54,29.6,-58.1,30.3);
	this.shape_29.setTransform(43.4523,61.4913);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(29.9,-31.5).curveTo(27.5,-29.1,29.1,-25.9).curveTo(30.3,-23.9,32.7,-21.9).curveTo(35.1,-19.9,38.9,-17.5).curveTo(41.1,-16.1,45.3,-13.2).curveTo(47.9,-11.7,49.2,-10.6).curveTo(51.3,-9,52.9,-7.5).curveTo(55.4,-5.1,56.5,-2.8).curveTo(58,0.6,55.5,3.6).curveTo(54.2,5.1,52.4,6.3).curveTo(51.1,7.2,48.9,8.2).curveTo(44.4,10.5,37.2,12.7).curveTo(30.3,14.8,21.4,17).curveTo(14,18.7,2.8,20.9).curveTo(-2.4,22,-7.7,23).curveTo(-9.5,23.4,-12.8,23.9).curveTo(-13.1,24,-13.5,24.1).curveTo(-16.6,24.6,-17.9,24.9).curveTo(-22.1,25.7,-24.2,26).curveTo(-29.1,26.8,-31.7,27.2).curveTo(-34,27.6,-35.7,27.9).curveTo(-37.2,28.2,-38.2,28.3).curveTo(-38.8,28.4,-39.3,28.5).curveTo(-40.2,28.6,-40.9,28.7).curveTo(-43.6,29.1,-45.1,29.4).curveTo(-49.7,30.3,-51.9,30.6).curveTo(-54,30.9,-58.1,31.6);
	this.shape_30.setTransform(43.4523,60.1913);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(32,-32.3).curveTo(30.8,-31.6,29.9,-30.8).curveTo(27.5,-28.4,29.1,-25.2).curveTo(30.3,-23.2,32.7,-21.2).curveTo(35.1,-19.2,38.9,-16.8).curveTo(41.1,-15.4,45.3,-12.5).curveTo(47.9,-11,49.2,-9.9).curveTo(51.3,-8.3,52.9,-6.8).curveTo(55.4,-4.4,56.5,-2.1).curveTo(58,1.3,55.5,4.3).curveTo(54.2,5.8,52.4,7).curveTo(51.1,7.9,48.9,8.9).curveTo(44.4,11.2,37.2,13.4).curveTo(30.3,15.5,21.4,17.7).curveTo(14,19.4,2.8,21.6).curveTo(-2.4,22.7,-7.7,23.7).curveTo(-9.5,24.1,-12.8,24.6).curveTo(-13.1,24.7,-13.5,24.8).curveTo(-16.6,25.3,-17.9,25.6).curveTo(-22.1,26.4,-24.2,26.7).curveTo(-29.1,27.5,-31.7,27.9).curveTo(-34,28.3,-35.7,28.6).curveTo(-37.2,28.9,-38.2,29).curveTo(-38.8,29.1,-39.3,29.2).curveTo(-40.2,29.3,-40.9,29.4).curveTo(-43.6,29.8,-45.1,30.1).curveTo(-49.7,31,-51.9,31.3).curveTo(-54,31.6,-58.1,32.3);
	this.shape_31.setTransform(43.4523,59.4663);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(36.9,-33.2).curveTo(35.7,-32.9,34.7,-32.6).curveTo(31.6,-31.5,29.9,-29.9).curveTo(27.5,-27.5,29.1,-24.3).curveTo(30.3,-22.3,32.7,-20.3).curveTo(35.1,-18.3,38.9,-15.9).curveTo(41.1,-14.5,45.3,-11.6).curveTo(47.9,-10.1,49.2,-9).curveTo(51.3,-7.4,52.9,-5.9).curveTo(55.4,-3.5,56.5,-1.2).curveTo(58,2.2,55.5,5.2).curveTo(54.2,6.7,52.4,7.9).curveTo(51.1,8.8,48.9,9.8).curveTo(44.4,12.1,37.2,14.3).curveTo(30.3,16.4,21.4,18.6).curveTo(14,20.3,2.8,22.5).curveTo(-2.4,23.6,-7.7,24.6).curveTo(-9.5,25,-12.8,25.5).curveTo(-13.1,25.6,-13.5,25.7).curveTo(-16.6,26.2,-17.9,26.5).curveTo(-22.1,27.3,-24.2,27.6).curveTo(-29.1,28.4,-31.7,28.8).curveTo(-34,29.2,-35.7,29.5).curveTo(-37.2,29.8,-38.2,29.9).curveTo(-38.8,30,-39.3,30.1).curveTo(-40.2,30.2,-40.9,30.3).curveTo(-43.6,30.7,-45.1,31).curveTo(-49.7,31.9,-51.9,32.2).curveTo(-54,32.5,-58.1,33.2);
	this.shape_32.setTransform(43.4523,58.5663);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(40.9,-33.6).curveTo(37,-33,34.7,-32.1).curveTo(31.6,-31.1,29.9,-29.5).curveTo(27.5,-27.1,29.1,-23.8).curveTo(30.3,-21.9,32.7,-19.8).curveTo(35.1,-17.9,38.9,-15.4).curveTo(41.1,-14,45.3,-11.2).curveTo(47.9,-9.6,49.2,-8.5).curveTo(51.3,-6.9,52.9,-5.5).curveTo(55.4,-3,56.5,-0.7).curveTo(58,2.7,55.5,5.7).curveTo(54.2,7.2,52.4,8.4).curveTo(51.1,9.3,48.9,10.3).curveTo(44.4,12.5,37.2,14.7).curveTo(30.3,16.9,21.4,19).curveTo(14,20.7,2.8,22.9).curveTo(-2.4,24.1,-7.7,25).curveTo(-9.5,25.4,-12.8,26).curveTo(-13.1,26,-13.5,26.1).curveTo(-16.6,26.7,-17.9,26.9).curveTo(-22.1,27.7,-24.2,28.1).curveTo(-29.1,28.8,-31.7,29.3).curveTo(-34,29.7,-35.7,29.9).curveTo(-37.2,30.2,-38.2,30.4).curveTo(-38.8,30.5,-39.3,30.6).curveTo(-40.2,30.7,-40.9,30.8).curveTo(-43.6,31.2,-45.1,31.5).curveTo(-49.7,32.3,-51.9,32.7).curveTo(-54,32.9,-58.1,33.6);
	this.shape_33.setTransform(43.4523,58.1413);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(45.4,-33.9).curveTo(43.4,-33.6,41.6,-33.4).curveTo(37.2,-32.7,34.7,-31.8).curveTo(31.6,-30.8,29.9,-29.2).curveTo(27.5,-26.8,29.1,-23.5).curveTo(30.3,-21.6,32.7,-19.5).curveTo(35.1,-17.6,38.9,-15.1).curveTo(41.1,-13.7,45.3,-10.9).curveTo(47.9,-9.3,49.2,-8.2).curveTo(51.3,-6.6,52.9,-5.2).curveTo(55.4,-2.7,56.5,-0.4).curveTo(58,3,55.5,6).curveTo(54.2,7.5,52.4,8.7).curveTo(51.1,9.6,48.9,10.6).curveTo(44.4,12.8,37.2,15).curveTo(30.3,17.2,21.4,19.3).curveTo(14,21,2.8,23.2).curveTo(-2.4,24.4,-7.7,25.3).curveTo(-9.5,25.7,-12.8,26.3).curveTo(-13.1,26.3,-13.5,26.4).curveTo(-16.6,27,-17.9,27.2).curveTo(-22.1,28,-24.2,28.4).curveTo(-29.1,29.1,-31.7,29.6).curveTo(-34,30,-35.7,30.2).curveTo(-37.2,30.5,-38.2,30.7).curveTo(-38.8,30.8,-39.3,30.9).curveTo(-40.2,31,-40.9,31.1).curveTo(-43.6,31.5,-45.1,31.8).curveTo(-49.7,32.6,-51.9,33).curveTo(-54,33.2,-58.1,33.9);
	this.shape_34.setTransform(43.4523,57.8413);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(49.8,-34).curveTo(49.6,-34,49.4,-34).curveTo(45.2,-33.8,41.6,-33.3).curveTo(37.2,-32.6,34.7,-31.7).curveTo(31.6,-30.7,29.9,-29.1).curveTo(27.5,-26.7,29.1,-23.4).curveTo(30.3,-21.5,32.7,-19.4).curveTo(35.1,-17.5,38.9,-15).curveTo(41.1,-13.6,45.3,-10.8).curveTo(47.9,-9.2,49.2,-8.1).curveTo(51.3,-6.5,52.9,-5.1).curveTo(55.4,-2.6,56.5,-0.3).curveTo(58,3.1,55.5,6.1).curveTo(54.2,7.6,52.4,8.8).curveTo(51.1,9.7,48.9,10.7).curveTo(44.4,12.9,37.2,15.1).curveTo(30.3,17.3,21.4,19.4).curveTo(14,21.1,2.8,23.3).curveTo(-2.4,24.5,-7.7,25.4).curveTo(-9.5,25.8,-12.8,26.4).curveTo(-13.1,26.4,-13.5,26.5).curveTo(-16.6,27.1,-17.9,27.3).curveTo(-22.1,28.1,-24.2,28.5).curveTo(-29.1,29.2,-31.7,29.7).curveTo(-34,30.1,-35.7,30.3).curveTo(-37.2,30.6,-38.2,30.8).curveTo(-38.8,30.9,-39.3,31).curveTo(-40.2,31.1,-40.9,31.2).curveTo(-43.6,31.6,-45.1,31.9).curveTo(-49.7,32.7,-51.9,33.1).curveTo(-54,33.3,-58.1,34);
	this.shape_35.setTransform(43.4523,57.7163);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(58.8,-33.8).curveTo(57.7,-33.9,57.5,-33.9).curveTo(53.6,-34.1,48.8,-34).curveTo(44.6,-33.8,41,-33.3).curveTo(36.6,-32.6,34.2,-31.7).curveTo(31.1,-30.7,29.3,-29.1).curveTo(26.9,-26.7,28.6,-23.4).curveTo(29.7,-21.5,32.2,-19.4).curveTo(34.6,-17.5,38.4,-15).curveTo(40.5,-13.6,44.8,-10.8).curveTo(47.3,-9.2,48.6,-8.1).curveTo(50.8,-6.5,52.3,-5.1).curveTo(54.9,-2.6,55.9,-0.3).curveTo(57.4,3.1,54.9,6.1).curveTo(53.7,7.6,51.9,8.8).curveTo(50.5,9.7,48.3,10.7).curveTo(43.9,12.9,36.6,15.1).curveTo(29.8,17.3,20.9,19.4).curveTo(13.4,21.1,2.3,23.3).curveTo(-2.9,24.5,-8.3,25.4).curveTo(-10.1,25.8,-13.4,26.4).curveTo(-13.7,26.4,-14,26.5).curveTo(-17.1,27.1,-18.4,27.3).curveTo(-22.7,28.1,-24.8,28.5).curveTo(-29.7,29.2,-32.2,29.7).curveTo(-34.6,30.1,-36.2,30.3).curveTo(-37.8,30.6,-38.8,30.8).curveTo(-39.4,30.9,-39.9,31).curveTo(-40.7,31.1,-41.5,31.2).curveTo(-44.1,31.6,-45.6,31.9).curveTo(-50.2,32.7,-52.5,33.1).curveTo(-54.5,33.3,-58.7,34);
	this.shape_36.setTransform(44.0276,57.71);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(60.2,-33.6).curveTo(59.6,-33.7,59,-33.7).curveTo(55.3,-33.9,54.9,-33.9).curveTo(51,-34.1,46.3,-34).curveTo(42.1,-33.8,38.5,-33.3).curveTo(34.1,-32.6,31.6,-31.7).curveTo(28.5,-30.7,26.8,-29.1).curveTo(24.4,-26.7,26,-23.4).curveTo(27.2,-21.5,29.6,-19.4).curveTo(32,-17.5,35.8,-15).curveTo(38,-13.6,42.2,-10.8).curveTo(44.8,-9.2,46.1,-8.1).curveTo(48.2,-6.5,49.8,-5.1).curveTo(52.3,-2.6,53.4,-0.3).curveTo(54.9,3.1,52.4,6.1).curveTo(51.1,7.6,49.3,8.8).curveTo(48,9.7,45.8,10.7).curveTo(41.3,12.9,34.1,15.1).curveTo(27.2,17.3,18.3,19.4).curveTo(10.9,21.1,-0.3,23.3).curveTo(-5.5,24.5,-10.8,25.4).curveTo(-12.6,25.8,-15.9,26.4).curveTo(-16.2,26.4,-16.6,26.5).curveTo(-19.7,27.1,-21,27.3).curveTo(-25.2,28.1,-27.3,28.5).curveTo(-32.2,29.2,-34.8,29.7).curveTo(-37.1,30.1,-38.8,30.3).curveTo(-40.3,30.6,-41.3,30.8).curveTo(-41.9,30.9,-42.4,31).curveTo(-43.3,31.1,-44,31.2).curveTo(-46.7,31.6,-48.2,31.9).curveTo(-52.8,32.7,-55,33.1).curveTo(-57.1,33.3,-61.2,34);
	this.shape_37.setTransform(46.571,57.71);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(63,-33.3).curveTo(62.1,-33.4,61.4,-33.4).curveTo(59.8,-33.5,57.3,-33.7).curveTo(53.6,-33.9,53.2,-33.9).curveTo(49.3,-34.1,44.5,-34).curveTo(40.3,-33.8,36.7,-33.3).curveTo(32.3,-32.6,29.9,-31.7).curveTo(26.8,-30.7,25,-29.1).curveTo(22.6,-26.7,24.3,-23.4).curveTo(25.4,-21.5,27.9,-19.4).curveTo(30.3,-17.5,34.1,-15).curveTo(36.2,-13.6,40.5,-10.8).curveTo(43,-9.2,44.3,-8.1).curveTo(46.5,-6.5,48,-5.1).curveTo(50.6,-2.6,51.6,-0.3).curveTo(53.1,3.1,50.6,6.1).curveTo(49.4,7.6,47.6,8.8).curveTo(46.2,9.7,44,10.7).curveTo(39.6,12.9,32.3,15.1).curveTo(25.5,17.3,16.6,19.4).curveTo(9.1,21.1,-2,23.3).curveTo(-7.2,24.5,-12.6,25.4).curveTo(-14.4,25.8,-17.7,26.4).curveTo(-18,26.4,-18.3,26.5).curveTo(-21.4,27.1,-22.7,27.3).curveTo(-27,28.1,-29.1,28.5).curveTo(-34,29.2,-36.5,29.7).curveTo(-38.9,30.1,-40.5,30.3).curveTo(-42.1,30.6,-43.1,30.8).curveTo(-43.7,30.9,-44.2,31).curveTo(-45,31.1,-45.8,31.2).curveTo(-48.4,31.6,-49.9,31.9).curveTo(-54.5,32.7,-56.8,33.1).curveTo(-58.8,33.3,-63,34);
	this.shape_38.setTransform(48.3115,57.71);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(65.5,-32.9).curveTo(64.3,-33.1,63.6,-33.2).curveTo(63.5,-33.2,63.4,-33.2).curveTo(60.4,-33.3,58.9,-33.4).curveTo(57.3,-33.5,54.8,-33.7).curveTo(51.1,-33.9,50.7,-33.9).curveTo(46.8,-34.1,42,-34).curveTo(37.8,-33.8,34.2,-33.3).curveTo(29.8,-32.6,27.4,-31.7).curveTo(24.3,-30.7,22.5,-29.1).curveTo(20.1,-26.7,21.8,-23.4).curveTo(22.9,-21.5,25.4,-19.4).curveTo(27.8,-17.5,31.6,-15).curveTo(33.7,-13.6,38,-10.8).curveTo(40.5,-9.2,41.8,-8.1).curveTo(44,-6.5,45.5,-5.1).curveTo(48.1,-2.6,49.1,-0.3).curveTo(50.6,3.1,48.1,6.1).curveTo(46.9,7.6,45.1,8.8).curveTo(43.7,9.7,41.5,10.7).curveTo(37.1,12.9,29.8,15.1).curveTo(23,17.3,14.1,19.4).curveTo(6.6,21.1,-4.5,23.3).curveTo(-9.7,24.5,-15.1,25.4).curveTo(-16.9,25.8,-20.2,26.4).curveTo(-20.5,26.4,-20.8,26.5).curveTo(-23.9,27.1,-25.2,27.3).curveTo(-29.5,28.1,-31.6,28.5).curveTo(-36.5,29.2,-39,29.7).curveTo(-41.4,30.1,-43,30.3).curveTo(-44.6,30.6,-45.6,30.8).curveTo(-46.2,30.9,-46.7,31).curveTo(-47.5,31.1,-48.3,31.2).curveTo(-50.9,31.6,-52.4,31.9).curveTo(-57,32.7,-59.3,33.1).curveTo(-61.3,33.3,-65.5,34);
	this.shape_39.setTransform(50.8205,57.71);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(67.5,-32.6).curveTo(65,-32.7,63.6,-32.9).curveTo(62.4,-33.1,61.7,-33.2).curveTo(58.6,-33.3,57,-33.4).curveTo(55.4,-33.5,52.9,-33.7).curveTo(49.2,-33.9,48.8,-33.9).curveTo(44.9,-34.1,40.1,-34).curveTo(35.9,-33.8,32.3,-33.3).curveTo(27.9,-32.6,25.5,-31.7).curveTo(22.4,-30.7,20.6,-29.1).curveTo(18.2,-26.7,19.9,-23.4).curveTo(21,-21.5,23.5,-19.4).curveTo(25.9,-17.5,29.7,-15).curveTo(31.8,-13.6,36.1,-10.8).curveTo(38.6,-9.2,39.9,-8.1).curveTo(42.1,-6.5,43.6,-5.1).curveTo(46.2,-2.6,47.2,-0.3).curveTo(48.7,3.1,46.2,6.1).curveTo(45,7.6,43.2,8.8).curveTo(41.8,9.7,39.6,10.7).curveTo(35.2,12.9,27.9,15.1).curveTo(21.1,17.3,12.2,19.4).curveTo(4.7,21.1,-6.4,23.3).curveTo(-11.6,24.5,-17,25.4).curveTo(-18.8,25.8,-22.1,26.4).curveTo(-22.4,26.4,-22.7,26.5).curveTo(-25.8,27.1,-27.1,27.3).curveTo(-31.4,28.1,-33.5,28.5).curveTo(-38.4,29.2,-40.9,29.7).curveTo(-43.3,30.1,-44.9,30.3).curveTo(-46.5,30.6,-47.5,30.8).curveTo(-48.1,30.9,-48.6,31).curveTo(-49.4,31.1,-50.2,31.2).curveTo(-52.8,31.6,-54.3,31.9).curveTo(-58.9,32.7,-61.2,33.1).curveTo(-63.2,33.3,-67.4,34);
	this.shape_40.setTransform(52.7327,57.71);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(69.7,-32.2).lineTo(65.9,-32.5).curveTo(62.9,-32.7,61.4,-32.9).curveTo(60.2,-33.1,59.5,-33.2).curveTo(56.4,-33.3,54.8,-33.4).curveTo(53.2,-33.5,50.7,-33.7).curveTo(47,-33.9,46.6,-33.9).curveTo(42.7,-34.1,37.9,-34).curveTo(33.7,-33.8,30.1,-33.3).curveTo(25.7,-32.6,23.3,-31.7).curveTo(20.2,-30.7,18.4,-29.1).curveTo(16,-26.7,17.7,-23.4).curveTo(18.8,-21.5,21.3,-19.4).curveTo(23.7,-17.5,27.5,-15).curveTo(29.6,-13.6,33.9,-10.8).curveTo(36.4,-9.2,37.7,-8.1).curveTo(39.9,-6.5,41.4,-5.1).curveTo(44,-2.6,45,-0.3).curveTo(46.5,3.1,44,6.1).curveTo(42.8,7.6,41,8.8).curveTo(39.6,9.7,37.4,10.7).curveTo(33,12.9,25.7,15.1).curveTo(18.9,17.3,10,19.4).curveTo(2.5,21.1,-8.6,23.3).curveTo(-13.8,24.5,-19.2,25.4).curveTo(-21,25.8,-24.3,26.4).curveTo(-24.6,26.4,-24.9,26.5).curveTo(-28,27.1,-29.3,27.3).curveTo(-33.6,28.1,-35.7,28.5).curveTo(-40.6,29.2,-43.1,29.7).curveTo(-45.5,30.1,-47.1,30.3).curveTo(-48.7,30.6,-49.7,30.8).curveTo(-50.3,30.9,-50.8,31).curveTo(-51.6,31.1,-52.4,31.2).curveTo(-55,31.6,-56.5,31.9).curveTo(-61.1,32.7,-63.4,33.1).curveTo(-65.4,33.3,-69.6,34);
	this.shape_41.setTransform(54.9202,57.71);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(71.8,-31.7).lineTo(63.7,-32.5).curveTo(60.8,-32.7,59.3,-32.9).curveTo(58,-33.1,57.3,-33.2).curveTo(54.3,-33.3,52.7,-33.4).curveTo(51.1,-33.5,48.5,-33.7).curveTo(44.8,-33.9,44.4,-33.9).curveTo(40.5,-34.1,35.8,-34).curveTo(31.6,-33.8,28,-33.3).curveTo(23.6,-32.6,21.1,-31.7).curveTo(18,-30.7,16.3,-29.1).curveTo(13.9,-26.7,15.5,-23.4).curveTo(16.7,-21.5,19.1,-19.4).curveTo(21.5,-17.5,25.3,-15).curveTo(27.5,-13.6,31.7,-10.8).curveTo(34.3,-9.2,35.6,-8.1).curveTo(37.7,-6.5,39.3,-5.1).curveTo(41.8,-2.6,42.9,-0.3).curveTo(44.4,3.1,41.9,6.1).curveTo(40.6,7.6,38.8,8.8).curveTo(37.5,9.7,35.3,10.7).curveTo(30.8,12.9,23.6,15.1).curveTo(16.7,17.3,7.8,19.4).curveTo(0.4,21.1,-10.8,23.3).curveTo(-16,24.5,-21.3,25.4).curveTo(-23.1,25.8,-26.4,26.4).curveTo(-26.7,26.4,-27.1,26.5).curveTo(-30.2,27.1,-31.5,27.3).curveTo(-35.7,28.1,-37.8,28.5).curveTo(-42.7,29.2,-45.3,29.7).curveTo(-47.6,30.1,-49.3,30.3).curveTo(-50.8,30.6,-51.8,30.8).curveTo(-52.4,30.9,-52.9,31).curveTo(-53.8,31.1,-54.5,31.2).curveTo(-57.2,31.6,-58.7,31.9).curveTo(-63.3,32.7,-65.5,33.1).curveTo(-67.6,33.3,-71.7,34);
	this.shape_42.setTransform(57.0825,57.71);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(74.5,-31.1).lineTo(61,-32.5).curveTo(58.1,-32.7,56.6,-32.9).curveTo(55.3,-33.1,54.6,-33.2).curveTo(51.6,-33.3,50,-33.4).curveTo(48.4,-33.5,45.8,-33.7).curveTo(42.1,-33.9,41.7,-33.9).curveTo(37.8,-34.1,33.1,-34).curveTo(28.9,-33.8,25.3,-33.3).curveTo(20.9,-32.6,18.4,-31.7).curveTo(15.3,-30.7,13.6,-29.1).curveTo(11.2,-26.7,12.8,-23.4).curveTo(14,-21.5,16.4,-19.4).curveTo(18.8,-17.5,22.6,-15).curveTo(24.8,-13.6,29,-10.8).curveTo(31.6,-9.2,32.9,-8.1).curveTo(35,-6.5,36.6,-5.1).curveTo(39.1,-2.6,40.2,-0.3).curveTo(41.7,3.1,39.2,6.1).curveTo(37.9,7.6,36.1,8.8).curveTo(34.8,9.7,32.6,10.7).curveTo(28.1,12.9,20.9,15.1).curveTo(14,17.3,5.1,19.4).curveTo(-2.3,21.1,-13.5,23.3).curveTo(-18.7,24.5,-24,25.4).curveTo(-25.8,25.8,-29.1,26.4).curveTo(-29.4,26.4,-29.8,26.5).curveTo(-32.9,27.1,-34.2,27.3).curveTo(-38.4,28.1,-40.5,28.5).curveTo(-45.4,29.2,-48,29.7).curveTo(-50.3,30.1,-52,30.3).curveTo(-53.5,30.6,-54.5,30.8).curveTo(-55.1,30.9,-55.6,31).curveTo(-56.5,31.1,-57.2,31.2).curveTo(-59.9,31.6,-61.4,31.9).curveTo(-66,32.7,-68.2,33.1).curveTo(-70.3,33.3,-74.4,34);
	this.shape_43.setTransform(59.7585,57.71);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(76.6,-30.8).curveTo(74.5,-31,73.4,-31.1).lineTo(58.9,-32.5).curveTo(56,-32.7,54.5,-32.9).curveTo(53.2,-33.1,52.5,-33.2).curveTo(49.5,-33.3,47.9,-33.4).curveTo(46.3,-33.5,43.7,-33.7).curveTo(40,-33.9,39.6,-33.9).curveTo(35.7,-34.1,31,-34).curveTo(26.8,-33.8,23.2,-33.3).curveTo(18.8,-32.6,16.3,-31.7).curveTo(13.2,-30.7,11.5,-29.1).curveTo(9.1,-26.7,10.7,-23.4).curveTo(11.9,-21.5,14.3,-19.4).curveTo(16.7,-17.5,20.5,-15).curveTo(22.7,-13.6,26.9,-10.8).curveTo(29.5,-9.2,30.8,-8.1).curveTo(32.9,-6.5,34.5,-5.1).curveTo(37,-2.6,38.1,-0.3).curveTo(39.6,3.1,37.1,6.1).curveTo(35.8,7.6,34,8.8).curveTo(32.7,9.7,30.5,10.7).curveTo(26,12.9,18.8,15.1).curveTo(11.9,17.3,3,19.4).curveTo(-4.4,21.1,-15.6,23.3).curveTo(-20.8,24.5,-26.1,25.4).curveTo(-27.9,25.8,-31.2,26.4).curveTo(-31.5,26.4,-31.9,26.5).curveTo(-35,27.1,-36.3,27.3).curveTo(-40.5,28.1,-42.6,28.5).curveTo(-47.5,29.2,-50.1,29.7).curveTo(-52.4,30.1,-54.1,30.3).curveTo(-55.6,30.6,-56.6,30.8).curveTo(-57.2,30.9,-57.7,31).curveTo(-58.6,31.1,-59.3,31.2).curveTo(-62,31.6,-63.5,31.9).curveTo(-68.1,32.7,-70.3,33.1).curveTo(-72.4,33.3,-76.5,34);
	this.shape_44.setTransform(61.8803,57.71);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(81.3,-29.9).lineTo(80.1,-30).curveTo(79.5,-30.1,76.1,-30.3).curveTo(73.6,-30.5,72.2,-30.8).curveTo(69.8,-31,68.7,-31.1).lineTo(54.2,-32.5).curveTo(51.3,-32.7,49.8,-32.9).curveTo(48.5,-33.1,47.8,-33.2).curveTo(44.8,-33.3,43.2,-33.4).curveTo(41.6,-33.5,39,-33.7).curveTo(35.3,-33.9,34.9,-33.9).curveTo(31,-34.1,26.3,-34).curveTo(22.1,-33.8,18.5,-33.3).curveTo(14.1,-32.6,11.6,-31.7).curveTo(8.5,-30.7,6.8,-29.1).curveTo(4.4,-26.7,6,-23.4).curveTo(7.2,-21.5,9.6,-19.4).curveTo(12,-17.5,15.8,-15).curveTo(18,-13.6,22.2,-10.8).curveTo(24.8,-9.2,26.1,-8.1).curveTo(28.2,-6.5,29.8,-5.1).curveTo(32.3,-2.6,33.4,-0.3).curveTo(34.9,3.1,32.4,6.1).curveTo(31.1,7.6,29.3,8.8).curveTo(28,9.7,25.8,10.7).curveTo(21.3,12.9,14.1,15.1).curveTo(7.2,17.3,-1.7,19.4).curveTo(-9.1,21.1,-20.3,23.3).curveTo(-25.5,24.5,-30.8,25.4).curveTo(-32.6,25.8,-35.9,26.4).curveTo(-36.2,26.4,-36.6,26.5).curveTo(-39.7,27.1,-41,27.3).curveTo(-45.2,28.1,-47.3,28.5).curveTo(-52.2,29.2,-54.8,29.7).curveTo(-57.1,30.1,-58.8,30.3).curveTo(-60.3,30.6,-61.3,30.8).curveTo(-61.9,30.9,-62.4,31).curveTo(-63.3,31.1,-64,31.2).curveTo(-66.7,31.6,-68.2,31.9).curveTo(-72.8,32.7,-75,33.1).curveTo(-77.1,33.3,-81.2,34);
	this.shape_45.setTransform(66.5769,57.71);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(83.1,-29.5).curveTo(82.7,-29.5,82.4,-29.5).lineTo(78,-30).curveTo(77.3,-30.1,73.9,-30.3).curveTo(71.4,-30.5,70.1,-30.8).curveTo(67.7,-31,66.6,-31.1).lineTo(52.1,-32.5).curveTo(49.1,-32.7,47.6,-32.9).curveTo(46.4,-33.1,45.7,-33.2).curveTo(42.6,-33.3,41,-33.4).curveTo(39.4,-33.5,36.9,-33.7).curveTo(33.2,-33.9,32.8,-33.9).curveTo(28.9,-34.1,24.1,-34).curveTo(19.9,-33.8,16.3,-33.3).curveTo(11.9,-32.6,9.5,-31.7).curveTo(6.4,-30.7,4.6,-29.1).curveTo(2.2,-26.7,3.9,-23.4).curveTo(5,-21.5,7.5,-19.4).curveTo(9.9,-17.5,13.7,-15).curveTo(15.8,-13.6,20.1,-10.8).curveTo(22.6,-9.2,23.9,-8.1).curveTo(26.1,-6.5,27.6,-5.1).curveTo(30.2,-2.6,31.2,-0.3).curveTo(32.7,3.1,30.2,6.1).curveTo(29,7.6,27.2,8.8).curveTo(25.8,9.7,23.6,10.7).curveTo(19.2,12.9,11.9,15.1).curveTo(5.1,17.3,-3.8,19.4).curveTo(-11.3,21.1,-22.4,23.3).curveTo(-27.6,24.5,-33,25.4).curveTo(-34.8,25.8,-38.1,26.4).curveTo(-38.4,26.4,-38.7,26.5).curveTo(-41.8,27.1,-43.1,27.3).curveTo(-47.4,28.1,-49.5,28.5).curveTo(-54.4,29.2,-56.9,29.7).curveTo(-59.3,30.1,-60.9,30.3).curveTo(-62.5,30.6,-63.5,30.8).curveTo(-64.1,30.9,-64.6,31).curveTo(-65.4,31.1,-66.2,31.2).curveTo(-68.8,31.6,-70.3,31.9).curveTo(-74.9,32.7,-77.2,33.1).curveTo(-79.2,33.3,-83.4,34);
	this.shape_46.setTransform(68.746,57.71);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(85.3,-29.1).curveTo(84.1,-29.2,82.8,-29.3).curveTo(80.5,-29.5,79.4,-29.5).lineTo(75,-30).curveTo(74.3,-30.1,70.9,-30.3).curveTo(68.4,-30.5,67.1,-30.8).curveTo(64.7,-31,63.6,-31.1).lineTo(49.1,-32.5).curveTo(46.1,-32.7,44.6,-32.9).curveTo(43.4,-33.1,42.7,-33.2).curveTo(39.6,-33.3,38,-33.4).curveTo(36.4,-33.5,33.9,-33.7).curveTo(30.2,-33.9,29.8,-33.9).curveTo(25.9,-34.1,21.1,-34).curveTo(16.9,-33.8,13.3,-33.3).curveTo(8.9,-32.6,6.5,-31.7).curveTo(3.4,-30.7,1.6,-29.1).curveTo(-0.8,-26.7,0.9,-23.4).curveTo(2,-21.5,4.5,-19.4).curveTo(6.9,-17.5,10.7,-15).curveTo(12.8,-13.6,17.1,-10.8).curveTo(19.6,-9.2,20.9,-8.1).curveTo(23.1,-6.5,24.6,-5.1).curveTo(27.2,-2.6,28.2,-0.3).curveTo(29.7,3.1,27.2,6.1).curveTo(26,7.6,24.2,8.8).curveTo(22.8,9.7,20.6,10.7).curveTo(16.2,12.9,8.9,15.1).curveTo(2.1,17.3,-6.8,19.4).curveTo(-14.3,21.1,-25.4,23.3).curveTo(-30.6,24.5,-36,25.4).curveTo(-37.8,25.8,-41.1,26.4).curveTo(-41.4,26.4,-41.7,26.5).curveTo(-44.8,27.1,-46.1,27.3).curveTo(-50.4,28.1,-52.5,28.5).curveTo(-57.4,29.2,-59.9,29.7).curveTo(-62.3,30.1,-63.9,30.3).curveTo(-65.5,30.6,-66.5,30.8).curveTo(-67.1,30.9,-67.6,31).curveTo(-68.4,31.1,-69.2,31.2).curveTo(-71.8,31.6,-73.3,31.9).curveTo(-77.9,32.7,-80.2,33.1).curveTo(-82.2,33.3,-86.4,34);
	this.shape_47.setTransform(71.721,57.71);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(87.3,-29).curveTo(84.2,-29.1,80.8,-29.3).curveTo(78.5,-29.5,77.4,-29.5).lineTo(73,-30).curveTo(72.3,-30.1,68.9,-30.3).curveTo(66.4,-30.5,65.1,-30.8).curveTo(62.7,-31,61.6,-31.1).lineTo(47.1,-32.5).curveTo(44.1,-32.7,42.6,-32.9).curveTo(41.4,-33.1,40.7,-33.2).curveTo(37.6,-33.3,36,-33.4).curveTo(34.4,-33.5,31.9,-33.7).curveTo(28.2,-33.9,27.8,-33.9).curveTo(23.9,-34.1,19.1,-34).curveTo(14.9,-33.8,11.3,-33.3).curveTo(6.9,-32.6,4.5,-31.7).curveTo(1.4,-30.7,-0.4,-29.1).curveTo(-2.8,-26.7,-1.1,-23.4).curveTo(0,-21.5,2.5,-19.4).curveTo(4.9,-17.5,8.7,-15).curveTo(10.8,-13.6,15.1,-10.8).curveTo(17.6,-9.2,18.9,-8.1).curveTo(21.1,-6.5,22.6,-5.1).curveTo(25.2,-2.6,26.2,-0.3).curveTo(27.7,3.1,25.2,6.1).curveTo(24,7.6,22.2,8.8).curveTo(20.8,9.7,18.6,10.7).curveTo(14.2,12.9,6.9,15.1).curveTo(0.1,17.3,-8.8,19.4).curveTo(-16.3,21.1,-27.4,23.3).curveTo(-32.6,24.5,-38,25.4).curveTo(-39.8,25.8,-43.1,26.4).curveTo(-43.4,26.4,-43.7,26.5).curveTo(-46.8,27.1,-48.1,27.3).curveTo(-52.4,28.1,-54.5,28.5).curveTo(-59.4,29.2,-61.9,29.7).curveTo(-64.3,30.1,-65.9,30.3).curveTo(-67.5,30.6,-68.5,30.8).curveTo(-69.1,30.9,-69.6,31).curveTo(-70.4,31.1,-71.2,31.2).curveTo(-73.8,31.6,-75.3,31.9).curveTo(-79.9,32.7,-82.2,33.1).curveTo(-84.2,33.3,-88.4,34);
	this.shape_48.setTransform(73.721,57.71);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(89.8,-28.9).curveTo(88.6,-28.9,86.5,-29).curveTo(82.8,-29.1,78.3,-29.3).curveTo(76.1,-29.5,74.9,-29.5).lineTo(70.5,-30).curveTo(69.9,-30.1,66.5,-30.3).curveTo(64,-30.5,62.6,-30.8).curveTo(60.2,-31,59.1,-31.1).lineTo(44.6,-32.5).curveTo(41.7,-32.7,40.2,-32.9).curveTo(38.9,-33.1,38.2,-33.2).curveTo(35.2,-33.3,33.6,-33.4).curveTo(32,-33.5,29.4,-33.7).curveTo(25.7,-33.9,25.3,-33.9).curveTo(21.4,-34.1,16.7,-34).curveTo(12.5,-33.8,8.9,-33.3).curveTo(4.5,-32.6,2,-31.7).curveTo(-1.1,-30.7,-2.8,-29.1).curveTo(-5.2,-26.7,-3.6,-23.4).curveTo(-2.4,-21.5,0,-19.4).curveTo(2.4,-17.5,6.2,-15).curveTo(8.4,-13.6,12.6,-10.8).curveTo(15.2,-9.2,16.5,-8.1).curveTo(18.6,-6.5,20.2,-5.1).curveTo(22.7,-2.6,23.8,-0.3).curveTo(25.3,3.1,22.8,6.1).curveTo(21.5,7.6,19.7,8.8).curveTo(18.4,9.7,16.2,10.7).curveTo(11.7,12.9,4.5,15.1).curveTo(-2.4,17.3,-11.3,19.4).curveTo(-18.7,21.1,-29.9,23.3).curveTo(-35.1,24.5,-40.4,25.4).curveTo(-42.2,25.8,-45.5,26.4).curveTo(-45.8,26.4,-46.2,26.5).curveTo(-49.3,27.1,-50.6,27.3).curveTo(-54.8,28.1,-56.9,28.5).curveTo(-61.8,29.2,-64.4,29.7).curveTo(-66.7,30.1,-68.4,30.3).curveTo(-69.9,30.6,-70.9,30.8).curveTo(-71.5,30.9,-72,31).curveTo(-72.9,31.1,-73.6,31.2).curveTo(-76.3,31.6,-77.8,31.9).curveTo(-82.4,32.7,-84.6,33.1).curveTo(-86.7,33.3,-90.8,34);
	this.shape_49.setTransform(76.171,57.71);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(92.3,-29.1).curveTo(90.4,-28.9,88.2,-28.9).curveTo(87,-28.9,84.1,-29).curveTo(80.3,-29.1,75.9,-29.3).curveTo(73.6,-29.5,72.5,-29.5).lineTo(68.1,-30).curveTo(67.4,-30.1,64,-30.3).curveTo(61.5,-30.5,60.2,-30.8).curveTo(57.8,-31,56.7,-31.1).lineTo(42.2,-32.5).curveTo(39.2,-32.7,37.7,-32.9).curveTo(36.5,-33.1,35.8,-33.2).curveTo(32.7,-33.3,31.1,-33.4).curveTo(29.5,-33.5,27,-33.7).curveTo(23.3,-33.9,22.9,-33.9).curveTo(19,-34.1,14.2,-34).curveTo(10,-33.8,6.4,-33.3).curveTo(2,-32.6,-0.4,-31.7).curveTo(-3.5,-30.7,-5.3,-29.1).curveTo(-7.7,-26.7,-6,-23.4).curveTo(-4.9,-21.5,-2.4,-19.4).curveTo(-0,-17.5,3.8,-15).curveTo(5.9,-13.6,10.2,-10.8).curveTo(12.7,-9.2,14,-8.1).curveTo(16.2,-6.5,17.7,-5.1).curveTo(20.3,-2.6,21.3,-0.3).curveTo(22.8,3.1,20.3,6.1).curveTo(19.1,7.6,17.3,8.8).curveTo(15.9,9.7,13.7,10.7).curveTo(9.3,12.9,2,15.1).curveTo(-4.8,17.3,-13.7,19.4).curveTo(-21.2,21.1,-32.3,23.3).curveTo(-37.5,24.5,-42.9,25.4).curveTo(-44.7,25.8,-48,26.4).curveTo(-48.3,26.4,-48.6,26.5).curveTo(-51.7,27.1,-53,27.3).curveTo(-57.3,28.1,-59.4,28.5).curveTo(-64.3,29.2,-66.8,29.7).curveTo(-69.2,30.1,-70.8,30.3).curveTo(-72.4,30.6,-73.4,30.8).curveTo(-74,30.9,-74.5,31).curveTo(-75.3,31.1,-76.1,31.2).curveTo(-78.7,31.6,-80.2,31.9).curveTo(-84.8,32.7,-87.1,33.1).curveTo(-89.1,33.3,-93.3,34);
	this.shape_50.setTransform(78.646,57.71);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(94.3,-29.3).curveTo(93.5,-29.3,92.3,-29.2).curveTo(90.8,-29.1,90.2,-29.1).curveTo(88.4,-28.9,86.2,-28.9).curveTo(85,-28.9,82,-29).curveTo(78.3,-29.1,73.8,-29.3).curveTo(71.6,-29.5,70.4,-29.5).lineTo(66,-30).curveTo(65.4,-30.1,62,-30.3).curveTo(59.5,-30.5,58.1,-30.8).curveTo(55.7,-31,54.6,-31.1).lineTo(40.1,-32.5).curveTo(37.2,-32.7,35.7,-32.9).curveTo(34.4,-33.1,33.7,-33.2).curveTo(30.7,-33.3,29.1,-33.4).curveTo(27.5,-33.5,24.9,-33.7).curveTo(21.2,-33.9,20.8,-33.9).curveTo(16.9,-34.1,12.2,-34).curveTo(8,-33.8,4.4,-33.3).curveTo(-0,-32.6,-2.5,-31.7).curveTo(-5.6,-30.7,-7.3,-29.1).curveTo(-9.7,-26.7,-8.1,-23.4).curveTo(-6.9,-21.5,-4.5,-19.4).curveTo(-2.1,-17.5,1.7,-15).curveTo(3.9,-13.6,8.1,-10.8).curveTo(10.7,-9.2,12,-8.1).curveTo(14.1,-6.5,15.7,-5.1).curveTo(18.2,-2.6,19.3,-0.3).curveTo(20.8,3.1,18.3,6.1).curveTo(17,7.6,15.2,8.8).curveTo(13.9,9.7,11.7,10.7).curveTo(7.2,12.9,-0,15.1).curveTo(-6.9,17.3,-15.8,19.4).curveTo(-23.2,21.1,-34.4,23.3).curveTo(-39.6,24.5,-44.9,25.4).curveTo(-46.7,25.8,-50,26.4).curveTo(-50.3,26.4,-50.7,26.5).curveTo(-53.8,27.1,-55.1,27.3).curveTo(-59.3,28.1,-61.4,28.5).curveTo(-66.3,29.2,-68.9,29.7).curveTo(-71.2,30.1,-72.9,30.3).curveTo(-74.4,30.6,-75.4,30.8).curveTo(-76,30.9,-76.5,31).curveTo(-77.4,31.1,-78.1,31.2).curveTo(-80.8,31.6,-82.3,31.9).curveTo(-86.9,32.7,-89.1,33.1).curveTo(-91.2,33.3,-95.3,34);
	this.shape_51.setTransform(80.671,57.71);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(96.5,-30.1).curveTo(94.7,-29.8,92.2,-29.4).curveTo(91.4,-29.3,90.1,-29.2).curveTo(88.6,-29.1,88,-29.1).curveTo(86.2,-28.9,84,-28.9).curveTo(82.8,-28.9,79.8,-29).curveTo(76.1,-29.1,71.6,-29.3).curveTo(69.4,-29.5,68.2,-29.5).lineTo(63.8,-30).curveTo(63.2,-30.1,59.8,-30.3).curveTo(57.3,-30.5,55.9,-30.8).curveTo(53.5,-31,52.4,-31.1).lineTo(37.9,-32.5).curveTo(35,-32.7,33.5,-32.9).curveTo(32.2,-33.1,31.5,-33.2).curveTo(28.5,-33.3,26.9,-33.4).curveTo(25.3,-33.5,22.7,-33.7).curveTo(19,-33.9,18.6,-33.9).curveTo(14.7,-34.1,10,-34).curveTo(5.8,-33.8,2.2,-33.3).curveTo(-2.2,-32.6,-4.7,-31.7).curveTo(-7.8,-30.7,-9.5,-29.1).curveTo(-11.9,-26.7,-10.3,-23.4).curveTo(-9.1,-21.5,-6.7,-19.4).curveTo(-4.3,-17.5,-0.5,-15).curveTo(1.7,-13.6,5.9,-10.8).curveTo(8.5,-9.2,9.8,-8.1).curveTo(11.9,-6.5,13.5,-5.1).curveTo(16,-2.6,17.1,-0.3).curveTo(18.6,3.1,16.1,6.1).curveTo(14.8,7.6,13,8.8).curveTo(11.7,9.7,9.5,10.7).curveTo(5,12.9,-2.2,15.1).curveTo(-9.1,17.3,-18,19.4).curveTo(-25.4,21.1,-36.6,23.3).curveTo(-41.8,24.5,-47.1,25.4).curveTo(-48.9,25.8,-52.2,26.4).curveTo(-52.5,26.4,-52.9,26.5).curveTo(-56,27.1,-57.3,27.3).curveTo(-61.5,28.1,-63.6,28.5).curveTo(-68.5,29.2,-71.1,29.7).curveTo(-73.4,30.1,-75.1,30.3).curveTo(-76.6,30.6,-77.6,30.8).curveTo(-78.2,30.9,-78.7,31).curveTo(-79.6,31.1,-80.3,31.2).curveTo(-83,31.6,-84.5,31.9).curveTo(-89.1,32.7,-91.3,33.1).curveTo(-93.4,33.3,-97.5,34);
	this.shape_52.setTransform(82.871,57.71);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(98.9,-31.4).curveTo(98.7,-31.3,98.3,-31.2).curveTo(97,-30.8,95.5,-30.4).curveTo(93.4,-29.9,89.7,-29.4).curveTo(89,-29.3,87.7,-29.2).curveTo(86.1,-29.1,85.6,-29.1).curveTo(83.7,-28.9,81.5,-28.9).curveTo(80.3,-28.9,77.4,-29).curveTo(73.6,-29.1,69.2,-29.3).curveTo(66.9,-29.5,65.8,-29.5).lineTo(61.4,-30).curveTo(60.7,-30.1,57.3,-30.3).curveTo(54.8,-30.5,53.5,-30.8).curveTo(51.1,-31,50,-31.1).lineTo(35.5,-32.5).curveTo(32.5,-32.7,31,-32.9).curveTo(29.8,-33.1,29.1,-33.2).curveTo(26,-33.3,24.4,-33.4).curveTo(22.8,-33.5,20.3,-33.7).curveTo(16.6,-33.9,16.2,-33.9).curveTo(12.3,-34.1,7.5,-34).curveTo(3.3,-33.8,-0.3,-33.3).curveTo(-4.7,-32.6,-7.1,-31.7).curveTo(-10.2,-30.7,-12,-29.1).curveTo(-14.4,-26.7,-12.7,-23.4).curveTo(-11.6,-21.5,-9.1,-19.4).curveTo(-6.7,-17.5,-2.9,-15).curveTo(-0.8,-13.6,3.5,-10.8).curveTo(6,-9.2,7.3,-8.1).curveTo(9.5,-6.5,11,-5.1).curveTo(13.6,-2.6,14.6,-0.3).curveTo(16.1,3.1,13.6,6.1).curveTo(12.4,7.6,10.6,8.8).curveTo(9.2,9.7,7,10.7).curveTo(2.6,12.9,-4.7,15.1).curveTo(-11.5,17.3,-20.4,19.4).curveTo(-27.9,21.1,-39,23.3).curveTo(-44.2,24.5,-49.6,25.4).curveTo(-51.4,25.8,-54.7,26.4).curveTo(-55,26.4,-55.3,26.5).curveTo(-58.4,27.1,-59.7,27.3).curveTo(-64,28.1,-66.1,28.5).curveTo(-71,29.2,-73.5,29.7).curveTo(-75.9,30.1,-77.5,30.3).curveTo(-79.1,30.6,-80.1,30.8).curveTo(-80.7,30.9,-81.2,31).curveTo(-82,31.1,-82.8,31.2).curveTo(-85.4,31.6,-86.9,31.9).curveTo(-91.5,32.7,-93.8,33.1).curveTo(-95.8,33.3,-100,34);
	this.shape_53.setTransform(85.321,57.71);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(101,-33.1).curveTo(98.8,-32,96.3,-31.2).curveTo(94.9,-30.8,93.5,-30.4).curveTo(91.4,-29.9,87.7,-29.4).curveTo(86.9,-29.3,85.6,-29.2).curveTo(84.1,-29.1,83.5,-29.1).curveTo(81.7,-28.9,79.5,-28.9).curveTo(78.3,-28.9,75.3,-29).curveTo(71.6,-29.1,67.1,-29.3).curveTo(64.9,-29.5,63.7,-29.5).lineTo(59.3,-30).curveTo(58.7,-30.1,55.3,-30.3).curveTo(52.8,-30.5,51.4,-30.8).curveTo(49,-31,47.9,-31.1).lineTo(33.4,-32.5).curveTo(30.5,-32.7,29,-32.9).curveTo(27.7,-33.1,27,-33.2).curveTo(24,-33.3,22.4,-33.4).curveTo(20.8,-33.5,18.2,-33.7).curveTo(14.5,-33.9,14.1,-33.9).curveTo(10.2,-34.1,5.5,-34).curveTo(1.3,-33.8,-2.3,-33.3).curveTo(-6.7,-32.6,-9.2,-31.7).curveTo(-12.3,-30.7,-14,-29.1).curveTo(-16.4,-26.7,-14.8,-23.4).curveTo(-13.6,-21.5,-11.2,-19.4).curveTo(-8.8,-17.5,-5,-15).curveTo(-2.8,-13.6,1.4,-10.8).curveTo(4,-9.2,5.3,-8.1).curveTo(7.4,-6.5,9,-5.1).curveTo(11.5,-2.6,12.6,-0.3).curveTo(14.1,3.1,11.6,6.1).curveTo(10.3,7.6,8.5,8.8).curveTo(7.2,9.7,5,10.7).curveTo(0.5,12.9,-6.7,15.1).curveTo(-13.6,17.3,-22.5,19.4).curveTo(-29.9,21.1,-41.1,23.3).curveTo(-46.3,24.5,-51.6,25.4).curveTo(-53.4,25.8,-56.7,26.4).curveTo(-57,26.4,-57.4,26.5).curveTo(-60.5,27.1,-61.8,27.3).curveTo(-66,28.1,-68.1,28.5).curveTo(-73,29.2,-75.6,29.7).curveTo(-77.9,30.1,-79.6,30.3).curveTo(-81.1,30.6,-82.1,30.8).curveTo(-82.7,30.9,-83.2,31).curveTo(-84.1,31.1,-84.8,31.2).curveTo(-87.5,31.6,-89,31.9).curveTo(-93.6,32.7,-95.8,33.1).curveTo(-97.9,33.3,-102,34);
	this.shape_54.setTransform(87.371,57.71);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(102.7,-34.6).curveTo(102.6,-34.5,102.4,-34.3).curveTo(99,-32.1,94.5,-30.6).curveTo(93.2,-30.2,91.7,-29.9).curveTo(89.6,-29.4,85.9,-28.9).curveTo(85.2,-28.8,83.9,-28.7).curveTo(82.3,-28.6,81.8,-28.6).curveTo(79.9,-28.4,77.7,-28.4).curveTo(76.5,-28.4,73.6,-28.5).curveTo(69.8,-28.5,65.4,-28.8).curveTo(63.1,-28.9,62,-29).lineTo(57.6,-29.5).curveTo(56.9,-29.5,53.5,-29.7).curveTo(51,-30,49.7,-30.2).curveTo(47.3,-30.4,46.2,-30.5).lineTo(31.7,-31.9).curveTo(28.7,-32.2,27.2,-32.4).curveTo(26,-32.5,25.3,-32.6).curveTo(22.2,-32.7,20.6,-32.9).curveTo(19,-33,16.5,-33.1).curveTo(12.8,-33.4,12.4,-33.4).curveTo(8.5,-33.5,3.7,-33.5).curveTo(-0.5,-33.3,-4.1,-32.7).curveTo(-8.5,-32.1,-10.9,-31.2).curveTo(-14,-30.1,-15.8,-28.5).curveTo(-18.2,-26.1,-16.5,-22.9).curveTo(-15.4,-20.9,-12.9,-18.9).curveTo(-10.5,-16.9,-6.7,-14.5).curveTo(-4.6,-13.1,-0.3,-10.2).curveTo(2.2,-8.7,3.5,-7.6).curveTo(5.7,-6,7.2,-4.5).curveTo(9.8,-2.1,10.8,0.2).curveTo(12.3,3.6,9.8,6.6).curveTo(8.6,8.1,6.8,9.3).curveTo(5.4,10.2,3.2,11.2).curveTo(-1.2,13.5,-8.5,15.7).curveTo(-15.3,17.8,-24.2,20).curveTo(-31.7,21.7,-42.8,23.9).curveTo(-48,25,-53.4,26).curveTo(-55.2,26.4,-58.5,26.9).curveTo(-58.8,27,-59.1,27.1).curveTo(-62.2,27.6,-63.5,27.9).curveTo(-67.8,28.7,-69.9,29).curveTo(-74.8,29.8,-77.3,30.2).curveTo(-79.7,30.6,-81.3,30.9).curveTo(-82.9,31.2,-83.9,31.3).curveTo(-84.5,31.4,-85,31.5).curveTo(-85.8,31.6,-86.6,31.7).curveTo(-89.2,32.1,-90.7,32.4).curveTo(-95.3,33.3,-97.6,33.6).curveTo(-99.6,33.9,-103.8,34.6);
	this.shape_55.setTransform(89.121,57.1663);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(105.7,-37.4).curveTo(105.3,-36.9,105,-36.5).curveTo(102.7,-33.5,99.7,-31.5).curveTo(96.4,-29.2,91.9,-27.8).curveTo(90.5,-27.4,89.1,-27).curveTo(87,-26.5,83.3,-26).curveTo(82.5,-25.9,81.2,-25.8).curveTo(79.7,-25.7,79.1,-25.7).curveTo(77.3,-25.5,75.1,-25.5).curveTo(73.9,-25.5,70.9,-25.6).curveTo(67.2,-25.7,62.7,-25.9).curveTo(60.5,-26.1,59.3,-26.1).lineTo(54.9,-26.6).curveTo(54.3,-26.7,50.9,-26.9).curveTo(48.4,-27.1,47,-27.4).curveTo(44.6,-27.6,43.5,-27.7).lineTo(29,-29.1).curveTo(26.1,-29.3,24.6,-29.5).curveTo(23.3,-29.7,22.6,-29.8).curveTo(19.6,-29.9,18,-30).curveTo(16.4,-30.1,13.8,-30.3).curveTo(10.1,-30.5,9.7,-30.5).curveTo(5.8,-30.7,1.1,-30.6).curveTo(-3.1,-30.4,-6.7,-29.9).curveTo(-11.1,-29.2,-13.6,-28.3).curveTo(-16.7,-27.3,-18.4,-25.7).curveTo(-20.8,-23.3,-19.2,-20).curveTo(-18,-18.1,-15.6,-16).curveTo(-13.2,-14.1,-9.4,-11.6).curveTo(-7.2,-10.2,-3,-7.4).curveTo(-0.4,-5.8,0.9,-4.7).curveTo(3,-3.1,4.6,-1.7).curveTo(7.1,0.8,8.2,3.1).curveTo(9.7,6.5,7.2,9.5).curveTo(5.9,11,4.1,12.2).curveTo(2.8,13.1,0.6,14.1).curveTo(-3.9,16.3,-11.1,18.5).curveTo(-18,20.7,-26.9,22.8).curveTo(-34.3,24.5,-45.5,26.7).curveTo(-50.7,27.9,-56,28.8).curveTo(-57.8,29.2,-61.1,29.8).curveTo(-61.4,29.8,-61.8,29.9).curveTo(-64.9,30.5,-66.2,30.7).curveTo(-70.4,31.5,-72.5,31.9).curveTo(-77.4,32.6,-80,33.1).curveTo(-82.3,33.5,-84,33.7).curveTo(-85.5,34,-86.5,34.2).curveTo(-87.1,34.3,-87.6,34.4).curveTo(-88.5,34.5,-89.2,34.6).curveTo(-91.9,35,-93.4,35.3).curveTo(-98,36.1,-100.2,36.5).curveTo(-102.3,36.7,-106.4,37.4);
	this.shape_56.setTransform(91.7882,54.3413);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(106.9,-39.6).curveTo(106.6,-38.9,106.2,-38.2).curveTo(105,-36,103.5,-34.2).curveTo(101.2,-31.3,98.2,-29.2).curveTo(94.9,-27,90.4,-25.5).curveTo(89,-25.1,87.6,-24.8).curveTo(85.5,-24.3,81.8,-23.8).curveTo(81,-23.7,79.7,-23.6).curveTo(78.2,-23.5,77.6,-23.5).curveTo(75.8,-23.3,73.6,-23.3).curveTo(72.4,-23.3,69.4,-23.4).curveTo(65.7,-23.4,61.2,-23.7).curveTo(59,-23.8,57.8,-23.9).lineTo(53.4,-24.4).curveTo(52.8,-24.4,49.4,-24.6).curveTo(46.9,-24.9,45.5,-25.1).curveTo(43.1,-25.3,42,-25.4).lineTo(27.5,-26.8).curveTo(24.6,-27.1,23.1,-27.3).curveTo(21.8,-27.4,21.1,-27.5).curveTo(18.1,-27.6,16.5,-27.8).curveTo(14.9,-27.9,12.3,-28).curveTo(8.6,-28.3,8.2,-28.3).curveTo(4.3,-28.4,-0.4,-28.4).curveTo(-4.6,-28.2,-8.2,-27.6).curveTo(-12.6,-27,-15.1,-26.1).curveTo(-18.2,-25,-19.9,-23.4).curveTo(-22.3,-21,-20.7,-17.8).curveTo(-19.5,-15.8,-17.1,-13.8).curveTo(-14.7,-11.8,-10.9,-9.4).curveTo(-8.7,-8,-4.5,-5.1).curveTo(-1.9,-3.6,-0.6,-2.5).curveTo(1.5,-0.9,3.1,0.6).curveTo(5.6,3,6.7,5.3).curveTo(8.2,8.7,5.7,11.7).curveTo(4.4,13.2,2.6,14.4).curveTo(1.3,15.3,-0.9,16.3).curveTo(-5.4,18.6,-12.6,20.8).curveTo(-19.5,22.9,-28.4,25.1).curveTo(-35.8,26.8,-47,29).curveTo(-52.2,30.1,-57.5,31.1).curveTo(-59.3,31.5,-62.6,32).curveTo(-62.9,32.1,-63.3,32.2).curveTo(-66.4,32.7,-67.7,33).curveTo(-71.9,33.8,-74,34.1).curveTo(-78.9,34.9,-81.5,35.3).curveTo(-83.8,35.7,-85.5,36).curveTo(-87,36.3,-88,36.4).curveTo(-88.6,36.5,-89.1,36.6).curveTo(-90,36.7,-90.7,36.8).curveTo(-93.4,37.2,-94.9,37.5).curveTo(-99.5,38.4,-101.7,38.7).curveTo(-103.8,39,-107.9,39.7);
	this.shape_57.setTransform(93.296,52.0913);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(107.9,-42.4).lineTo(107.7,-42).curveTo(106.8,-39.5,106.4,-38.6).curveTo(105.8,-37.4,105.3,-36.4).curveTo(104,-34.2,102.5,-32.3).curveTo(100.3,-29.4,97.3,-27.3).curveTo(93.9,-25.1,89.4,-23.6).curveTo(88.1,-23.2,86.6,-22.9).curveTo(84.5,-22.4,80.8,-21.9).curveTo(80.1,-21.8,78.8,-21.7).curveTo(77.2,-21.6,76.7,-21.6).curveTo(74.8,-21.4,72.6,-21.4).curveTo(71.4,-21.4,68.5,-21.5).curveTo(64.7,-21.5,60.3,-21.8).curveTo(58,-21.9,56.9,-22).lineTo(52.5,-22.5).curveTo(51.8,-22.5,48.4,-22.7).curveTo(45.9,-23,44.6,-23.2).curveTo(42.2,-23.4,41.1,-23.5).lineTo(26.6,-24.9).curveTo(23.6,-25.2,22.1,-25.4).curveTo(20.9,-25.5,20.2,-25.6).curveTo(17.1,-25.7,15.5,-25.9).curveTo(13.9,-26,11.4,-26.1).curveTo(7.7,-26.4,7.3,-26.4).curveTo(3.4,-26.5,-1.4,-26.5).curveTo(-5.6,-26.3,-9.2,-25.7).curveTo(-13.6,-25.1,-16,-24.2).curveTo(-19.1,-23.1,-20.9,-21.5).curveTo(-23.3,-19.1,-21.6,-15.9).curveTo(-20.5,-13.9,-18,-11.9).curveTo(-15.6,-9.9,-11.8,-7.5).curveTo(-9.7,-6.1,-5.4,-3.2).curveTo(-2.9,-1.7,-1.6,-0.6).curveTo(0.6,1,2.1,2.5).curveTo(4.7,4.9,5.7,7.2).curveTo(7.2,10.6,4.7,13.6).curveTo(3.5,15.1,1.7,16.3).curveTo(0.3,17.2,-1.9,18.2).curveTo(-6.3,20.5,-13.6,22.7).curveTo(-20.4,24.8,-29.3,27).curveTo(-36.8,28.7,-47.9,30.9).curveTo(-53.1,32,-58.5,33).curveTo(-60.3,33.4,-63.6,33.9).curveTo(-63.9,34,-64.2,34.1).curveTo(-67.3,34.6,-68.6,34.9).curveTo(-72.9,35.7,-75,36).curveTo(-79.9,36.8,-82.4,37.2).curveTo(-84.8,37.6,-86.4,37.9).curveTo(-88,38.2,-89,38.3).curveTo(-89.6,38.4,-90.1,38.5).curveTo(-90.9,38.6,-91.7,38.7).curveTo(-94.3,39.1,-95.8,39.4).curveTo(-100.4,40.3,-102.7,40.6).curveTo(-104.7,40.9,-108.9,41.6);
	this.shape_58.setTransform(94.214,50.1687);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(109.1,-45).curveTo(108.7,-44.4,108.4,-43.4).curveTo(107.9,-41.8,107.9,-41.7).lineTo(106.7,-38.5).curveTo(105.8,-36.1,105.3,-35.1).curveTo(104.8,-34,104.2,-33).curveTo(102.9,-30.7,101.5,-28.9).curveTo(99.2,-25.9,96.2,-23.9).curveTo(92.9,-21.6,88.4,-20.2).curveTo(87,-19.8,85.6,-19.4).curveTo(83.5,-18.9,79.8,-18.4).curveTo(79,-18.3,77.7,-18.2).curveTo(76.2,-18.1,75.6,-18.1).curveTo(73.8,-17.9,71.6,-17.9).curveTo(70.4,-17.9,67.4,-18).curveTo(63.7,-18.1,59.2,-18.3).curveTo(57,-18.5,55.8,-18.5).lineTo(51.4,-19).curveTo(50.8,-19.1,47.4,-19.3).curveTo(44.9,-19.5,43.5,-19.8).curveTo(41.2,-20,40,-20.1).lineTo(25.5,-21.5).curveTo(22.6,-21.7,21.1,-21.9).curveTo(19.8,-22.1,19.1,-22.2).curveTo(16.1,-22.3,14.5,-22.4).curveTo(12.9,-22.5,10.3,-22.7).curveTo(6.6,-22.9,6.2,-22.9).curveTo(2.3,-23.1,-2.4,-23).curveTo(-6.6,-22.8,-10.2,-22.3).curveTo(-14.6,-21.6,-17.1,-20.7).curveTo(-20.2,-19.7,-21.9,-18.1).curveTo(-24.3,-15.7,-22.7,-12.4).curveTo(-21.5,-10.5,-19.1,-8.4).curveTo(-16.7,-6.5,-12.9,-4).curveTo(-10.7,-2.6,-6.5,0.2).curveTo(-3.9,1.8,-2.6,2.9).curveTo(-0.5,4.5,1.1,5.9).curveTo(3.6,8.4,4.7,10.7).curveTo(6.2,14.1,3.7,17.1).curveTo(2.4,18.6,0.6,19.8).curveTo(-0.7,20.7,-2.9,21.7).curveTo(-7.4,23.9,-14.6,26.1).curveTo(-21.5,28.3,-30.4,30.4).curveTo(-37.8,32.2,-49,34.3).curveTo(-54.2,35.5,-59.5,36.4).curveTo(-61.3,36.8,-64.6,37.4).curveTo(-64.9,37.4,-65.3,37.5).curveTo(-68.4,38.1,-69.7,38.3).curveTo(-73.9,39.1,-76,39.5).curveTo(-80.9,40.2,-83.5,40.7).curveTo(-85.8,41.1,-87.5,41.3).curveTo(-89,41.6,-90,41.8).curveTo(-90.6,41.9,-91.1,42).curveTo(-92,42.1,-92.7,42.2).curveTo(-95.4,42.6,-96.9,42.9).curveTo(-101.5,43.7,-103.7,44.1).curveTo(-105.8,44.3,-109.9,45);
	this.shape_59.setTransform(95.2661,46.7413);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(86.1,-41.1).curveTo(85.7,-40.5,85.5,-39.5).curveTo(84.9,-37.9,84.9,-37.9).lineTo(83.7,-34.7).curveTo(82.8,-32.2,82.4,-31.3).curveTo(81.8,-30.1,81.3,-29.1).curveTo(80,-26.9,78.5,-25).curveTo(76.3,-22.1,73.3,-20).curveTo(69.9,-17.8,65.4,-16.3).curveTo(64.1,-15.9,62.6,-15.6).curveTo(60.5,-15.1,56.8,-14.6).curveTo(56.1,-14.5,54.8,-14.4).curveTo(53.2,-14.3,52.7,-14.3).curveTo(50.8,-14.1,48.6,-14.1).curveTo(47.4,-14.1,44.5,-14.2).curveTo(40.7,-14.2,36.3,-14.5).curveTo(34,-14.6,32.9,-14.7).lineTo(28.5,-15.2).curveTo(27.8,-15.2,24.4,-15.4).curveTo(21.9,-15.7,20.6,-15.9).curveTo(18.3,-16.1,17.1,-16.2).lineTo(2.6,-17.6).curveTo(-0.4,-17.9,-1.9,-18.1).curveTo(-3.1,-18.2,-3.8,-18.3).curveTo(-6.9,-18.4,-8.5,-18.6).curveTo(-10.1,-18.7,-12.6,-18.8).curveTo(-16.3,-19.1,-16.7,-19.1).curveTo(-20.6,-19.2,-25.4,-19.2).curveTo(-29.6,-19,-33.2,-18.4).curveTo(-37.6,-17.8,-40,-16.9).curveTo(-43.1,-15.8,-44.9,-14.2).curveTo(-47.3,-11.8,-45.6,-8.6).curveTo(-44.5,-6.6,-42,-4.6).curveTo(-39.6,-2.6,-35.8,-0.2).curveTo(-33.7,1.2,-29.4,4.1).curveTo(-26.9,5.7,-25.6,6.7).curveTo(-23.4,8.4,-21.9,9.8).curveTo(-19.3,12.2,-18.3,14.5).curveTo(-16.8,17.9,-19.3,20.9).curveTo(-20.5,22.4,-22.3,23.6).curveTo(-23.7,24.5,-25.9,25.5).curveTo(-30.3,27.8,-37.6,30).curveTo(-44.4,32.1,-53.3,34.3).curveTo(-60.8,36,-71.9,38.2).curveTo(-77.1,39.3,-82.5,40.3).curveTo(-84.1,40.6,-87,41.1);
	this.shape_60.setTransform(118.2154,42.8662);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(71.2,-38.1).curveTo(70.8,-37.5,70.6,-36.5).curveTo(70,-34.9,70,-34.9).lineTo(68.8,-31.7).curveTo(67.9,-29.2,67.5,-28.3).curveTo(66.9,-27.1,66.4,-26.1).curveTo(65.1,-23.9,63.6,-22).curveTo(61.4,-19.1,58.4,-17).curveTo(55,-14.8,50.5,-13.3).curveTo(49.2,-12.9,47.7,-12.6).curveTo(45.6,-12.1,41.9,-11.6).curveTo(41.2,-11.5,39.9,-11.4).curveTo(38.3,-11.3,37.8,-11.3).curveTo(35.9,-11.1,33.7,-11.1).curveTo(32.5,-11.1,29.6,-11.2).curveTo(25.8,-11.2,21.4,-11.5).curveTo(19.1,-11.6,18,-11.7).lineTo(13.6,-12.2).curveTo(12.9,-12.2,9.5,-12.4).curveTo(7,-12.7,5.7,-12.9).curveTo(3.4,-13.1,2.2,-13.2).lineTo(-12.3,-14.6).curveTo(-15.3,-14.9,-16.8,-15.1).curveTo(-18,-15.2,-18.7,-15.3).curveTo(-21.8,-15.4,-23.4,-15.6).curveTo(-25,-15.7,-27.5,-15.8).curveTo(-31.2,-16.1,-31.6,-16.1).curveTo(-35.5,-16.2,-40.3,-16.2).curveTo(-44.5,-16,-48.1,-15.4).curveTo(-52.5,-14.8,-54.9,-13.9).curveTo(-58,-12.8,-59.8,-11.2).curveTo(-62.2,-8.8,-60.5,-5.6).curveTo(-59.4,-3.6,-56.9,-1.6).curveTo(-54.5,0.4,-50.7,2.8).curveTo(-48.6,4.2,-44.3,7.1).curveTo(-41.8,8.7,-40.5,9.7).curveTo(-38.3,11.4,-36.8,12.8).curveTo(-34.2,15.2,-33.2,17.5).curveTo(-31.7,20.9,-34.2,23.9).curveTo(-35.4,25.4,-37.2,26.6).curveTo(-38.6,27.5,-40.8,28.5).curveTo(-45.2,30.8,-52.5,33).curveTo(-59.3,35.1,-68.2,37.3).curveTo(-70,37.7,-72,38.1);
	this.shape_61.setTransform(133.147,39.8601);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(66.3,-32.1).curveTo(65.9,-31.5,65.7,-30.5).curveTo(65.1,-28.9,65.1,-28.9).lineTo(63.9,-25.7).curveTo(63,-23.2,62.6,-22.3).curveTo(62,-21.1,61.5,-20.1).curveTo(60.2,-17.9,58.7,-16).curveTo(56.5,-13.1,53.5,-11).curveTo(50.1,-8.8,45.6,-7.4).curveTo(44.3,-6.9,42.8,-6.6).curveTo(40.7,-6.1,37,-5.6).curveTo(36.3,-5.5,35,-5.4).curveTo(33.4,-5.3,32.9,-5.3).curveTo(31,-5.1,28.8,-5.1).curveTo(27.6,-5.1,24.7,-5.2).curveTo(20.9,-5.2,16.5,-5.5).curveTo(14.2,-5.6,13.1,-5.7).lineTo(8.7,-6.2).curveTo(8,-6.2,4.6,-6.4).curveTo(2.1,-6.7,0.8,-6.9).curveTo(-1.5,-7.1,-2.7,-7.2).lineTo(-17.2,-8.6).curveTo(-20.2,-8.9,-21.7,-9.1).curveTo(-22.9,-9.2,-23.6,-9.3).curveTo(-26.7,-9.4,-28.3,-9.6).curveTo(-29.9,-9.7,-32.4,-9.8).curveTo(-36.1,-10.1,-36.5,-10.1).curveTo(-40.4,-10.2,-45.2,-10.2).curveTo(-49.4,-10,-53,-9.4).curveTo(-57.4,-8.8,-59.8,-7.9).curveTo(-62.9,-6.9,-64.7,-5.2).curveTo(-67.1,-2.9,-65.4,0.4).curveTo(-64.3,2.4,-61.8,4.4).curveTo(-59.4,6.4,-55.6,8.8).curveTo(-53.5,10.2,-49.2,13.1).curveTo(-46.7,14.6,-45.4,15.7).curveTo(-43.2,17.4,-41.7,18.8).curveTo(-39.1,21.2,-38.1,23.5).curveTo(-36.6,26.9,-39.1,29.9).curveTo(-40.1,31.1,-41.5,32.1);
	this.shape_62.setTransform(138.0339,33.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(66.3,-25.6).curveTo(65.9,-25,65.7,-24).curveTo(65.1,-22.4,65.1,-22.4).lineTo(63.9,-19.2).curveTo(63,-16.8,62.6,-15.8).curveTo(62,-14.6,61.5,-13.6).curveTo(60.2,-11.4,58.7,-9.5).curveTo(56.5,-6.6,53.5,-4.5).curveTo(50.1,-2.3,45.6,-0.9).curveTo(44.3,-0.4,42.8,-0.1).curveTo(40.7,0.4,37,0.9).curveTo(36.3,1,35,1.1).curveTo(33.4,1.2,32.9,1.2).curveTo(31,1.4,28.8,1.4).curveTo(27.6,1.4,24.7,1.3).curveTo(20.9,1.2,16.5,1).curveTo(14.2,0.9,13.1,0.8).lineTo(8.7,0.3).curveTo(8,0.2,4.6,0.1).curveTo(2.1,-0.2,0.8,-0.4).curveTo(-1.5,-0.6,-2.7,-0.8).lineTo(-17.2,-2.1).curveTo(-20.2,-2.4,-21.7,-2.6).curveTo(-22.9,-2.8,-23.6,-2.8).curveTo(-26.7,-2.9,-28.3,-3.1).curveTo(-29.9,-3.2,-32.4,-3.3).curveTo(-36.1,-3.6,-36.5,-3.6).curveTo(-40.4,-3.8,-45.2,-3.7).curveTo(-49.4,-3.5,-53,-2.9).curveTo(-57.4,-2.3,-59.8,-1.4).curveTo(-62.9,-0.4,-64.7,1.2).curveTo(-67.1,3.6,-65.4,6.9).curveTo(-64.3,8.9,-61.8,10.9).curveTo(-59.4,12.9,-55.6,15.3).curveTo(-53.5,16.7,-49.2,19.6).curveTo(-46.7,21.1,-45.4,22.2).curveTo(-43.2,23.9,-41.7,25.2).curveTo(-41.5,25.5,-41.3,25.6);
	this.shape_63.setTransform(138.0339,27.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(66.3,-21).curveTo(65.9,-20.4,65.7,-19.4).curveTo(65.1,-17.8,65.1,-17.8).lineTo(63.9,-14.6).curveTo(63,-12.1,62.6,-11.2).curveTo(62,-10,61.5,-9).curveTo(60.2,-6.8,58.7,-4.9).curveTo(56.5,-2,53.5,0.1).curveTo(50.1,2.3,45.6,3.8).curveTo(44.3,4.2,42.8,4.5).curveTo(40.7,5,37,5.5).curveTo(36.3,5.6,35,5.7).curveTo(33.4,5.8,32.9,5.8).curveTo(31,6,28.8,6).curveTo(27.6,6,24.7,5.9).curveTo(20.9,5.9,16.5,5.6).curveTo(14.2,5.5,13.1,5.4).lineTo(8.7,4.9).curveTo(8,4.9,4.6,4.7).curveTo(2.1,4.4,0.8,4.2).curveTo(-1.5,4,-2.7,3.9).lineTo(-17.2,2.5).curveTo(-20.2,2.2,-21.7,2).curveTo(-22.9,1.9,-23.6,1.8).curveTo(-26.7,1.7,-28.3,1.5).curveTo(-29.9,1.4,-32.4,1.3).curveTo(-36.1,1,-36.5,1).curveTo(-40.4,0.9,-45.2,0.9).curveTo(-49.4,1.1,-53,1.7).curveTo(-57.4,2.3,-59.8,3.2).curveTo(-62.9,4.3,-64.7,5.9).curveTo(-67.1,8.3,-65.4,11.5).curveTo(-64.3,13.5,-61.8,15.5).curveTo(-59.4,17.5,-55.6,19.9).curveTo(-54.8,20.5,-53.6,21.3);
	this.shape_64.setTransform(138.0339,22.7957);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(66.3,-16.4).curveTo(65.9,-15.8,65.7,-14.8).curveTo(65.1,-13.2,65.1,-13.1).lineTo(63.9,-9.9).curveTo(63,-7.5,62.6,-6.5).curveTo(62,-5.4,61.5,-4.4).curveTo(60.2,-2.1,58.7,-0.3).curveTo(56.5,2.7,53.5,4.7).curveTo(50.1,7,45.6,8.4).curveTo(44.3,8.8,42.8,9.2).curveTo(40.7,9.7,37,10.2).curveTo(36.3,10.3,35,10.4).curveTo(33.4,10.5,32.9,10.5).curveTo(31,10.7,28.8,10.7).curveTo(27.6,10.7,24.7,10.6).curveTo(20.9,10.5,16.5,10.3).curveTo(14.2,10.1,13.1,10.1).lineTo(8.7,9.6).curveTo(8,9.5,4.6,9.3).curveTo(2.1,9.1,0.8,8.8).curveTo(-1.5,8.6,-2.7,8.5).lineTo(-17.2,7.1).curveTo(-20.2,6.9,-21.7,6.7).curveTo(-22.9,6.5,-23.6,6.4).curveTo(-26.7,6.3,-28.3,6.2).curveTo(-29.9,6.1,-32.4,5.9).curveTo(-36.1,5.7,-36.5,5.7).curveTo(-40.4,5.5,-45.2,5.6).curveTo(-49.4,5.8,-53,6.3).curveTo(-57.4,7,-59.8,7.9).curveTo(-62.9,8.9,-64.7,10.5).curveTo(-67.1,12.9,-65.4,16.2).curveTo(-65.2,16.5,-64.9,16.9);
	this.shape_65.setTransform(138.0339,18.1477);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(61.3,-13.5).curveTo(60.9,-12.9,60.6,-11.9).curveTo(60.1,-10.3,60.1,-10.3).lineTo(58.9,-7.1).curveTo(58,-4.6,57.5,-3.7).curveTo(57,-2.5,56.4,-1.5).curveTo(55.1,0.7,53.7,2.6).curveTo(51.4,5.5,48.4,7.6).curveTo(45.1,9.8,40.6,11.3).curveTo(39.2,11.7,37.8,12).curveTo(35.7,12.5,32,13).curveTo(31.2,13.1,29.9,13.2).curveTo(28.4,13.3,27.8,13.3).curveTo(26,13.5,23.8,13.5).curveTo(22.6,13.5,19.6,13.4).curveTo(15.9,13.4,11.4,13.1).curveTo(9.2,13,8,12.9).lineTo(3.6,12.4).curveTo(3,12.4,-0.4,12.2).curveTo(-2.9,11.9,-4.3,11.7).curveTo(-6.6,11.5,-7.8,11.4).lineTo(-22.3,10).curveTo(-25.2,9.7,-26.7,9.5).curveTo(-28,9.4,-28.7,9.3).curveTo(-31.7,9.2,-33.3,9).curveTo(-34.9,8.9,-37.5,8.8).curveTo(-41.2,8.5,-41.6,8.5).curveTo(-45.5,8.4,-50.2,8.4).curveTo(-54.4,8.6,-58,9.2).curveTo(-59.7,9.4,-61,9.7);
	this.shape_66.setTransform(143.095,15.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(54.6,-13.5).curveTo(54.2,-12.9,54,-11.9).curveTo(53.4,-10.3,53.4,-10.3).lineTo(52.2,-7.1).curveTo(51.3,-4.6,50.9,-3.7).curveTo(50.3,-2.5,49.8,-1.5).curveTo(48.5,0.7,47,2.6).curveTo(44.8,5.5,41.8,7.6).curveTo(38.4,9.8,33.9,11.3).curveTo(32.6,11.7,31.1,12).curveTo(29,12.5,25.3,13).curveTo(24.6,13.1,23.3,13.2).curveTo(21.7,13.3,21.2,13.3).curveTo(19.3,13.5,17.1,13.5).curveTo(15.9,13.5,13,13.4).curveTo(9.2,13.4,4.8,13.1).curveTo(2.5,13,1.4,12.9).lineTo(-3,12.4).curveTo(-3.7,12.4,-7.1,12.2).curveTo(-9.6,11.9,-10.9,11.7).curveTo(-13.2,11.5,-14.4,11.4).lineTo(-28.9,10).curveTo(-31.9,9.7,-33.4,9.5).curveTo(-34.6,9.4,-35.3,9.3).curveTo(-38.4,9.2,-40,9).curveTo(-41.6,8.9,-44.1,8.8).curveTo(-47.8,8.5,-48.2,8.5).curveTo(-51.6,8.4,-55.7,8.4);
	this.shape_67.setTransform(149.7153,15.275);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(48.7,-13.5).curveTo(48.3,-12.9,48,-11.9).curveTo(47.5,-10.3,47.5,-10.3).lineTo(46.3,-7.1).curveTo(45.4,-4.6,44.9,-3.7).curveTo(44.4,-2.5,43.8,-1.5).curveTo(42.5,0.7,41.1,2.6).curveTo(38.8,5.5,35.8,7.6).curveTo(32.5,9.8,28,11.3).curveTo(26.6,11.7,25.2,12).curveTo(23.1,12.5,19.4,13).curveTo(18.6,13.1,17.3,13.2).curveTo(15.8,13.3,15.2,13.3).curveTo(13.4,13.5,11.2,13.5).curveTo(10,13.5,7,13.4).curveTo(3.3,13.4,-1.2,13.1).curveTo(-3.4,13,-4.6,12.9).lineTo(-9,12.4).curveTo(-9.6,12.4,-13,12.2).curveTo(-15.5,11.9,-16.9,11.7).curveTo(-19.2,11.5,-20.4,11.4).lineTo(-34.9,10).curveTo(-37.8,9.7,-39.3,9.5).curveTo(-40.6,9.4,-41.3,9.3).curveTo(-44.3,9.2,-45.9,9).curveTo(-47.4,8.9,-49.6,8.8);
	this.shape_68.setTransform(155.6828,15.275);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(43.8,-13.5).curveTo(43.4,-12.9,43.1,-11.9).curveTo(42.6,-10.3,42.6,-10.3).lineTo(41.4,-7.1).curveTo(40.5,-4.6,40,-3.7).curveTo(39.5,-2.5,38.9,-1.5).curveTo(37.6,0.7,36.2,2.6).curveTo(33.9,5.5,30.9,7.6).curveTo(27.6,9.8,23.1,11.3).curveTo(21.7,11.7,20.3,12).curveTo(18.2,12.5,14.5,13).curveTo(13.7,13.1,12.4,13.2).curveTo(10.9,13.3,10.3,13.3).curveTo(8.5,13.5,6.3,13.5).curveTo(5.1,13.5,2.1,13.4).curveTo(-1.6,13.4,-6.1,13.1).curveTo(-8.3,13,-9.5,12.9).lineTo(-13.9,12.4).curveTo(-14.5,12.4,-17.9,12.2).curveTo(-20.4,11.9,-21.8,11.7).curveTo(-24.1,11.5,-25.3,11.4).lineTo(-39.8,10).curveTo(-42.1,9.8,-43.5,9.6);
	this.shape_69.setTransform(160.595,15.275);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(37.2,-13.5).curveTo(36.8,-12.9,36.5,-11.9).curveTo(36,-10.3,36,-10.3).lineTo(34.8,-7.1).curveTo(33.9,-4.6,33.4,-3.7).curveTo(32.9,-2.5,32.3,-1.5).curveTo(31,0.7,29.6,2.6).curveTo(27.3,5.5,24.3,7.6).curveTo(21,9.8,16.5,11.3).curveTo(15.1,11.7,13.7,12).curveTo(11.6,12.5,7.9,13).curveTo(7.1,13.1,5.8,13.2).curveTo(4.3,13.3,3.7,13.3).curveTo(1.9,13.5,-0.3,13.5).curveTo(-1.5,13.5,-4.5,13.4).curveTo(-8.2,13.4,-12.7,13.1).curveTo(-14.9,13,-16.1,12.9).lineTo(-20.5,12.4).curveTo(-21.1,12.4,-24.5,12.2).curveTo(-27,11.9,-28.4,11.7).curveTo(-30.7,11.5,-31.9,11.4).lineTo(-38.1,10.8);
	this.shape_70.setTransform(167.1603,15.275);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(32.3,-13.5).curveTo(31.9,-12.9,31.6,-11.9).curveTo(31.1,-10.3,31.1,-10.3).lineTo(29.9,-7.1).curveTo(29,-4.6,28.5,-3.7).curveTo(28,-2.5,27.4,-1.5).curveTo(26.1,0.7,24.7,2.6).curveTo(22.4,5.5,19.4,7.6).curveTo(16.1,9.8,11.6,11.3).curveTo(10.2,11.7,8.8,12).curveTo(6.7,12.5,3,13).curveTo(2.2,13.1,0.9,13.2).curveTo(-0.6,13.3,-1.2,13.3).curveTo(-3,13.5,-5.2,13.5).curveTo(-6.4,13.5,-9.4,13.4).curveTo(-13.1,13.4,-17.6,13.1).curveTo(-19.8,13,-21,12.9).lineTo(-25.4,12.4).curveTo(-26,12.4,-29.4,12.2).curveTo(-31,12,-32,11.9);
	this.shape_71.setTransform(172.095,15.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(26.7,-13.5).curveTo(26.3,-12.9,26.1,-11.9).curveTo(25.5,-10.3,25.5,-10.3).lineTo(24.3,-7.1).curveTo(23.4,-4.6,23,-3.7).curveTo(22.4,-2.5,21.9,-1.5).curveTo(20.6,0.7,19.1,2.6).curveTo(16.9,5.5,13.9,7.6).curveTo(10.5,9.8,6,11.3).curveTo(4.7,11.7,3.2,12).curveTo(1.1,12.5,-2.6,13).curveTo(-3.3,13.1,-4.6,13.2).curveTo(-6.2,13.3,-6.7,13.3).curveTo(-8.6,13.5,-10.8,13.5).curveTo(-12,13.5,-14.9,13.4).curveTo(-18.7,13.4,-23.1,13.1).curveTo(-25.4,13,-26.5,12.9).lineTo(-27.6,12.8);
	this.shape_72.setTransform(177.62,15.275);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(19.2,-13.5).curveTo(18.8,-12.9,18.5,-11.9).curveTo(18,-10.3,18,-10.3).lineTo(16.8,-7.1).curveTo(15.9,-4.6,15.4,-3.7).curveTo(14.9,-2.5,14.3,-1.5).curveTo(13,0.7,11.6,2.6).curveTo(9.3,5.5,6.3,7.6).curveTo(3,9.8,-1.5,11.3).curveTo(-2.9,11.7,-4.3,12).curveTo(-6.4,12.5,-10.1,13).curveTo(-10.9,13.1,-12.2,13.2).curveTo(-13.7,13.3,-14.3,13.3).curveTo(-16.1,13.5,-18.3,13.5).curveTo(-19,13.5,-20.2,13.5);
	this.shape_73.setTransform(185.1819,15.275);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(12.8,-13.1).curveTo(12.4,-12.5,12.1,-11.5).curveTo(11.6,-9.9,11.6,-9.8).lineTo(10.4,-6.6).curveTo(9.5,-4.2,9,-3.2).curveTo(8.5,-2.1,7.9,-1.1).curveTo(6.6,1.2,5.2,3.1).curveTo(2.9,6,-0.1,8.1).curveTo(-3.4,10.3,-7.9,11.7).curveTo(-9.3,12.2,-10.7,12.5).curveTo(-11.9,12.8,-13.6,13.1);
	this.shape_74.setTransform(191.5955,14.8);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(7.9,-11.5).curveTo(7.5,-10.9,7.3,-9.9).curveTo(6.7,-8.3,6.7,-8.3).lineTo(5.5,-5.1).curveTo(4.6,-2.6,4.2,-1.7).curveTo(3.6,-0.5,3.1,0.5).curveTo(1.8,2.7,0.3,4.6).curveTo(-1.9,7.5,-4.9,9.6).curveTo(-6.5,10.6,-8.4,11.5);
	this.shape_75.setTransform(196.4282,13.2875);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(3.5,-7.6).curveTo(3.1,-7,2.8,-6).curveTo(2.3,-4.4,2.3,-4.4).lineTo(1.1,-1.2).curveTo(0.2,1.2,-0.3,2.2).curveTo(-0.8,3.4,-1.4,4.4).curveTo(-2.4,6.1,-3.5,7.7);
	this.shape_76.setTransform(200.867,9.4);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(1.2,-2.7).curveTo(0.8,-2.1,0.6,-1.1).curveTo(0,0.5,0,0.5).lineTo(-1.1,3.6);
	this.shape_77.setTransform(203.1102,4.4955);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(2.5).moveTo(12.7,-13.1).curveTo(12.3,-12.5,12.1,-11.5).curveTo(11.5,-9.9,11.5,-9.8).lineTo(10.3,-6.6).curveTo(9.4,-4.2,9,-3.2).curveTo(8.4,-2.1,7.9,-1.1).curveTo(6.6,1.2,5.1,3.1).curveTo(2.9,6,-0.1,8.1).curveTo(-3.5,10.3,-8,11.8).curveTo(-9.3,12.1,-10.8,12.5).curveTo(-11.9,12.8,-13.6,13.1);
	this.shape_78.setTransform(191.6041,14.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},12).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},2).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[]},1).to({state:[{t:this.shape}]},19).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},2).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[]},1).to({state:[{t:this.shape}]},19).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},2).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).wait(1));

	// PLANE
	this.PLANE_ANIMATION = new lib.Plane();
	this.PLANE_ANIMATION.name = "PLANE_ANIMATION";
	this.PLANE_ANIMATION.parent = this;
	this.PLANE_ANIMATION.setTransform(-2.75,87,0.2458,0.2457,0,0,0,-409.2,212.5);
	this.PLANE_ANIMATION.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.PLANE_ANIMATION).to({regX:-408.9,guide:{path:[-2.6,87.1,-2.6,87.1,-2.7,87.1]},alpha:1},6).to({regX:-409.2,regY:211.1,guide:{path:[-2.7,87,0.1,86.6,2.7,86.3,3.5,86.1,4.3,86.1,6.2,85.8,7.9,85.5,17.2,84.2,23.4,83.3,26.9,82.9,30.1,82.4,43.2,80.4,52.9,78.5,89.2,71.5,113.5,59.4,118.3,57,119.2,54.4,120.1,51.8,117.5,48.4,115.1,45.2,109.1,40.3,105.6,37.6,94.7,29.1,90.6,26,89.2,23.6,87.9,21.3,89.4,19.7,91.9,16.7,103.8,16.2,114.1,15.7,132.7,17,146.2,17.9,170.6,20.3,177.6,21,183.7,21,192.5,20.9,199.5,19.2,211.5,16.4,218.3,9,222.6,4.4,224.4,-1.4,225.3,-4.3,225.3,-6.3]}},66).to({regX:-409.4,regY:211.2,x:223.75,y:-6.45,alpha:0},5).to({_off:true},20).wait(1).to({_off:false,regX:-409.2,regY:212.5,x:-2.75,y:87},0).to({regX:-408.9,guide:{path:[-2.6,87.1,-2.6,87.1,-2.7,87.1]},alpha:1},6).to({regX:-409.2,regY:211.1,guide:{path:[-2.7,87,0.1,86.6,2.7,86.3,3.5,86.1,4.3,86.1,6.2,85.8,7.9,85.5,17.2,84.2,23.4,83.3,26.9,82.9,30.1,82.4,43.2,80.4,52.9,78.5,89.2,71.5,113.5,59.4,118.3,57,119.2,54.4,120.1,51.8,117.5,48.4,115.1,45.2,109.1,40.3,105.6,37.6,94.7,29.1,90.6,26,89.2,23.6,87.9,21.3,89.4,19.7,91.9,16.7,103.8,16.2,114.1,15.7,132.7,17,146.2,17.9,170.6,20.3,177.6,21,183.7,21,192.5,20.9,199.5,19.2,211.5,16.4,218.3,9,222.6,4.4,224.4,-1.4,225.3,-4.3,225.3,-6.3]}},66).to({regX:-409.4,regY:211.2,x:223.75,y:-6.45,alpha:0},5).to({_off:true},20).wait(1).to({_off:false,regX:-409.2,regY:212.5,x:-2.75,y:87},0).to({regX:-409.4,regY:212.7,guide:{path:[-2.6,87.1,0.2,86.7,2.7,86.3,3.5,86.2,4.3,86.1,6.2,85.8,7.9,85.6,14.3,84.7,19.3,84]},alpha:1},5).to({regX:-409.2,regY:211.1,guide:{path:[19.3,84,21.5,83.7,23.4,83.4,26.9,82.9,30.1,82.4,43.2,80.5,52.9,78.5,89.2,71.6,113.5,59.5,118.3,57.1,119.2,54.5,120.1,51.9,117.5,48.4,115.1,45.3,109.1,40.3,105.6,37.6,94.7,29.1,90.6,25.9,89.3,23.6,87.9,21.2,89.4,19.7,91.9,16.8,103.8,16.2,114.1,15.8,132.7,17.1,146.2,18,170.6,20.4,177.6,21.1,183.7,21,192.5,20.9,199.5,19.3,211.5,16.4,218.3,9,222.6,4.5,224.4,-1.4,225.3,-4.2,225.3,-6.3]}},67).to({regX:-409.4,regY:211.2,x:223.75,y:-6.45,alpha:0},4,cjs.Ease.cubicOut).wait(13));

	// Layer_20 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.moveTo(-124.5,45).lineTo(-124.5,-45).lineTo(124.5,-45).lineTo(124.5,45).closePath();
	mask.setTransform(124.5,45);

	// IMG2
	this.instance = new lib.Tween5("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(82,132);

	this.instance_1 = new lib.Tween6("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(82,277.5);
	this.instance_1.alpha = 0;

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance}]},89).to({state:[{t:this.instance_1}]},7).to({state:[]},1).wait(188));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:259.55},89).to({_off:true,y:277.5,alpha:0},7).wait(189));

	// IMG1
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(67.65,96.85,0.7332,0.7332,0,0,0,0.2,0.2);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(145.55,90.3,0.7098,0.7098,0,0,0,0.3,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(88).to({_off:false},0).to({_off:true,regX:0.3,scaleX:0.7098,scaleY:0.7098,x:145.55,y:90.3},88).wait(109));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(88).to({_off:false},88).to({x:170.25,alpha:0},9).to({_off:true},1).wait(99));

	// IMG3
	this.instance_4 = new lib.Tween7("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(161.3,100.85,0.9,0.9,0,0,0,0.2,0.2);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween8("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(109.65,104.1,0.9297,0.9297,0,0,0,0.1,0.1);

	var maskedShapeInstanceList = [this.instance_4,this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},178).to({state:[{t:this.instance_5}]},106).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(178).to({_off:false},0).to({_off:true,regX:0.1,regY:0.1,scaleX:0.9297,scaleY:0.9297,x:109.65,y:104.1},106).wait(1));

	// TEXT_3
	this.instance_6 = new lib.Symbol2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(476.25,42.45,1.1688,1.1688,0,0,0,0.1,0.1);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(189).to({_off:false},0).to({alpha:1},7,cjs.Ease.cubicOut).wait(82).to({alpha:0},6,cjs.Ease.cubicIn).wait(1));

	// TEXT_2
	this.instance_7 = new lib.Symbol3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(476.25,46,1.1688,1.1688,0,0,0,0.1,0.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(94).to({_off:false},0).to({alpha:1},8,cjs.Ease.cubicOut).wait(81).to({alpha:0},6,cjs.Ease.cubicIn).to({_off:true},1).wait(95));

	// TEXT_1
	this.instance_8 = new lib.Symbol4();
	this.instance_8.parent = this;
	this.instance_8.setTransform(470.25,43.35,1.1688,1.1688,0,0,0,0.1,0.1);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({x:476.25,alpha:1},13,cjs.Ease.cubicOut).wait(73).to({alpha:0},7,cjs.Ease.cubicIn).to({_off:true},5).wait(187));

	// FH
	this.instance_9 = new lib.FHlogo();
	this.instance_9.parent = this;
	this.instance_9.setTransform(316.75,45,0.8668,0.8668);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(285));

	// Lendlease
	this.instance_10 = new lib.lendlease_logo();
	this.instance_10.parent = this;
	this.instance_10.setTransform(649.55,58.15,0.7531,0.7437,0,0,0,0.2,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(285));

	// Layer_6
	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.4,0.4).curveTo(-0.4,0.3,-0.4,0.3).curveTo(-0.5,0.3,-0.5,0.2).curveTo(-0.5,0.2,-0.5,0.1).curveTo(-0.5,0,-0.5,-0).curveTo(-0.5,-0.1,-0.5,-0.1).curveTo(-0.5,-0.2,-0.5,-0.2).curveTo(-0.5,-0.3,-0.4,-0.3).curveTo(-0.4,-0.3,-0.4,-0.4).curveTo(-0.3,-0.4,-0.3,-0.4).curveTo(-0.2,-0.5,-0.2,-0.5).curveTo(-0.1,-0.5,-0.1,-0.5).curveTo(-0,-0.5,0,-0.5).curveTo(0.1,-0.5,0.1,-0.5).curveTo(0.2,-0.5,0.2,-0.5).curveTo(0.3,-0.5,0.3,-0.4).curveTo(0.3,-0.4,0.4,-0.4).curveTo(0.4,-0.3,0.4,-0.3).curveTo(0.5,-0.3,0.5,-0.2).curveTo(0.5,-0.2,0.5,-0.1).curveTo(0.5,-0.1,0.5,-0).curveTo(0.5,0,0.5,0.1).curveTo(0.5,0.2,0.5,0.2).curveTo(0.5,0.3,0.4,0.3).curveTo(0.4,0.3,0.4,0.4).curveTo(0.3,0.4,0.3,0.4).curveTo(0.3,0.5,0.2,0.5).curveTo(0.2,0.5,0.1,0.5).curveTo(0.1,0.5,0,0.5).curveTo(-0,0.5,-0.1,0.5).curveTo(-0.1,0.5,-0.2,0.5).curveTo(-0.2,0.5,-0.3,0.4).curveTo(-0.3,0.4,-0.4,0.4).closePath();
	this.shape_79.setTransform(581.725,121.675);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.4).curveTo(-1.7,0.8,-1.7,-0).curveTo(-1.7,-0.8,-1.2,-1.4).curveTo(-0.7,-1.9,0,-1.9).curveTo(0.8,-1.9,1.3,-1.4).curveTo(1.7,-0.9,1.7,-0).lineTo(1.7,0.2).lineTo(-1,0.2).curveTo(-1,0.7,-0.7,1).curveTo(-0.4,1.3,0.1,1.3).curveTo(0.9,1.3,1.1,0.5).lineTo(1.7,0.8).curveTo(1.6,1.3,1.1,1.6).curveTo(0.7,1.9,0.1,1.9).curveTo(-0.7,1.9,-1.2,1.4).closePath().moveTo(1,-0.4).curveTo(1,-0.8,0.7,-1).curveTo(0.5,-1.3,0,-1.3).curveTo(-0.4,-1.3,-0.7,-1).curveTo(-0.9,-0.7,-1,-0.4).lineTo(1,-0.4).lineTo(1,-0.4).closePath();
	this.shape_80.setTransform(578.675,120.35);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,2.2).curveTo(-1.7,1.9,-1.7,1.3).lineTo(-1.1,1.1).curveTo(-1,1.5,-0.7,1.7).curveTo(-0.5,2,-0.1,2).curveTo(1,2,1,0.8).lineTo(1,0.3).curveTo(0.7,0.9,-0.1,0.9).curveTo(-0.8,0.9,-1.3,0.4).curveTo(-1.7,-0.1,-1.7,-0.8).curveTo(-1.7,-1.6,-1.3,-2.1).curveTo(-0.8,-2.6,-0.1,-2.6).curveTo(0.8,-2.6,1,-2).lineTo(1,-2.5).lineTo(1.7,-2.5).lineTo(1.7,0.8).curveTo(1.7,1.6,1.3,2.1).curveTo(0.9,2.6,-0.1,2.6).curveTo(-0.7,2.6,-1.2,2.2).closePath().moveTo(-0.7,-1.7).curveTo(-1,-1.4,-1,-0.8).curveTo(-1,-0.3,-0.7,-0).curveTo(-0.4,0.3,0,0.3).curveTo(0.5,0.3,0.8,-0).curveTo(1.1,-0.3,1.1,-0.8).curveTo(1.1,-1.4,0.8,-1.7).curveTo(0.5,-2,0,-2).curveTo(-0.4,-2,-0.7,-1.7).closePath();
	this.shape_81.setTransform(574.425,121.075);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.8,1.8).lineTo(0.8,-0.3).curveTo(0.8,-1.2,0,-1.2).curveTo(-0.4,-1.2,-0.7,-1).curveTo(-0.9,-0.6,-0.9,-0.2).lineTo(-0.9,1.8).lineTo(-1.6,1.8).lineTo(-1.6,-1.8).lineTo(-0.9,-1.8).lineTo(-0.9,-1.2).curveTo(-0.5,-1.9,0.2,-1.9).curveTo(0.9,-1.9,1.2,-1.4).curveTo(1.5,-1.1,1.6,-0.4).lineTo(1.6,1.8).closePath();
	this.shape_82.setTransform(570.3,120.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.6).curveTo(-1.6,1.3,-1.6,0.9).curveTo(-1.6,0.4,-1.2,0.1).curveTo(-0.9,-0.2,-0.4,-0.3).lineTo(0.6,-0.4).curveTo(0.6,-0.4,0.7,-0.4).curveTo(0.7,-0.5,0.7,-0.5).curveTo(0.8,-0.5,0.8,-0.6).curveTo(0.8,-0.6,0.8,-0.7).curveTo(0.8,-0.8,0.8,-0.8).curveTo(0.8,-0.9,0.8,-0.9).curveTo(0.7,-1,0.7,-1).curveTo(0.7,-1.1,0.7,-1.2).curveTo(0.4,-1.3,0,-1.3).curveTo(-0.3,-1.3,-0.6,-1.1).curveTo(-0.7,-0.9,-0.8,-0.6).lineTo(-1.5,-0.7).curveTo(-1.4,-1.2,-1,-1.6).curveTo(-0.5,-1.9,0,-1.9).curveTo(0.8,-1.9,1.2,-1.6).curveTo(1.5,-1.2,1.6,-0.6).lineTo(1.6,1.2).lineTo(1.6,1.8).lineTo(0.9,1.8).lineTo(0.8,1.3).curveTo(0.5,1.9,-0.3,1.9).curveTo(-0.9,1.9,-1.2,1.6).closePath().moveTo(-0.3,0.2).curveTo(-0.8,0.4,-0.8,0.8).curveTo(-0.8,0.8,-0.8,0.9).curveTo(-0.8,0.9,-0.8,1).curveTo(-0.7,1,-0.7,1.1).curveTo(-0.7,1.1,-0.7,1.2).curveTo(-0.6,1.2,-0.6,1.2).curveTo(-0.5,1.2,-0.5,1.3).curveTo(-0.4,1.3,-0.3,1.3).curveTo(-0.3,1.3,-0.2,1.3).curveTo(0.8,1.3,0.8,0.2).lineTo(0.8,0.1).closePath();
	this.shape_83.setTransform(566.15,120.35);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.8,2.7).lineTo(0.8,0.6).curveTo(0.8,-0.4,0,-0.4).curveTo(-0.4,-0.4,-0.6,-0.1).curveTo(-0.8,0.2,-0.9,0.6).lineTo(-0.9,2.7).lineTo(-1.6,2.7).lineTo(-1.6,-2.7).lineTo(-0.9,-2.7).lineTo(-0.9,-0.5).curveTo(-0.5,-1,0.2,-1).curveTo(0.9,-1,1.2,-0.6).curveTo(1.5,-0.2,1.6,0.4).lineTo(1.6,2.7).closePath();
	this.shape_84.setTransform(562.2,119.425);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.3).curveTo(-1.7,0.8,-1.7,-0).curveTo(-1.7,-0.8,-1.2,-1.4).curveTo(-0.7,-1.9,0.1,-1.9).curveTo(0.8,-1.9,1.2,-1.6).curveTo(1.6,-1.2,1.7,-0.7).lineTo(1.1,-0.5).curveTo(0.9,-1.3,0.1,-1.3).curveTo(-0.4,-1.3,-0.7,-0.9).curveTo(-1,-0.6,-1,-0).curveTo(-1,0.6,-0.7,1).curveTo(-0.4,1.2,0.1,1.2).curveTo(0.9,1.2,1.1,0.5).lineTo(1.7,0.8).curveTo(1.6,1.2,1.2,1.5).curveTo(0.7,1.9,0.1,1.9).curveTo(-0.7,1.9,-1.2,1.3).closePath();
	this.shape_85.setTransform(558.125,120.35);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.3,2.2).curveTo(-1.8,1.7,-1.8,0.9).curveTo(-1.8,0.1,-1.3,-0.5).curveTo(-0.8,-1,-0.1,-1).curveTo(0.8,-1,1,-0.4).lineTo(1,-2.8).lineTo(1.7,-2.8).lineTo(1.7,2).lineTo(1.8,2.7).lineTo(1.1,2.7).lineTo(1.1,2.2).lineTo(1.1,2.1).curveTo(0.7,2.8,-0.1,2.8).curveTo(-0.8,2.8,-1.3,2.2).closePath().moveTo(-0.8,-0.1).curveTo(-1.1,0.3,-1.1,0.9).curveTo(-1.1,1.4,-0.8,1.8).curveTo(-0.5,2.2,0,2.2).curveTo(0.5,2.2,0.8,1.8).curveTo(1,1.4,1,0.8).curveTo(1,0.3,0.8,-0.1).curveTo(0.5,-0.4,0,-0.4).curveTo(-0.5,-0.4,-0.8,-0.1).closePath();
	this.shape_86.setTransform(551.925,119.475);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.8,1.8).lineTo(0.8,-0.3).curveTo(0.8,-1.2,0,-1.2).curveTo(-0.4,-1.2,-0.7,-1).curveTo(-0.9,-0.6,-0.9,-0.2).lineTo(-0.9,1.8).lineTo(-1.6,1.8).lineTo(-1.6,-1.8).lineTo(-0.9,-1.8).lineTo(-0.9,-1.2).curveTo(-0.5,-1.9,0.2,-1.9).curveTo(0.9,-1.9,1.2,-1.4).curveTo(1.5,-1.1,1.6,-0.4).lineTo(1.6,1.8).closePath();
	this.shape_87.setTransform(547.8,120.3);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.6).curveTo(-1.6,1.3,-1.6,0.9).curveTo(-1.6,0.4,-1.2,0.1).curveTo(-0.9,-0.2,-0.4,-0.3).lineTo(0.6,-0.4).curveTo(0.6,-0.4,0.7,-0.4).curveTo(0.7,-0.5,0.7,-0.5).curveTo(0.8,-0.5,0.8,-0.6).curveTo(0.8,-0.6,0.8,-0.7).curveTo(0.8,-0.8,0.8,-0.8).curveTo(0.8,-0.9,0.8,-0.9).curveTo(0.7,-1,0.7,-1).curveTo(0.7,-1.1,0.7,-1.2).curveTo(0.4,-1.3,0,-1.3).curveTo(-0.3,-1.3,-0.6,-1.1).curveTo(-0.7,-0.9,-0.8,-0.6).lineTo(-1.5,-0.7).curveTo(-1.4,-1.2,-1,-1.6).curveTo(-0.5,-1.9,0,-1.9).curveTo(0.8,-1.9,1.2,-1.6).curveTo(1.5,-1.2,1.6,-0.6).lineTo(1.6,1.2).lineTo(1.6,1.8).lineTo(0.9,1.8).lineTo(0.8,1.3).curveTo(0.5,1.9,-0.3,1.9).curveTo(-0.9,1.9,-1.2,1.6).closePath().moveTo(-0.3,0.2).curveTo(-0.8,0.4,-0.8,0.8).curveTo(-0.8,0.8,-0.8,0.9).curveTo(-0.8,0.9,-0.8,1).curveTo(-0.7,1,-0.7,1.1).curveTo(-0.7,1.1,-0.7,1.2).curveTo(-0.6,1.2,-0.6,1.2).curveTo(-0.5,1.2,-0.5,1.3).curveTo(-0.4,1.3,-0.3,1.3).curveTo(-0.3,1.3,-0.2,1.3).curveTo(0.8,1.3,0.8,0.2).lineTo(0.8,0.1).closePath();
	this.shape_88.setTransform(543.65,120.35);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.4,2.7).lineTo(-0.4,-2.7).lineTo(0.3,-2.7).lineTo(0.3,2.7).closePath();
	this.shape_89.setTransform(538.95,119.425);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.6).curveTo(-1.6,1.3,-1.6,0.9).curveTo(-1.6,0.4,-1.2,0.1).curveTo(-0.9,-0.2,-0.4,-0.3).lineTo(0.6,-0.4).curveTo(0.6,-0.4,0.7,-0.4).curveTo(0.7,-0.5,0.7,-0.5).curveTo(0.8,-0.5,0.8,-0.6).curveTo(0.8,-0.6,0.8,-0.7).curveTo(0.8,-0.8,0.8,-0.8).curveTo(0.8,-0.9,0.8,-0.9).curveTo(0.7,-1,0.7,-1).curveTo(0.7,-1.1,0.7,-1.2).curveTo(0.4,-1.3,0,-1.3).curveTo(-0.3,-1.3,-0.6,-1.1).curveTo(-0.7,-0.9,-0.8,-0.6).lineTo(-1.5,-0.7).curveTo(-1.4,-1.2,-1,-1.6).curveTo(-0.5,-1.9,0,-1.9).curveTo(0.8,-1.9,1.2,-1.6).curveTo(1.5,-1.2,1.6,-0.6).lineTo(1.6,1.2).lineTo(1.6,1.8).lineTo(0.9,1.8).lineTo(0.8,1.3).curveTo(0.5,1.9,-0.3,1.9).curveTo(-0.9,1.9,-1.2,1.6).closePath().moveTo(-0.3,0.2).curveTo(-0.8,0.4,-0.8,0.8).curveTo(-0.8,0.8,-0.8,0.9).curveTo(-0.8,0.9,-0.8,1).curveTo(-0.7,1,-0.7,1.1).curveTo(-0.7,1.1,-0.7,1.2).curveTo(-0.6,1.2,-0.6,1.2).curveTo(-0.5,1.2,-0.5,1.3).curveTo(-0.4,1.3,-0.3,1.3).curveTo(-0.3,1.3,-0.2,1.3).curveTo(0.8,1.3,0.8,0.2).lineTo(0.8,0.1).closePath();
	this.shape_90.setTransform(536,120.35);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.3,1.8).lineTo(-1.8,-1.8).lineTo(-1,-1.8).lineTo(0,1).lineTo(1.1,-1.8).lineTo(1.8,-1.8).lineTo(0.4,1.8).closePath();
	this.shape_91.setTransform(532.225,120.35);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.4,1.3).curveTo(-1.8,0.8,-1.8,-0).curveTo(-1.8,-0.8,-1.4,-1.4).curveTo(-0.8,-1.9,-0,-1.9).curveTo(0.8,-1.9,1.3,-1.4).curveTo(1.8,-0.8,1.8,-0).curveTo(1.8,0.8,1.3,1.3).curveTo(0.8,1.9,-0,1.9).curveTo(-0.8,1.9,-1.4,1.3).closePath().moveTo(-0.8,-0.9).curveTo(-1.2,-0.6,-1.1,-0).curveTo(-1.2,0.6,-0.8,1).curveTo(-0.5,1.3,-0,1.3).curveTo(0.5,1.3,0.8,1).curveTo(1.1,0.6,1.1,-0).curveTo(1.1,-0.6,0.8,-0.9).curveTo(0.5,-1.3,-0,-1.3).curveTo(-0.5,-1.3,-0.8,-0.9).closePath();
	this.shape_92.setTransform(528.25,120.35);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1,1.8).lineTo(-1,-1.8).lineTo(-0.3,-1.8).lineTo(-0.3,-1.2).curveTo(0,-1.8,0.7,-1.8).lineTo(1,-1.8).lineTo(1,-1.1).lineTo(0.7,-1.1).curveTo(-0.3,-1.1,-0.3,0).lineTo(-0.3,1.8).closePath();
	this.shape_93.setTransform(524.95,120.325);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.8,2.6).lineTo(-1.8,-2.5).lineTo(-1.1,-2.5).lineTo(-1.1,-1.9).curveTo(-0.7,-2.5,0.1,-2.6).curveTo(0.9,-2.5,1.3,-2).curveTo(1.8,-1.5,1.8,-0.7).curveTo(1.8,0.2,1.3,0.7).curveTo(0.9,1.3,0.1,1.2).curveTo(-0.7,1.2,-1.1,0.7).lineTo(-1.1,2.6).closePath().moveTo(-0.8,-1.6).curveTo(-1.1,-1.2,-1.1,-0.7).curveTo(-1.1,-0.1,-0.8,0.2).curveTo(-0.5,0.6,-0,0.6).curveTo(0.5,0.6,0.8,0.2).curveTo(1.1,-0.1,1.1,-0.7).curveTo(1.1,-1.2,0.8,-1.6).curveTo(0.5,-1.9,-0,-1.9).curveTo(-0.5,-1.9,-0.8,-1.6).closePath();
	this.shape_94.setTransform(521.325,121);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.8,2.6).lineTo(-1.8,-2.5).lineTo(-1.1,-2.5).lineTo(-1.1,-1.9).curveTo(-0.7,-2.5,0.1,-2.6).curveTo(0.9,-2.5,1.3,-2).curveTo(1.8,-1.5,1.8,-0.7).curveTo(1.8,0.2,1.3,0.7).curveTo(0.9,1.3,0.1,1.2).curveTo(-0.7,1.2,-1.1,0.7).lineTo(-1.1,2.6).closePath().moveTo(-0.8,-1.6).curveTo(-1.1,-1.2,-1.1,-0.7).curveTo(-1.1,-0.1,-0.8,0.2).curveTo(-0.5,0.6,-0,0.6).curveTo(0.5,0.6,0.8,0.2).curveTo(1.1,-0.1,1.1,-0.7).curveTo(1.1,-1.2,0.8,-1.6).curveTo(0.5,-1.9,-0,-1.9).curveTo(-0.5,-1.9,-0.8,-1.6).closePath();
	this.shape_95.setTransform(516.925,121);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.6).curveTo(-1.6,1.3,-1.5,0.9).curveTo(-1.6,0.4,-1.2,0.1).curveTo(-0.9,-0.2,-0.5,-0.3).lineTo(0.5,-0.4).curveTo(0.6,-0.4,0.7,-0.4).curveTo(0.7,-0.5,0.7,-0.5).curveTo(0.8,-0.5,0.8,-0.6).curveTo(0.8,-0.6,0.8,-0.7).curveTo(0.8,-0.8,0.8,-0.8).curveTo(0.8,-0.9,0.8,-0.9).curveTo(0.7,-1,0.7,-1).curveTo(0.7,-1.1,0.6,-1.2).curveTo(0.4,-1.3,0.1,-1.3).curveTo(-0.3,-1.3,-0.5,-1.1).curveTo(-0.7,-0.9,-0.8,-0.6).lineTo(-1.4,-0.7).curveTo(-1.4,-1.2,-1,-1.6).curveTo(-0.6,-1.9,0.1,-1.9).curveTo(0.8,-1.9,1.2,-1.6).curveTo(1.6,-1.2,1.5,-0.6).lineTo(1.5,1.2).lineTo(1.5,1.8).lineTo(0.9,1.8).lineTo(0.8,1.3).curveTo(0.4,1.9,-0.3,1.9).curveTo(-0.9,1.9,-1.2,1.6).closePath().moveTo(-0.3,0.2).curveTo(-0.8,0.4,-0.8,0.8).curveTo(-0.8,0.8,-0.8,0.9).curveTo(-0.8,0.9,-0.8,1).curveTo(-0.7,1,-0.7,1.1).curveTo(-0.7,1.1,-0.6,1.2).curveTo(-0.6,1.2,-0.6,1.2).curveTo(-0.5,1.2,-0.5,1.3).curveTo(-0.4,1.3,-0.3,1.3).curveTo(-0.3,1.3,-0.2,1.3).curveTo(0.8,1.3,0.8,0.2).lineTo(0.8,0.1).closePath();
	this.shape_96.setTransform(512.55,120.35);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,2.2).curveTo(-1.7,1.9,-1.7,1.3).lineTo(-1.1,1.1).curveTo(-1,1.5,-0.7,1.7).curveTo(-0.5,2,-0.1,2).curveTo(1,2,1,0.8).lineTo(1,0.3).curveTo(0.7,0.9,-0.1,0.9).curveTo(-0.8,0.9,-1.3,0.4).curveTo(-1.7,-0.1,-1.7,-0.8).curveTo(-1.7,-1.6,-1.3,-2.1).curveTo(-0.8,-2.6,-0.1,-2.6).curveTo(0.8,-2.6,1,-2).lineTo(1,-2.5).lineTo(1.7,-2.5).lineTo(1.7,0.8).curveTo(1.7,1.6,1.3,2.1).curveTo(0.9,2.6,-0.1,2.6).curveTo(-0.7,2.6,-1.2,2.2).closePath().moveTo(-0.7,-1.7).curveTo(-1,-1.4,-1,-0.8).curveTo(-1,-0.3,-0.7,-0).curveTo(-0.4,0.3,0,0.3).curveTo(0.5,0.3,0.8,-0).curveTo(1.1,-0.3,1.1,-0.8).curveTo(1.1,-1.4,0.8,-1.7).curveTo(0.5,-2,0,-2).curveTo(-0.4,-2,-0.7,-1.7).closePath();
	this.shape_97.setTransform(506.575,121.075);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.8,1.8).lineTo(0.8,-0.3).curveTo(0.8,-1.2,0,-1.2).curveTo(-0.4,-1.2,-0.6,-1).curveTo(-0.9,-0.6,-0.9,-0.2).lineTo(-0.9,1.8).lineTo(-1.5,1.8).lineTo(-1.5,-1.8).lineTo(-0.9,-1.8).lineTo(-0.9,-1.2).curveTo(-0.5,-1.9,0.3,-1.9).curveTo(0.9,-1.9,1.2,-1.4).curveTo(1.5,-1.1,1.6,-0.4).lineTo(1.6,1.8).closePath();
	this.shape_98.setTransform(502.45,120.3);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.4,2.7).lineTo(-0.4,-0.9).lineTo(0.4,-0.9).lineTo(0.4,2.7).closePath().moveTo(-0.4,-1.9).curveTo(-0.4,-1.9,-0.4,-1.9).curveTo(-0.4,-2,-0.5,-2).curveTo(-0.5,-2.1,-0.5,-2.1).curveTo(-0.5,-2.2,-0.5,-2.2).curveTo(-0.5,-2.3,-0.5,-2.3).curveTo(-0.5,-2.4,-0.5,-2.4).curveTo(-0.4,-2.5,-0.4,-2.5).curveTo(-0.4,-2.6,-0.4,-2.6).curveTo(-0.3,-2.6,-0.3,-2.7).curveTo(-0.2,-2.7,-0.2,-2.7).curveTo(-0.1,-2.7,-0.1,-2.7).curveTo(-0,-2.8,0,-2.8).curveTo(0.1,-2.8,0.1,-2.7).curveTo(0.1,-2.7,0.2,-2.7).curveTo(0.2,-2.7,0.3,-2.7).curveTo(0.3,-2.6,0.4,-2.6).curveTo(0.4,-2.6,0.4,-2.5).curveTo(0.4,-2.5,0.5,-2.4).curveTo(0.5,-2.4,0.5,-2.3).curveTo(0.5,-2.3,0.5,-2.2).curveTo(0.5,-2.2,0.5,-2.1).curveTo(0.5,-2.1,0.5,-2).curveTo(0.4,-2,0.4,-1.9).curveTo(0.4,-1.9,0.4,-1.9).curveTo(0.3,-1.8,0.3,-1.8).curveTo(0.2,-1.8,0.2,-1.7).curveTo(0.1,-1.7,0.1,-1.7).curveTo(0.1,-1.7,0,-1.7).curveTo(-0,-1.7,-0.1,-1.7).curveTo(-0.1,-1.7,-0.2,-1.7).curveTo(-0.2,-1.8,-0.3,-1.8).curveTo(-0.3,-1.8,-0.4,-1.9).closePath();
	this.shape_99.setTransform(499.4,119.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.9,1.8).lineTo(0.9,-0.3).curveTo(0.8,-1.2,0,-1.2).curveTo(-0.4,-1.2,-0.7,-1).curveTo(-0.9,-0.6,-0.9,-0.2).lineTo(-0.9,1.8).lineTo(-1.6,1.8).lineTo(-1.6,-1.8).lineTo(-0.9,-1.8).lineTo(-0.9,-1.2).curveTo(-0.5,-1.9,0.2,-1.9).curveTo(0.9,-1.9,1.2,-1.4).curveTo(1.5,-1.1,1.6,-0.4).lineTo(1.6,1.8).closePath();
	this.shape_100.setTransform(496.4,120.3);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.8,1.8).lineTo(0.8,-0.3).curveTo(0.9,-1.2,0,-1.2).curveTo(-0.4,-1.2,-0.6,-1).curveTo(-0.9,-0.6,-0.9,-0.2).lineTo(-0.9,1.8).lineTo(-1.5,1.8).lineTo(-1.5,-1.8).lineTo(-0.9,-1.8).lineTo(-0.9,-1.2).curveTo(-0.5,-1.9,0.3,-1.9).curveTo(0.8,-1.9,1.2,-1.4).curveTo(1.5,-1.1,1.5,-0.4).lineTo(1.5,1.8).closePath();
	this.shape_101.setTransform(492.2,120.3);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.6).curveTo(-1.5,1.3,-1.5,0.9).curveTo(-1.5,0.4,-1.2,0.1).curveTo(-0.9,-0.2,-0.4,-0.3).lineTo(0.6,-0.4).curveTo(0.6,-0.4,0.7,-0.4).curveTo(0.7,-0.5,0.7,-0.5).curveTo(0.8,-0.5,0.8,-0.6).curveTo(0.8,-0.6,0.8,-0.7).curveTo(0.8,-0.8,0.8,-0.8).curveTo(0.8,-0.9,0.8,-0.9).curveTo(0.7,-1,0.7,-1).curveTo(0.7,-1.1,0.6,-1.2).curveTo(0.5,-1.3,0,-1.3).curveTo(-0.3,-1.3,-0.5,-1.1).curveTo(-0.7,-0.9,-0.8,-0.6).lineTo(-1.4,-0.7).curveTo(-1.4,-1.2,-1,-1.6).curveTo(-0.5,-1.9,0,-1.9).curveTo(0.8,-1.9,1.2,-1.6).curveTo(1.5,-1.2,1.6,-0.6).lineTo(1.6,1.2).lineTo(1.6,1.8).lineTo(0.9,1.8).lineTo(0.8,1.3).curveTo(0.5,1.9,-0.3,1.9).curveTo(-0.8,1.9,-1.2,1.6).closePath().moveTo(-0.3,0.2).curveTo(-0.8,0.4,-0.8,0.8).curveTo(-0.8,0.8,-0.8,0.9).curveTo(-0.8,0.9,-0.8,1).curveTo(-0.7,1,-0.7,1.1).curveTo(-0.7,1.1,-0.6,1.2).curveTo(-0.6,1.2,-0.6,1.2).curveTo(-0.5,1.2,-0.5,1.3).curveTo(-0.4,1.3,-0.3,1.3).curveTo(-0.3,1.3,-0.2,1.3).curveTo(0.8,1.3,0.8,0.2).lineTo(0.8,0.1).closePath();
	this.shape_102.setTransform(488.05,120.35);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.4,2.7).lineTo(-0.4,-2.7).lineTo(0.3,-2.7).lineTo(0.3,2.7).closePath();
	this.shape_103.setTransform(485.2,119.425);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.8,2.6).lineTo(-1.8,-2.5).lineTo(-1.1,-2.5).lineTo(-1.1,-1.9).curveTo(-0.7,-2.5,0.1,-2.6).curveTo(0.9,-2.5,1.3,-2).curveTo(1.8,-1.5,1.8,-0.7).curveTo(1.8,0.2,1.3,0.7).curveTo(0.9,1.3,0.1,1.2).curveTo(-0.7,1.2,-1.1,0.7).lineTo(-1.1,2.6).closePath().moveTo(-0.8,-1.6).curveTo(-1.1,-1.2,-1.1,-0.7).curveTo(-1.1,-0.1,-0.8,0.2).curveTo(-0.5,0.6,-0,0.6).curveTo(0.5,0.6,0.8,0.2).curveTo(1.1,-0.1,1.1,-0.7).curveTo(1.1,-1.2,0.8,-1.6).curveTo(0.5,-1.9,-0,-1.9).curveTo(-0.5,-1.9,-0.8,-1.6).closePath();
	this.shape_104.setTransform(482.225,121);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.3,1.3).curveTo(-1.9,0.8,-1.9,-0).curveTo(-1.9,-0.8,-1.3,-1.4).curveTo(-0.8,-1.9,0,-1.9).curveTo(0.8,-1.9,1.3,-1.4).curveTo(1.9,-0.8,1.8,-0).curveTo(1.9,0.8,1.3,1.3).curveTo(0.8,1.9,0,1.9).curveTo(-0.8,1.9,-1.3,1.3).closePath().moveTo(-0.8,-0.9).curveTo(-1.1,-0.6,-1.1,-0).curveTo(-1.1,0.6,-0.8,1).curveTo(-0.5,1.3,0,1.3).curveTo(0.4,1.3,0.8,1).curveTo(1.1,0.6,1.1,-0).curveTo(1.1,-0.6,0.8,-0.9).curveTo(0.4,-1.3,0,-1.3).curveTo(-0.5,-1.3,-0.8,-0.9).closePath();
	this.shape_105.setTransform(475.9,120.35);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.1,2.1).curveTo(-0.4,1.8,-0.4,1.3).lineTo(-0.4,-0.6).lineTo(-1.1,-0.6).lineTo(-1.1,-1.3).lineTo(-0.9,-1.3).curveTo(-0.3,-1.2,-0.4,-1.8).lineTo(-0.4,-2.4).lineTo(0.3,-2.4).lineTo(0.3,-1.3).lineTo(1.1,-1.3).lineTo(1.1,-0.6).lineTo(0.3,-0.6).lineTo(0.3,1.2).curveTo(0.3,1.7,0.8,1.8).lineTo(1.1,1.7).lineTo(1.1,2.3).lineTo(0.6,2.4).curveTo(0.2,2.4,-0.1,2.1).closePath();
	this.shape_106.setTransform(472.35,119.8);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.1,2.1).curveTo(-0.4,1.8,-0.4,1.3).lineTo(-0.4,-0.6).lineTo(-1.1,-0.6).lineTo(-1.1,-1.3).lineTo(-0.9,-1.3).curveTo(-0.3,-1.2,-0.4,-1.8).lineTo(-0.4,-2.4).lineTo(0.3,-2.4).lineTo(0.3,-1.3).lineTo(1.1,-1.3).lineTo(1.1,-0.6).lineTo(0.3,-0.6).lineTo(0.3,1.2).curveTo(0.3,1.7,0.8,1.8).lineTo(1.1,1.7).lineTo(1.1,2.3).lineTo(0.6,2.4).curveTo(0.2,2.4,-0.1,2.1).closePath();
	this.shape_107.setTransform(467.85,119.8);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.3).curveTo(-1.7,0.8,-1.7,-0).curveTo(-1.7,-0.8,-1.2,-1.4).curveTo(-0.7,-1.9,0.1,-1.9).curveTo(0.8,-1.9,1.2,-1.6).curveTo(1.6,-1.2,1.7,-0.7).lineTo(1.1,-0.5).curveTo(0.9,-1.3,0.1,-1.3).curveTo(-0.4,-1.3,-0.7,-0.9).curveTo(-1,-0.6,-1,-0).curveTo(-1,0.6,-0.7,1).curveTo(-0.4,1.2,0.1,1.2).curveTo(0.9,1.2,1.1,0.5).lineTo(1.7,0.8).curveTo(1.6,1.2,1.2,1.5).curveTo(0.7,1.9,0.1,1.9).curveTo(-0.7,1.9,-1.2,1.3).closePath();
	this.shape_108.setTransform(464.675,120.35);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.4).curveTo(-1.7,0.8,-1.7,-0).curveTo(-1.7,-0.8,-1.2,-1.4).curveTo(-0.7,-1.9,0,-1.9).curveTo(0.8,-1.9,1.3,-1.4).curveTo(1.7,-0.9,1.7,-0).lineTo(1.7,0.2).lineTo(-1,0.2).curveTo(-1,0.7,-0.7,1).curveTo(-0.4,1.3,0.1,1.3).curveTo(0.9,1.3,1.1,0.5).lineTo(1.7,0.8).curveTo(1.6,1.3,1.1,1.6).curveTo(0.7,1.9,0.1,1.9).curveTo(-0.7,1.9,-1.2,1.4).closePath().moveTo(1,-0.4).curveTo(1,-0.8,0.7,-1).curveTo(0.5,-1.3,0,-1.3).curveTo(-0.4,-1.3,-0.7,-1).curveTo(-0.9,-0.7,-1,-0.4).lineTo(1,-0.4).lineTo(1,-0.4).closePath();
	this.shape_109.setTransform(460.625,120.35);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.8,3.5).lineTo(-0.8,2.9).lineTo(-0.6,2.9).curveTo(-0.1,2.9,-0.1,2.4).lineTo(-0.1,-1.6).lineTo(0.6,-1.6).lineTo(0.6,2.4).curveTo(0.6,2.9,0.4,3.2).curveTo(0.1,3.5,-0.4,3.5).lineTo(-0.8,3.5).closePath().moveTo(-0.1,-2.7).curveTo(-0.1,-2.7,-0.1,-2.8).curveTo(-0.2,-2.8,-0.2,-2.8).curveTo(-0.2,-2.9,-0.2,-2.9).curveTo(-0.2,-3,-0.2,-3).curveTo(-0.2,-3.1,-0.2,-3.1).curveTo(-0.2,-3.2,-0.2,-3.2).curveTo(-0.2,-3.3,-0.1,-3.3).curveTo(-0.1,-3.3,-0.1,-3.4).curveTo(-0,-3.4,0,-3.4).curveTo(0,-3.5,0.1,-3.5).curveTo(0.1,-3.5,0.2,-3.5).curveTo(0.2,-3.5,0.3,-3.5).curveTo(0.3,-3.5,0.4,-3.5).curveTo(0.4,-3.5,0.5,-3.5).curveTo(0.5,-3.5,0.5,-3.4).curveTo(0.6,-3.4,0.6,-3.4).curveTo(0.7,-3.3,0.7,-3.3).curveTo(0.7,-3.3,0.7,-3.2).curveTo(0.8,-3.2,0.8,-3.1).curveTo(0.8,-3.1,0.8,-3).curveTo(0.8,-3,0.8,-2.9).curveTo(0.8,-2.9,0.7,-2.8).curveTo(0.7,-2.8,0.7,-2.8).curveTo(0.7,-2.7,0.6,-2.7).curveTo(0.6,-2.6,0.5,-2.6).curveTo(0.5,-2.6,0.5,-2.6).curveTo(0.4,-2.5,0.4,-2.5).curveTo(0.3,-2.5,0.3,-2.5).curveTo(0.2,-2.5,0.2,-2.5).curveTo(0.1,-2.5,0.1,-2.6).curveTo(0,-2.6,0,-2.6).curveTo(-0,-2.6,-0.1,-2.7).closePath();
	this.shape_110.setTransform(457.375,120.175);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.1,2.2).lineTo(-1.1,2.7).lineTo(-1.8,2.7).lineTo(-1.8,-2.8).lineTo(-1.1,-2.8).lineTo(-1.1,-0.4).lineTo(-0.6,-0.9).curveTo(-0.3,-1,0.1,-1).curveTo(0.9,-1,1.4,-0.5).curveTo(1.8,0,1.8,0.9).curveTo(1.8,1.7,1.3,2.2).curveTo(0.9,2.8,0.1,2.8).curveTo(-0.7,2.8,-1.1,2.2).closePath().moveTo(-0.8,-0.1).curveTo(-1.1,0.3,-1.1,0.9).curveTo(-1.1,1.4,-0.8,1.8).curveTo(-0.5,2.1,-0,2.1).curveTo(0.5,2.1,0.8,1.8).curveTo(1.1,1.4,1.1,0.9).curveTo(1.1,0.3,0.8,-0.1).curveTo(0.5,-0.4,-0,-0.4).curveTo(-0.5,-0.4,-0.8,-0.1).closePath();
	this.shape_111.setTransform(454.675,119.475);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.5).curveTo(-1.6,1.1,-1.6,0.4).lineTo(-1.6,-1.9).lineTo(-0.9,-1.9).lineTo(-0.9,0.3).curveTo(-0.9,0.7,-0.7,0.9).curveTo(-0.5,1.3,-0,1.3).curveTo(0.4,1.3,0.6,1).curveTo(0.8,0.7,0.8,0.3).lineTo(0.8,-1.9).lineTo(1.5,-1.9).lineTo(1.5,1.1).lineTo(1.6,1.7).lineTo(0.9,1.7).lineTo(0.9,1.3).curveTo(0.6,1.9,-0.2,1.8).curveTo(-0.8,1.8,-1.2,1.5).closePath();
	this.shape_112.setTransform(450.225,120.4);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.4,2.3).curveTo(-1.9,1.8,-1.9,1.2).lineTo(-1.2,1).curveTo(-1.1,1.5,-0.9,1.8).curveTo(-0.5,2.1,0,2.1).curveTo(0.6,2.1,0.9,1.9).curveTo(1.2,1.6,1.1,1.3).curveTo(1.2,0.6,0.3,0.4).lineTo(-0.4,0.3).curveTo(-1,0.2,-1.3,-0.2).curveTo(-1.7,-0.6,-1.7,-1.2).curveTo(-1.7,-1.8,-1.2,-2.3).curveTo(-0.6,-2.8,0,-2.8).curveTo(0.9,-2.8,1.3,-2.3).curveTo(1.8,-2,1.9,-1.4).lineTo(1.2,-1.2).curveTo(1.2,-1.6,0.9,-1.8).curveTo(0.6,-2.1,0.1,-2.1).curveTo(-0.4,-2.1,-0.7,-1.9).curveTo(-0.9,-1.6,-0.9,-1.2).curveTo(-1,-0.6,-0.2,-0.5).lineTo(0.6,-0.3).curveTo(1.2,-0.1,1.6,0.3).curveTo(1.9,0.7,1.9,1.2).curveTo(1.9,1.9,1.4,2.3).curveTo(0.9,2.8,0,2.8).curveTo(-0.8,2.8,-1.4,2.3).closePath();
	this.shape_113.setTransform(445.9,119.475);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.4,0.4).curveTo(-0.4,0.3,-0.4,0.3).curveTo(-0.5,0.3,-0.5,0.2).curveTo(-0.5,0.2,-0.5,0.1).curveTo(-0.5,0,-0.5,-0).curveTo(-0.5,-0.1,-0.5,-0.1).curveTo(-0.5,-0.2,-0.5,-0.2).curveTo(-0.5,-0.3,-0.4,-0.3).curveTo(-0.4,-0.3,-0.4,-0.4).curveTo(-0.3,-0.4,-0.3,-0.4).curveTo(-0.3,-0.5,-0.2,-0.5).curveTo(-0.2,-0.5,-0.1,-0.5).curveTo(-0,-0.5,0,-0.5).curveTo(0.1,-0.5,0.1,-0.5).curveTo(0.2,-0.5,0.2,-0.5).curveTo(0.3,-0.5,0.3,-0.4).curveTo(0.3,-0.4,0.4,-0.4).curveTo(0.4,-0.3,0.4,-0.3).curveTo(0.5,-0.3,0.5,-0.2).curveTo(0.5,-0.2,0.5,-0.1).curveTo(0.5,-0.1,0.5,-0).curveTo(0.5,0,0.5,0.1).curveTo(0.5,0.2,0.5,0.2).curveTo(0.5,0.3,0.4,0.3).curveTo(0.4,0.3,0.4,0.4).curveTo(0.3,0.4,0.3,0.4).curveTo(0.3,0.5,0.2,0.5).curveTo(0.2,0.5,0.1,0.5).curveTo(0.1,0.5,0,0.5).curveTo(-0,0.5,-0.1,0.5).curveTo(-0.2,0.5,-0.2,0.5).curveTo(-0.3,0.5,-0.3,0.4).curveTo(-0.3,0.4,-0.4,0.4).closePath();
	this.shape_114.setTransform(440.825,121.675);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,2.6).lineTo(-0.3,0.7).lineTo(-1.9,-2.6).lineTo(-1.1,-2.6).lineTo(0.1,-0.1).lineTo(1.2,-2.6).lineTo(1.9,-2.6).lineTo(-0.5,2.6).closePath();
	this.shape_115.setTransform(437.85,121.1);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.3,2.7).lineTo(-0.3,-2.7).lineTo(0.4,-2.7).lineTo(0.4,2.7).closePath();
	this.shape_116.setTransform(434.95,119.425);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.9,1.8).lineTo(0.9,-0.3).curveTo(0.9,-1.2,-0,-1.2).curveTo(-0.4,-1.2,-0.7,-1).curveTo(-0.9,-0.6,-0.8,-0.2).lineTo(-0.8,1.8).lineTo(-1.6,1.8).lineTo(-1.6,-1.8).lineTo(-0.8,-1.8).lineTo(-0.8,-1.2).curveTo(-0.5,-1.9,0.2,-1.9).curveTo(0.8,-1.9,1.2,-1.4).curveTo(1.6,-1.1,1.6,-0.4).lineTo(1.6,1.8).closePath();
	this.shape_117.setTransform(431.95,120.3);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.4,1.3).curveTo(-1.8,0.8,-1.8,-0).curveTo(-1.8,-0.8,-1.4,-1.4).curveTo(-0.8,-1.9,-0,-1.9).curveTo(0.8,-1.9,1.3,-1.4).curveTo(1.8,-0.8,1.9,-0).curveTo(1.8,0.8,1.3,1.3).curveTo(0.8,1.9,-0,1.9).curveTo(-0.8,1.9,-1.4,1.3).closePath().moveTo(-0.8,-0.9).curveTo(-1.2,-0.6,-1.2,-0).curveTo(-1.2,0.6,-0.8,1).curveTo(-0.5,1.3,-0,1.3).curveTo(0.5,1.3,0.8,1).curveTo(1.1,0.6,1.1,-0).curveTo(1.1,-0.6,0.8,-0.9).curveTo(0.5,-1.3,-0,-1.3).curveTo(-0.5,-1.3,-0.8,-0.9).closePath();
	this.shape_118.setTransform(427.7,120.35);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.8,1.8).lineTo(0.8,-0.3).curveTo(0.9,-1.2,-0,-1.2).curveTo(-0.4,-1.2,-0.6,-1).curveTo(-0.8,-0.6,-0.8,-0.2).lineTo(-0.8,1.8).lineTo(-1.5,1.8).lineTo(-1.5,-1.8).lineTo(-0.8,-1.8).lineTo(-0.8,-1.2).curveTo(-0.5,-1.9,0.3,-1.9).curveTo(0.8,-1.9,1.2,-1.4).curveTo(1.6,-1.1,1.5,-0.4).lineTo(1.5,1.8).closePath();
	this.shape_119.setTransform(421.65,120.3);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.3,1.3).curveTo(-1.9,0.8,-1.9,-0).curveTo(-1.9,-0.8,-1.3,-1.4).curveTo(-0.8,-1.9,0,-1.9).curveTo(0.8,-1.9,1.3,-1.4).curveTo(1.9,-0.8,1.8,-0).curveTo(1.9,0.8,1.3,1.3).curveTo(0.8,1.9,0,1.9).curveTo(-0.8,1.9,-1.3,1.3).closePath().moveTo(-0.8,-0.9).curveTo(-1.1,-0.6,-1.1,-0).curveTo(-1.1,0.6,-0.8,1).curveTo(-0.5,1.3,0,1.3).curveTo(0.4,1.3,0.8,1).curveTo(1.1,0.6,1.1,-0).curveTo(1.1,-0.6,0.8,-0.9).curveTo(0.4,-1.3,0,-1.3).curveTo(-0.5,-1.3,-0.8,-0.9).closePath();
	this.shape_120.setTransform(417.4,120.35);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.4,2.7).lineTo(-0.4,-0.9).lineTo(0.4,-0.9).lineTo(0.4,2.7).closePath().moveTo(-0.4,-1.9).curveTo(-0.4,-1.9,-0.4,-1.9).curveTo(-0.4,-2,-0.5,-2).curveTo(-0.5,-2.1,-0.5,-2.1).curveTo(-0.5,-2.2,-0.5,-2.2).curveTo(-0.5,-2.3,-0.5,-2.3).curveTo(-0.5,-2.4,-0.5,-2.4).curveTo(-0.4,-2.5,-0.4,-2.5).curveTo(-0.4,-2.6,-0.4,-2.6).curveTo(-0.3,-2.6,-0.3,-2.7).curveTo(-0.2,-2.7,-0.2,-2.7).curveTo(-0.1,-2.7,-0.1,-2.7).curveTo(-0,-2.8,0,-2.8).curveTo(0.1,-2.8,0.1,-2.7).curveTo(0.1,-2.7,0.2,-2.7).curveTo(0.2,-2.7,0.3,-2.7).curveTo(0.3,-2.6,0.4,-2.6).curveTo(0.4,-2.6,0.4,-2.5).curveTo(0.4,-2.5,0.5,-2.4).curveTo(0.5,-2.4,0.5,-2.3).curveTo(0.5,-2.3,0.5,-2.2).curveTo(0.5,-2.2,0.5,-2.1).curveTo(0.5,-2.1,0.5,-2).curveTo(0.4,-2,0.4,-1.9).curveTo(0.4,-1.9,0.4,-1.9).curveTo(0.3,-1.8,0.3,-1.8).curveTo(0.2,-1.8,0.2,-1.7).curveTo(0.1,-1.7,0.1,-1.7).curveTo(0.1,-1.7,0,-1.7).curveTo(-0,-1.7,-0.1,-1.7).curveTo(-0.1,-1.7,-0.2,-1.7).curveTo(-0.2,-1.8,-0.3,-1.8).curveTo(-0.3,-1.8,-0.4,-1.9).closePath();
	this.shape_121.setTransform(414.35,119.4);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1,1.5).curveTo(-1.3,1.2,-1.4,0.9).lineTo(-0.8,0.6).curveTo(-0.7,1,-0.5,1.1).curveTo(-0.3,1.3,0.1,1.3).curveTo(0.2,1.3,0.2,1.3).curveTo(0.3,1.3,0.4,1.3).curveTo(0.4,1.2,0.5,1.2).curveTo(0.5,1.2,0.6,1.2).curveTo(0.6,1.1,0.6,1.1).curveTo(0.6,1.1,0.7,1).curveTo(0.7,1,0.7,0.9).curveTo(0.7,0.9,0.7,0.9).curveTo(0.7,0.4,0.2,0.3).lineTo(-0.4,0.2).curveTo(-0.8,0.2,-1,-0.1).curveTo(-1.3,-0.4,-1.3,-0.8).curveTo(-1.3,-1.2,-0.9,-1.6).curveTo(-0.5,-1.9,-0,-1.9).curveTo(0.7,-1.9,1,-1.6).curveTo(1.3,-1.3,1.4,-0.9).lineTo(0.8,-0.7).curveTo(0.7,-1.3,-0,-1.3).curveTo(-0.1,-1.3,-0.1,-1.3).curveTo(-0.2,-1.3,-0.2,-1.3).curveTo(-0.3,-1.2,-0.3,-1.2).curveTo(-0.4,-1.2,-0.5,-1.2).curveTo(-0.5,-1.1,-0.5,-1.1).curveTo(-0.5,-1.1,-0.6,-1).curveTo(-0.6,-1,-0.6,-0.9).curveTo(-0.6,-0.9,-0.6,-0.8).curveTo(-0.6,-0.5,-0.2,-0.4).lineTo(0.4,-0.3).curveTo(1.4,-0.1,1.4,0.8).curveTo(1.4,1.2,1.1,1.5).curveTo(0.7,1.9,0.1,1.9).curveTo(-0.6,1.9,-1,1.5).closePath();
	this.shape_122.setTransform(411.7,120.35);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1,1.5).curveTo(-1.3,1.2,-1.4,0.9).lineTo(-0.7,0.6).curveTo(-0.7,1,-0.5,1.1).curveTo(-0.3,1.3,0.1,1.3).curveTo(0.2,1.3,0.2,1.3).curveTo(0.3,1.3,0.4,1.3).curveTo(0.4,1.2,0.5,1.2).curveTo(0.5,1.2,0.5,1.2).curveTo(0.6,1.1,0.6,1.1).curveTo(0.6,1.1,0.7,1).curveTo(0.7,1,0.7,0.9).curveTo(0.7,0.9,0.7,0.9).curveTo(0.7,0.4,0.3,0.3).lineTo(-0.4,0.2).curveTo(-0.8,0.2,-1,-0.1).curveTo(-1.3,-0.4,-1.3,-0.8).curveTo(-1.3,-1.2,-0.9,-1.6).curveTo(-0.5,-1.9,-0,-1.9).curveTo(0.7,-1.9,1.1,-1.6).curveTo(1.3,-1.3,1.4,-0.9).lineTo(0.8,-0.7).curveTo(0.6,-1.3,-0,-1.3).curveTo(-0.1,-1.3,-0.1,-1.3).curveTo(-0.2,-1.3,-0.2,-1.3).curveTo(-0.3,-1.2,-0.3,-1.2).curveTo(-0.4,-1.2,-0.5,-1.2).curveTo(-0.5,-1.1,-0.5,-1.1).curveTo(-0.5,-1.1,-0.6,-1).curveTo(-0.6,-1,-0.6,-0.9).curveTo(-0.6,-0.9,-0.6,-0.8).curveTo(-0.6,-0.5,-0.2,-0.4).lineTo(0.4,-0.3).curveTo(1.4,-0.1,1.4,0.8).curveTo(1.4,1.2,1.1,1.5).curveTo(0.7,1.9,0.1,1.9).curveTo(-0.6,1.9,-1,1.5).closePath();
	this.shape_123.setTransform(408.35,120.35);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.2,1.4).curveTo(-1.7,0.8,-1.7,-0).curveTo(-1.7,-0.8,-1.2,-1.4).curveTo(-0.7,-1.9,0,-1.9).curveTo(0.8,-1.9,1.3,-1.4).curveTo(1.7,-0.9,1.7,-0).lineTo(1.7,0.2).lineTo(-1,0.2).curveTo(-1,0.7,-0.7,1).curveTo(-0.4,1.3,0.1,1.3).curveTo(0.9,1.3,1.1,0.5).lineTo(1.7,0.8).curveTo(1.6,1.3,1.1,1.6).curveTo(0.7,1.9,0.1,1.9).curveTo(-0.7,1.9,-1.2,1.4).closePath().moveTo(1,-0.4).curveTo(1,-0.8,0.7,-1).curveTo(0.5,-1.3,0,-1.3).curveTo(-0.4,-1.3,-0.7,-1).curveTo(-0.9,-0.7,-1,-0.4).lineTo(1,-0.4).lineTo(1,-0.4).closePath();
	this.shape_124.setTransform(404.675,120.35);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1,1.8).lineTo(-1,-1.8).lineTo(-0.3,-1.8).lineTo(-0.3,-1.2).curveTo(0,-1.8,0.7,-1.8).lineTo(1,-1.8).lineTo(1,-1.1).lineTo(0.7,-1.1).curveTo(-0.3,-1.1,-0.3,0).lineTo(-0.3,1.8).closePath();
	this.shape_125.setTransform(401.5,120.325);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.8,2.6).lineTo(-1.8,-2.5).lineTo(-1.1,-2.5).lineTo(-1.1,-1.9).curveTo(-0.7,-2.5,0.1,-2.6).curveTo(0.9,-2.5,1.3,-2).curveTo(1.8,-1.5,1.8,-0.7).curveTo(1.8,0.2,1.3,0.7).curveTo(0.9,1.3,0.1,1.2).curveTo(-0.7,1.2,-1.1,0.7).lineTo(-1.1,2.6).closePath().moveTo(-0.8,-1.6).curveTo(-1.1,-1.2,-1.1,-0.7).curveTo(-1.1,-0.1,-0.8,0.2).curveTo(-0.5,0.6,-0,0.6).curveTo(0.5,0.6,0.8,0.2).curveTo(1.1,-0.1,1.1,-0.7).curveTo(1.1,-1.2,0.8,-1.6).curveTo(0.5,-1.9,-0,-1.9).curveTo(-0.5,-1.9,-0.8,-1.6).closePath();
	this.shape_126.setTransform(397.875,121);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.9,1.8).lineTo(1.9,-0.4).curveTo(1.9,-1.2,1.2,-1.2).curveTo(0.8,-1.3,0.6,-1).curveTo(0.3,-0.7,0.3,-0.3).lineTo(0.3,1.8).lineTo(-0.3,1.8).lineTo(-0.3,-0.4).curveTo(-0.3,-1.2,-1.1,-1.2).curveTo(-1.5,-1.3,-1.7,-1).curveTo(-2,-0.8,-1.9,-0.3).lineTo(-1.9,1.8).lineTo(-2.7,1.8).lineTo(-2.7,-1.8).lineTo(-2,-1.8).lineTo(-2,-1.3).curveTo(-1.7,-1.8,-0.9,-1.9).curveTo(-0.1,-1.8,0.2,-1.2).curveTo(0.6,-1.8,1.4,-1.9).curveTo(1.9,-1.9,2.2,-1.6).curveTo(2.7,-1.1,2.7,-0.5).lineTo(2.7,1.8).closePath();
	this.shape_127.setTransform(392.35,120.3);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.4,2.7).lineTo(-0.4,-0.9).lineTo(0.3,-0.9).lineTo(0.3,2.7).closePath().moveTo(-0.4,-1.9).curveTo(-0.4,-1.9,-0.4,-1.9).curveTo(-0.4,-2,-0.5,-2).curveTo(-0.5,-2.1,-0.5,-2.1).curveTo(-0.5,-2.2,-0.5,-2.2).curveTo(-0.5,-2.3,-0.5,-2.3).curveTo(-0.5,-2.4,-0.5,-2.4).curveTo(-0.4,-2.5,-0.4,-2.5).curveTo(-0.4,-2.6,-0.4,-2.6).curveTo(-0.3,-2.6,-0.3,-2.7).curveTo(-0.2,-2.7,-0.2,-2.7).curveTo(-0.1,-2.7,-0.1,-2.7).curveTo(-0.1,-2.8,-0,-2.8).curveTo(0,-2.8,0.1,-2.7).curveTo(0.1,-2.7,0.2,-2.7).curveTo(0.2,-2.7,0.3,-2.7).curveTo(0.3,-2.6,0.3,-2.6).curveTo(0.4,-2.6,0.4,-2.5).curveTo(0.4,-2.5,0.5,-2.4).curveTo(0.5,-2.4,0.5,-2.3).curveTo(0.5,-2.3,0.5,-2.2).curveTo(0.5,-2.2,0.5,-2.1).curveTo(0.5,-2.1,0.5,-2).curveTo(0.4,-2,0.4,-1.9).curveTo(0.4,-1.9,0.3,-1.9).curveTo(0.3,-1.8,0.3,-1.8).curveTo(0.2,-1.8,0.2,-1.7).curveTo(0.1,-1.7,0.1,-1.7).curveTo(0,-1.7,-0,-1.7).curveTo(-0.1,-1.7,-0.1,-1.7).curveTo(-0.1,-1.7,-0.2,-1.7).curveTo(-0.2,-1.8,-0.3,-1.8).curveTo(-0.3,-1.8,-0.4,-1.9).closePath();
	this.shape_128.setTransform(388.2,119.4);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.1,2.1).curveTo(-0.4,1.8,-0.4,1.3).lineTo(-0.4,-0.6).lineTo(-1.1,-0.6).lineTo(-1.1,-1.3).lineTo(-0.9,-1.3).curveTo(-0.4,-1.2,-0.3,-1.8).lineTo(-0.3,-2.4).lineTo(0.3,-2.4).lineTo(0.3,-1.3).lineTo(1.1,-1.3).lineTo(1.1,-0.6).lineTo(0.3,-0.6).lineTo(0.3,1.2).curveTo(0.3,1.7,0.8,1.8).lineTo(1.1,1.7).lineTo(1.1,2.3).lineTo(0.6,2.4).curveTo(0.1,2.4,-0.1,2.1).closePath();
	this.shape_129.setTransform(384,119.8);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1,1.5).curveTo(-1.3,1.2,-1.4,0.9).lineTo(-0.7,0.6).curveTo(-0.7,1,-0.5,1.1).curveTo(-0.3,1.3,0.1,1.3).curveTo(0.2,1.3,0.2,1.3).curveTo(0.3,1.3,0.4,1.3).curveTo(0.4,1.2,0.5,1.2).curveTo(0.5,1.2,0.6,1.2).curveTo(0.6,1.1,0.6,1.1).curveTo(0.6,1.1,0.7,1).curveTo(0.7,1,0.7,0.9).curveTo(0.7,0.9,0.7,0.9).curveTo(0.7,0.4,0.3,0.3).lineTo(-0.4,0.2).curveTo(-0.8,0.2,-1.1,-0.1).curveTo(-1.3,-0.4,-1.3,-0.8).curveTo(-1.3,-1.2,-0.9,-1.6).curveTo(-0.5,-1.9,0,-1.9).curveTo(0.6,-1.9,1.1,-1.6).curveTo(1.3,-1.3,1.4,-0.9).lineTo(0.7,-0.7).curveTo(0.6,-1.3,0,-1.3).curveTo(-0.1,-1.3,-0.1,-1.3).curveTo(-0.2,-1.3,-0.2,-1.3).curveTo(-0.3,-1.2,-0.3,-1.2).curveTo(-0.4,-1.2,-0.4,-1.2).curveTo(-0.5,-1.1,-0.5,-1.1).curveTo(-0.5,-1.1,-0.6,-1).curveTo(-0.6,-1,-0.6,-0.9).curveTo(-0.6,-0.9,-0.6,-0.8).curveTo(-0.6,-0.5,-0.2,-0.4).lineTo(0.4,-0.3).curveTo(1.4,-0.1,1.4,0.8).curveTo(1.4,1.2,1.1,1.5).curveTo(0.7,1.9,0.1,1.9).curveTo(-0.6,1.9,-1,1.5).closePath();
	this.shape_130.setTransform(381.05,120.35);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.3,2.7).lineTo(-0.3,-0.9).lineTo(0.3,-0.9).lineTo(0.3,2.7).closePath().moveTo(-0.3,-1.9).curveTo(-0.4,-1.9,-0.4,-1.9).curveTo(-0.4,-2,-0.5,-2).curveTo(-0.5,-2.1,-0.5,-2.1).curveTo(-0.5,-2.2,-0.5,-2.2).curveTo(-0.5,-2.3,-0.5,-2.3).curveTo(-0.5,-2.4,-0.5,-2.4).curveTo(-0.4,-2.5,-0.4,-2.5).curveTo(-0.4,-2.6,-0.3,-2.6).curveTo(-0.3,-2.6,-0.3,-2.7).curveTo(-0.2,-2.7,-0.2,-2.7).curveTo(-0.1,-2.7,-0.1,-2.7).curveTo(-0,-2.8,0,-2.8).curveTo(0.1,-2.8,0.1,-2.7).curveTo(0.1,-2.7,0.2,-2.7).curveTo(0.2,-2.7,0.3,-2.7).curveTo(0.3,-2.6,0.3,-2.6).curveTo(0.4,-2.6,0.4,-2.5).curveTo(0.4,-2.5,0.5,-2.4).curveTo(0.5,-2.4,0.5,-2.3).curveTo(0.5,-2.3,0.5,-2.2).curveTo(0.5,-2.2,0.5,-2.1).curveTo(0.5,-2.1,0.5,-2).curveTo(0.4,-2,0.4,-1.9).curveTo(0.4,-1.9,0.3,-1.9).curveTo(0.3,-1.8,0.3,-1.8).curveTo(0.2,-1.8,0.2,-1.7).curveTo(0.1,-1.7,0.1,-1.7).curveTo(0.1,-1.7,0,-1.7).curveTo(-0,-1.7,-0.1,-1.7).curveTo(-0.1,-1.7,-0.2,-1.7).curveTo(-0.2,-1.8,-0.3,-1.8).curveTo(-0.3,-1.8,-0.3,-1.9).closePath();
	this.shape_131.setTransform(378.5,119.4);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.1,2.1).curveTo(-0.4,1.8,-0.4,1.3).lineTo(-0.4,-0.6).lineTo(-1.1,-0.6).lineTo(-1.1,-1.3).lineTo(-0.9,-1.3).curveTo(-0.3,-1.2,-0.3,-1.8).lineTo(-0.3,-2.4).lineTo(0.3,-2.4).lineTo(0.3,-1.3).lineTo(1.1,-1.3).lineTo(1.1,-0.6).lineTo(0.3,-0.6).lineTo(0.3,1.2).curveTo(0.3,1.7,0.8,1.8).lineTo(1.1,1.7).lineTo(1.1,2.3).lineTo(0.6,2.4).curveTo(0.2,2.4,-0.1,2.1).closePath();
	this.shape_132.setTransform(376.15,119.8);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1,1.8).lineTo(-1,-1.8).lineTo(-0.3,-1.8).lineTo(-0.3,-1.2).curveTo(0,-1.8,0.7,-1.8).lineTo(1,-1.8).lineTo(1,-1.1).lineTo(0.7,-1.1).curveTo(-0.3,-1.1,-0.3,0).lineTo(-0.3,1.8).closePath();
	this.shape_133.setTransform(373.75,120.325);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.8,2.6).lineTo(1.2,1.2).lineTo(-1.2,1.2).lineTo(-1.7,2.6).lineTo(-2.5,2.6).lineTo(-0.4,-2.7).lineTo(0.4,-2.7).lineTo(2.5,2.6).closePath().moveTo(0.9,0.5).lineTo(-0,-1.9).lineTo(-0.9,0.5).lineTo(0.9,0.5).closePath();
	this.shape_134.setTransform(369.55,119.5);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.beginFill("#FFFFFF").beginStroke().moveTo(98.6,3.1).curveTo(98.1,2.8,98.1,2.2).lineTo(98.7,2).curveTo(98.8,2.4,99.1,2.6).curveTo(99.3,2.9,99.7,2.9).curveTo(100.8,2.9,100.8,1.7).lineTo(100.8,1.2).curveTo(100.5,1.8,99.7,1.8).curveTo(99,1.8,98.5,1.3).curveTo(98.1,0.8,98.1,0.1).curveTo(98.1,-0.7,98.5,-1.2).curveTo(99,-1.7,99.7,-1.7).curveTo(100.6,-1.7,100.8,-1.1).lineTo(100.8,-1.6).lineTo(101.5,-1.6).lineTo(101.5,1.7).curveTo(101.5,2.5,101.1,3).curveTo(100.7,3.5,99.7,3.5).curveTo(99.1,3.5,98.6,3.1).closePath().moveTo(99.1,-0.8).curveTo(98.8,-0.5,98.8,0.1).curveTo(98.8,0.6,99.1,0.9).curveTo(99.4,1.2,99.8,1.2).curveTo(100.3,1.2,100.6,0.9).curveTo(100.9,0.6,100.9,0.1).curveTo(100.9,-0.5,100.6,-0.8).curveTo(100.3,-1.1,99.8,-1.1).curveTo(99.4,-1.1,99.1,-0.8).closePath().moveTo(30.7,3.1).curveTo(30.3,2.8,30.2,2.2).lineTo(30.9,2).curveTo(30.9,2.4,31.2,2.6).curveTo(31.5,2.9,31.9,2.9).curveTo(33,2.9,33,1.7).lineTo(33,1.2).curveTo(32.7,1.8,31.9,1.8).curveTo(31.2,1.8,30.7,1.3).curveTo(30.2,0.8,30.2,0.1).curveTo(30.2,-0.7,30.7,-1.2).curveTo(31.1,-1.7,31.9,-1.7).curveTo(32.7,-1.7,33,-1.1).lineTo(33,-1.6).lineTo(33.7,-1.6).lineTo(33.7,1.7).curveTo(33.7,2.5,33.3,3).curveTo(32.8,3.5,31.9,3.5).curveTo(31.2,3.5,30.7,3.1).closePath().moveTo(31.2,-0.8).curveTo(30.9,-0.5,30.9,0.1).curveTo(30.9,0.6,31.2,0.9).curveTo(31.5,1.2,32,1.2).curveTo(32.4,1.2,32.7,0.9).curveTo(33,0.6,33,0.1).curveTo(33,-0.5,32.7,-0.8).curveTo(32.4,-1.1,32,-1.1).curveTo(31.5,-1.1,31.2,-0.8).closePath().moveTo(-18,3.5).lineTo(-18,2.9).lineTo(-17.8,2.9).curveTo(-17.3,2.9,-17.3,2.4).lineTo(-17.3,-1.6).lineTo(-16.6,-1.6).lineTo(-16.6,2.4).curveTo(-16.6,2.9,-16.9,3.2).curveTo(-17.2,3.5,-17.6,3.5).lineTo(-18,3.5).closePath().moveTo(-38,3.5).lineTo(-37.1,1.6).lineTo(-38.7,-1.6).lineTo(-37.8,-1.6).lineTo(-36.7,0.9).lineTo(-35.6,-1.6).lineTo(-34.9,-1.6).lineTo(-37.2,3.5).closePath().moveTo(44.9,3.4).lineTo(44.9,-1.6).lineTo(45.6,-1.6).lineTo(45.6,-1.1).curveTo(46,-1.7,46.8,-1.7).curveTo(47.6,-1.7,48,-1.2).curveTo(48.5,-0.7,48.5,0.2).curveTo(48.5,1,48,1.5).curveTo(47.6,2.1,46.8,2.1).curveTo(46,2.1,45.6,1.5).lineTo(45.6,3.4).closePath().moveTo(45.9,-0.7).curveTo(45.6,-0.4,45.6,0.2).curveTo(45.6,0.7,45.9,1.1).curveTo(46.2,1.4,46.7,1.4).curveTo(47.2,1.4,47.5,1.1).curveTo(47.8,0.7,47.8,0.2).curveTo(47.8,-0.4,47.5,-0.7).curveTo(47.2,-1.1,46.7,-1.1).curveTo(46.2,-1.1,45.9,-0.7).closePath().moveTo(40.5,3.4).lineTo(40.5,-1.6).lineTo(41.2,-1.6).lineTo(41.2,-1.1).curveTo(41.6,-1.7,42.4,-1.7).curveTo(43.2,-1.7,43.6,-1.2).curveTo(44.1,-0.7,44.1,0.2).curveTo(44.1,1,43.6,1.5).curveTo(43.2,2.1,42.4,2.1).curveTo(41.6,2.1,41.2,1.5).lineTo(41.2,3.4).closePath().moveTo(41.5,-0.7).curveTo(41.2,-0.4,41.2,0.2).curveTo(41.2,0.7,41.5,1.1).curveTo(41.8,1.4,42.3,1.4).curveTo(42.8,1.4,43.1,1.1).curveTo(43.4,0.7,43.4,0.2).curveTo(43.4,-0.4,43.1,-0.7).curveTo(42.8,-1.1,42.3,-1.1).curveTo(41.8,-1.1,41.5,-0.7).closePath().moveTo(5.8,3.4).lineTo(5.8,-1.6).lineTo(6.5,-1.6).lineTo(6.5,-1.1).curveTo(6.9,-1.7,7.7,-1.7).curveTo(8.5,-1.7,8.9,-1.2).curveTo(9.4,-0.7,9.4,0.2).curveTo(9.4,1,8.9,1.5).curveTo(8.5,2.1,7.7,2.1).curveTo(6.9,2.1,6.5,1.5).lineTo(6.5,3.4).closePath().moveTo(6.8,-0.7).curveTo(6.5,-0.4,6.5,0.2).curveTo(6.5,0.7,6.8,1.1).curveTo(7.1,1.4,7.6,1.4).curveTo(8.1,1.4,8.4,1.1).curveTo(8.7,0.7,8.7,0.2).curveTo(8.7,-0.4,8.4,-0.7).curveTo(8.1,-1.1,7.6,-1.1).curveTo(7.1,-1.1,6.8,-0.7).closePath().moveTo(-78.5,3.4).lineTo(-78.5,-1.6).lineTo(-77.8,-1.6).lineTo(-77.8,-1.1).curveTo(-77.5,-1.7,-76.6,-1.7).curveTo(-75.9,-1.7,-75.4,-1.2).curveTo(-75,-0.7,-75,0.2).curveTo(-75,1,-75.4,1.5).curveTo(-75.9,2.1,-76.7,2.1).curveTo(-77.5,2.1,-77.8,1.5).lineTo(-77.8,3.4).closePath().moveTo(-77.5,-0.7).curveTo(-77.8,-0.4,-77.8,0.2).curveTo(-77.8,0.7,-77.5,1.1).curveTo(-77.2,1.4,-76.8,1.4).curveTo(-76.3,1.4,-76,1.1).curveTo(-75.7,0.7,-75.7,0.2).curveTo(-75.7,-0.4,-76,-0.7).curveTo(-76.3,-1.1,-76.8,-1.1).curveTo(-77.2,-1.1,-77.5,-0.7).closePath().moveTo(102.9,1.6).curveTo(102.3,1,102.3,0.2).curveTo(102.3,-0.7,102.9,-1.2).curveTo(103.4,-1.7,104.1,-1.7).curveTo(104.9,-1.7,105.3,-1.2).curveTo(105.8,-0.7,105.8,0.1).lineTo(105.8,0.4).lineTo(103.1,0.4).curveTo(103.1,0.9,103.4,1.2).curveTo(103.7,1.5,104.1,1.5).curveTo(104.9,1.5,105.2,0.7).lineTo(105.8,0.9).curveTo(105.6,1.4,105.2,1.8).curveTo(104.8,2.1,104.1,2.1).curveTo(103.4,2.1,102.9,1.6).closePath().moveTo(105.1,-0.2).curveTo(105,-0.6,104.8,-0.9).curveTo(104.5,-1.1,104.1,-1.1).curveTo(103.6,-1.1,103.4,-0.8).curveTo(103.1,-0.6,103.1,-0.2).lineTo(105.1,-0.2).lineTo(105.1,-0.2).closePath().moveTo(90.3,1.8).curveTo(90,1.5,90,1).curveTo(90,0.5,90.3,0.3).curveTo(90.6,-0,91.1,-0.1).lineTo(92.1,-0.2).curveTo(92.1,-0.2,92.2,-0.3).curveTo(92.2,-0.3,92.3,-0.3).curveTo(92.3,-0.4,92.3,-0.4).curveTo(92.3,-0.5,92.3,-0.5).curveTo(92.3,-0.6,92.3,-0.6).curveTo(92.3,-0.7,92.3,-0.8).curveTo(92.3,-0.8,92.2,-0.9).curveTo(92.2,-0.9,92.2,-1).curveTo(92,-1.1,91.6,-1.1).curveTo(91.2,-1.1,91,-0.9).curveTo(90.8,-0.7,90.7,-0.4).lineTo(90.1,-0.6).curveTo(90.1,-1.1,90.5,-1.4).curveTo(91,-1.7,91.6,-1.7).curveTo(92.3,-1.7,92.7,-1.4).curveTo(93.1,-1,93.1,-0.4).lineTo(93.1,1.4).lineTo(93.1,2).lineTo(92.4,2).lineTo(92.4,1.5).curveTo(92,2.1,91.2,2.1).curveTo(90.7,2.1,90.3,1.8).closePath().moveTo(91.2,0.4).curveTo(90.7,0.5,90.7,1).curveTo(90.7,1,90.7,1.1).curveTo(90.7,1.1,90.8,1.2).curveTo(90.8,1.2,90.8,1.2).curveTo(90.8,1.3,90.9,1.3).curveTo(90.9,1.4,91,1.4).curveTo(91,1.4,91.1,1.4).curveTo(91.1,1.5,91.2,1.5).curveTo(91.3,1.5,91.3,1.5).curveTo(92.3,1.5,92.3,0.4).lineTo(92.3,0.3).closePath().moveTo(82.3,1.5).curveTo(81.8,1,81.8,0.2).curveTo(81.8,-0.7,82.3,-1.2).curveTo(82.8,-1.7,83.6,-1.7).curveTo(84.3,-1.7,84.7,-1.4).curveTo(85.1,-1.1,85.2,-0.6).lineTo(84.6,-0.3).curveTo(84.4,-1.1,83.6,-1.1).curveTo(83.1,-1.1,82.8,-0.8).curveTo(82.5,-0.4,82.5,0.2).curveTo(82.5,0.8,82.8,1.1).curveTo(83.1,1.4,83.6,1.4).curveTo(84.4,1.4,84.6,0.7).lineTo(85.2,1).curveTo(85.1,1.4,84.7,1.7).curveTo(84.2,2.1,83.6,2.1).curveTo(82.8,2.1,82.3,1.5).closePath().moveTo(76,1.5).curveTo(75.5,1,75.5,0.2).curveTo(75.5,-0.6,76,-1.2).curveTo(76.5,-1.7,77.2,-1.7).curveTo(78.1,-1.7,78.3,-1.1).lineTo(78.3,-3.5).lineTo(79,-3.5).lineTo(79,1.3).lineTo(79.1,2).lineTo(78.4,2).lineTo(78.4,1.5).lineTo(78.4,1.4).curveTo(78,2.1,77.2,2.1).curveTo(76.5,2.1,76,1.5).closePath().moveTo(76.5,-0.8).curveTo(76.2,-0.4,76.2,0.2).curveTo(76.2,0.7,76.5,1.1).curveTo(76.8,1.5,77.3,1.5).curveTo(77.8,1.5,78.1,1.1).curveTo(78.3,0.7,78.3,0.1).curveTo(78.3,-0.4,78.1,-0.8).curveTo(77.8,-1.1,77.3,-1.1).curveTo(76.8,-1.1,76.5,-0.8).closePath().moveTo(67.8,1.8).curveTo(67.5,1.5,67.5,1).curveTo(67.5,0.5,67.8,0.3).curveTo(68.1,-0,68.6,-0.1).lineTo(69.6,-0.2).curveTo(69.6,-0.2,69.7,-0.3).curveTo(69.7,-0.3,69.8,-0.3).curveTo(69.8,-0.4,69.8,-0.4).curveTo(69.8,-0.5,69.8,-0.5).curveTo(69.8,-0.6,69.8,-0.6).curveTo(69.8,-0.7,69.8,-0.8).curveTo(69.8,-0.8,69.7,-0.9).curveTo(69.7,-0.9,69.7,-1).curveTo(69.5,-1.1,69.1,-1.1).curveTo(68.7,-1.1,68.5,-0.9).curveTo(68.3,-0.7,68.2,-0.4).lineTo(67.6,-0.6).curveTo(67.6,-1.1,68,-1.4).curveTo(68.5,-1.7,69.1,-1.7).curveTo(69.8,-1.7,70.2,-1.4).curveTo(70.6,-1,70.6,-0.4).lineTo(70.6,1.4).lineTo(70.6,2).lineTo(69.9,2).lineTo(69.9,1.5).curveTo(69.5,2.1,68.7,2.1).curveTo(68.2,2.1,67.8,1.8).closePath().moveTo(68.7,0.4).curveTo(68.2,0.5,68.2,1).curveTo(68.2,1,68.2,1.1).curveTo(68.2,1.1,68.3,1.2).curveTo(68.3,1.2,68.3,1.2).curveTo(68.3,1.3,68.4,1.3).curveTo(68.4,1.4,68.5,1.4).curveTo(68.5,1.4,68.6,1.4).curveTo(68.6,1.5,68.7,1.5).curveTo(68.8,1.5,68.8,1.5).curveTo(69.8,1.5,69.8,0.4).lineTo(69.8,0.3).closePath().moveTo(60.2,1.8).curveTo(59.8,1.5,59.8,1).curveTo(59.8,0.5,60.2,0.3).curveTo(60.5,-0,60.9,-0.1).lineTo(61.9,-0.2).curveTo(62,-0.2,62,-0.3).curveTo(62.1,-0.3,62.1,-0.3).curveTo(62.1,-0.4,62.2,-0.4).curveTo(62.2,-0.5,62.2,-0.5).curveTo(62.2,-0.6,62.2,-0.6).curveTo(62.2,-0.7,62.1,-0.8).curveTo(62.1,-0.8,62.1,-0.9).curveTo(62.1,-0.9,62,-1).curveTo(61.8,-1.1,61.4,-1.1).curveTo(61.1,-1.1,60.8,-0.9).curveTo(60.6,-0.7,60.6,-0.4).lineTo(59.9,-0.6).curveTo(60,-1.1,60.4,-1.4).curveTo(60.8,-1.7,61.4,-1.7).curveTo(62.2,-1.7,62.6,-1.4).curveTo(62.9,-1,62.9,-0.4).lineTo(62.9,1.4).lineTo(62.9,2).lineTo(62.3,2).lineTo(62.2,1.5).curveTo(61.8,2.1,61.1,2.1).curveTo(60.5,2.1,60.2,1.8).closePath().moveTo(61.1,0.4).curveTo(60.6,0.5,60.6,1).curveTo(60.6,1,60.6,1.1).curveTo(60.6,1.1,60.6,1.2).curveTo(60.6,1.2,60.7,1.2).curveTo(60.7,1.3,60.7,1.3).curveTo(60.8,1.4,60.8,1.4).curveTo(60.9,1.4,60.9,1.4).curveTo(61,1.5,61,1.5).curveTo(61.1,1.5,61.2,1.5).curveTo(62.2,1.5,62.2,0.4).lineTo(62.2,0.3).closePath().moveTo(52.3,1.5).curveTo(51.8,1,51.8,0.2).curveTo(51.8,-0.7,52.3,-1.2).curveTo(52.8,-1.7,53.6,-1.7).curveTo(54.4,-1.7,54.9,-1.2).curveTo(55.5,-0.7,55.5,0.2).curveTo(55.5,1,54.9,1.5).curveTo(54.4,2.1,53.6,2.1).curveTo(52.8,2.1,52.3,1.5).closePath().moveTo(52.8,-0.8).curveTo(52.5,-0.4,52.5,0.2).curveTo(52.5,0.8,52.8,1.1).curveTo(53.1,1.5,53.6,1.5).curveTo(54.1,1.5,54.4,1.1).curveTo(54.7,0.8,54.7,0.2).curveTo(54.7,-0.4,54.4,-0.8).curveTo(54.1,-1.1,53.6,-1.1).curveTo(53.1,-1.1,52.8,-0.8).closePath().moveTo(36.7,1.8).curveTo(36.4,1.5,36.4,1).curveTo(36.4,0.5,36.7,0.3).curveTo(37,-0,37.5,-0.1).lineTo(38.5,-0.2).curveTo(38.5,-0.2,38.6,-0.3).curveTo(38.6,-0.3,38.7,-0.3).curveTo(38.7,-0.4,38.7,-0.4).curveTo(38.7,-0.5,38.7,-0.5).curveTo(38.7,-0.6,38.7,-0.6).curveTo(38.7,-0.7,38.7,-0.8).curveTo(38.7,-0.8,38.6,-0.9).curveTo(38.6,-0.9,38.6,-1).curveTo(38.4,-1.1,38,-1.1).curveTo(37.6,-1.1,37.4,-0.9).curveTo(37.2,-0.7,37.1,-0.4).lineTo(36.5,-0.6).curveTo(36.5,-1.1,36.9,-1.4).curveTo(37.4,-1.7,38,-1.7).curveTo(38.7,-1.7,39.1,-1.4).curveTo(39.5,-1,39.5,-0.4).lineTo(39.5,1.4).lineTo(39.5,2).lineTo(38.8,2).lineTo(38.8,1.5).curveTo(38.4,2.1,37.6,2.1).curveTo(37.1,2.1,36.7,1.8).closePath().moveTo(37.6,0.4).curveTo(37.1,0.5,37.1,1).curveTo(37.1,1,37.1,1.1).curveTo(37.1,1.1,37.2,1.2).curveTo(37.2,1.2,37.2,1.2).curveTo(37.2,1.3,37.3,1.3).curveTo(37.3,1.4,37.4,1.4).curveTo(37.4,1.4,37.5,1.4).curveTo(37.5,1.5,37.6,1.5).curveTo(37.7,1.5,37.7,1.5).curveTo(38.7,1.5,38.7,0.4).lineTo(38.7,0.3).closePath().moveTo(12.2,1.8).curveTo(11.9,1.5,11.9,1).curveTo(11.9,0.5,12.2,0.3).curveTo(12.5,-0,13,-0.1).lineTo(14,-0.2).curveTo(14,-0.2,14.1,-0.3).curveTo(14.1,-0.3,14.2,-0.3).curveTo(14.2,-0.4,14.2,-0.4).curveTo(14.2,-0.5,14.2,-0.5).curveTo(14.2,-0.6,14.2,-0.6).curveTo(14.2,-0.7,14.2,-0.8).curveTo(14.2,-0.8,14.1,-0.9).curveTo(14.1,-0.9,14.1,-1).curveTo(13.9,-1.1,13.5,-1.1).curveTo(13.1,-1.1,12.9,-0.9).curveTo(12.7,-0.7,12.6,-0.4).lineTo(12,-0.6).curveTo(12,-1.1,12.4,-1.4).curveTo(12.9,-1.7,13.5,-1.7).curveTo(14.2,-1.7,14.6,-1.4).curveTo(15,-1,15,-0.4).lineTo(15,1.4).lineTo(15,2).lineTo(14.3,2).lineTo(14.3,1.5).curveTo(13.9,2.1,13.1,2.1).curveTo(12.6,2.1,12.2,1.8).closePath().moveTo(13.1,0.4).curveTo(12.6,0.5,12.6,1).curveTo(12.6,1,12.6,1.1).curveTo(12.6,1.1,12.7,1.2).curveTo(12.7,1.2,12.7,1.2).curveTo(12.7,1.3,12.8,1.3).curveTo(12.8,1.4,12.9,1.4).curveTo(12.9,1.4,13,1.4).curveTo(13,1.5,13.1,1.5).curveTo(13.2,1.5,13.2,1.5).curveTo(14.2,1.5,14.2,0.4).lineTo(14.2,0.3).closePath().moveTo(-0.1,1.5).curveTo(-0.6,1,-0.6,0.2).curveTo(-0.6,-0.7,-0.1,-1.2).curveTo(0.5,-1.7,1.3,-1.7).curveTo(2.1,-1.7,2.6,-1.2).curveTo(3.1,-0.7,3.1,0.2).curveTo(3.1,1,2.6,1.5).curveTo(2.1,2.1,1.3,2.1).curveTo(0.5,2.1,-0.1,1.5).closePath().moveTo(0.5,-0.8).curveTo(0.1,-0.4,0.1,0.2).curveTo(0.1,0.8,0.5,1.1).curveTo(0.8,1.5,1.3,1.5).curveTo(1.7,1.5,2.1,1.1).curveTo(2.4,0.8,2.4,0.2).curveTo(2.4,-0.4,2.1,-0.8).curveTo(1.7,-1.1,1.3,-1.1).curveTo(0.8,-1.1,0.5,-0.8).closePath().moveTo(-11.2,1.5).curveTo(-11.7,1,-11.7,0.2).curveTo(-11.7,-0.7,-11.2,-1.2).curveTo(-10.6,-1.7,-9.9,-1.7).curveTo(-9.2,-1.7,-8.8,-1.4).curveTo(-8.4,-1.1,-8.3,-0.6).lineTo(-8.9,-0.3).curveTo(-9.1,-1.1,-9.9,-1.1).curveTo(-10.3,-1.1,-10.6,-0.8).curveTo(-11,-0.4,-11,0.2).curveTo(-11,0.8,-10.6,1.1).curveTo(-10.3,1.4,-9.9,1.4).curveTo(-9.1,1.4,-8.8,0.7).lineTo(-8.2,1).curveTo(-8.4,1.4,-8.8,1.7).curveTo(-9.2,2.1,-9.9,2.1).curveTo(-10.6,2.1,-11.2,1.5).closePath().moveTo(-15.2,1.6).curveTo(-15.7,1,-15.7,0.2).curveTo(-15.7,-0.7,-15.2,-1.2).curveTo(-14.7,-1.7,-14,-1.7).curveTo(-13.2,-1.7,-12.7,-1.2).curveTo(-12.3,-0.7,-12.3,0.1).lineTo(-12.3,0.4).lineTo(-15,0.4).curveTo(-15,0.9,-14.7,1.2).curveTo(-14.4,1.5,-13.9,1.5).curveTo(-13.1,1.5,-12.9,0.7).lineTo(-12.3,0.9).curveTo(-12.4,1.4,-12.9,1.8).curveTo(-13.3,2.1,-13.9,2.1).curveTo(-14.7,2.1,-15.2,1.6).closePath().moveTo(-13,-0.2).curveTo(-13,-0.6,-13.3,-0.9).curveTo(-13.5,-1.1,-14,-1.1).curveTo(-14.4,-1.1,-14.7,-0.8).curveTo(-14.9,-0.6,-15,-0.2).lineTo(-13,-0.2).lineTo(-13,-0.2).closePath().moveTo(-21,1.5).lineTo(-21,2).lineTo(-21.7,2).lineTo(-21.7,-3.5).lineTo(-21,-3.5).lineTo(-21,-1.1).lineTo(-20.6,-1.6).curveTo(-20.3,-1.7,-19.8,-1.7).curveTo(-19,-1.7,-18.6,-1.2).curveTo(-18.2,-0.7,-18.2,0.2).curveTo(-18.2,1,-18.6,1.5).curveTo(-19.1,2.1,-19.9,2.1).curveTo(-20.7,2.1,-21,1.5).closePath().moveTo(-20.7,-0.8).curveTo(-21,-0.4,-21,0.2).curveTo(-21,0.7,-20.7,1.1).curveTo(-20.4,1.4,-20,1.4).curveTo(-19.5,1.4,-19.2,1.1).curveTo(-18.9,0.7,-18.9,0.2).curveTo(-18.9,-0.4,-19.2,-0.8).curveTo(-19.5,-1.1,-20,-1.1).curveTo(-20.4,-1.1,-20.7,-0.8).closePath().moveTo(-25.6,1.7).curveTo(-26,1.3,-26,0.6).lineTo(-26,-1.6).lineTo(-25.3,-1.6).lineTo(-25.3,0.5).curveTo(-25.3,0.9,-25.1,1.2).curveTo(-24.9,1.5,-24.4,1.5).curveTo(-24,1.5,-23.8,1.2).curveTo(-23.6,1,-23.6,0.5).lineTo(-23.6,-1.6).lineTo(-22.9,-1.6).lineTo(-22.9,1.3).lineTo(-22.8,2).lineTo(-23.5,2).lineTo(-23.5,1.5).curveTo(-23.8,2.1,-24.6,2.1).curveTo(-25.2,2.1,-25.6,1.7).closePath().moveTo(-30.1,1.6).curveTo(-30.6,1.1,-30.6,0.5).lineTo(-29.9,0.3).curveTo(-29.9,0.8,-29.6,1.1).curveTo(-29.2,1.4,-28.7,1.4).curveTo(-28.1,1.4,-27.8,1.2).curveTo(-27.6,0.9,-27.6,0.6).curveTo(-27.6,-0.1,-28.4,-0.3).lineTo(-29.1,-0.4).curveTo(-29.7,-0.5,-30,-0.9).curveTo(-30.4,-1.3,-30.4,-1.9).curveTo(-30.4,-2.5,-29.9,-3).curveTo(-29.4,-3.5,-28.7,-3.5).curveTo(-27.8,-3.5,-27.4,-3).curveTo(-27,-2.7,-26.9,-2.1).lineTo(-27.5,-1.9).curveTo(-27.6,-2.3,-27.8,-2.5).curveTo(-28.1,-2.8,-28.6,-2.8).curveTo(-29.1,-2.8,-29.4,-2.6).curveTo(-29.7,-2.3,-29.7,-1.9).curveTo(-29.7,-1.3,-29,-1.2).lineTo(-28.2,-1).curveTo(-27.5,-0.8,-27.2,-0.4).curveTo(-26.8,-0,-26.8,0.5).curveTo(-26.8,1.2,-27.3,1.6).curveTo(-27.8,2.1,-28.7,2.1).curveTo(-29.5,2.1,-30.1,1.6).closePath().moveTo(-48.3,1.5).curveTo(-48.8,1,-48.8,0.2).curveTo(-48.8,-0.7,-48.3,-1.2).curveTo(-47.7,-1.7,-46.9,-1.7).curveTo(-46.1,-1.7,-45.6,-1.2).curveTo(-45.1,-0.7,-45.1,0.2).curveTo(-45.1,1,-45.6,1.5).curveTo(-46.1,2.1,-46.9,2.1).curveTo(-47.7,2.1,-48.3,1.5).closePath().moveTo(-47.7,-0.8).curveTo(-48.1,-0.4,-48.1,0.2).curveTo(-48.1,0.8,-47.7,1.1).curveTo(-47.4,1.5,-46.9,1.5).curveTo(-46.5,1.5,-46.1,1.1).curveTo(-45.8,0.8,-45.8,0.2).curveTo(-45.8,-0.4,-46.1,-0.8).curveTo(-46.5,-1.1,-46.9,-1.1).curveTo(-47.4,-1.1,-47.7,-0.8).closePath().moveTo(-58.6,1.5).curveTo(-59.1,1,-59.1,0.2).curveTo(-59.1,-0.7,-58.6,-1.2).curveTo(-58,-1.7,-57.2,-1.7).curveTo(-56.4,-1.7,-55.9,-1.2).curveTo(-55.4,-0.7,-55.4,0.2).curveTo(-55.4,1,-55.9,1.5).curveTo(-56.4,2.1,-57.2,2.1).curveTo(-58,2.1,-58.6,1.5).closePath().moveTo(-58,-0.8).curveTo(-58.4,-0.4,-58.4,0.2).curveTo(-58.4,0.8,-58,1.1).curveTo(-57.7,1.5,-57.2,1.5).curveTo(-56.8,1.5,-56.4,1.1).curveTo(-56.1,0.8,-56.1,0.2).curveTo(-56.1,-0.4,-56.4,-0.8).curveTo(-56.8,-1.1,-57.2,-1.1).curveTo(-57.7,-1.1,-58,-0.8).closePath().moveTo(-63.9,1.7).curveTo(-64.3,1.4,-64.3,1).lineTo(-63.7,0.8).curveTo(-63.6,1.1,-63.4,1.3).curveTo(-63.2,1.5,-62.8,1.5).curveTo(-62.7,1.5,-62.7,1.5).curveTo(-62.6,1.5,-62.6,1.4).curveTo(-62.5,1.4,-62.5,1.4).curveTo(-62.4,1.4,-62.4,1.3).curveTo(-62.3,1.3,-62.3,1.3).curveTo(-62.3,1.2,-62.3,1.2).curveTo(-62.2,1.2,-62.2,1.1).curveTo(-62.2,1.1,-62.2,1).curveTo(-62.2,0.6,-62.7,0.5).lineTo(-63.3,0.4).curveTo(-63.7,0.3,-64,0).curveTo(-64.2,-0.2,-64.2,-0.6).curveTo(-64.2,-1.1,-63.8,-1.4).curveTo(-63.4,-1.7,-62.9,-1.7).curveTo(-62.3,-1.7,-61.9,-1.4).curveTo(-61.6,-1.1,-61.5,-0.8).lineTo(-62.2,-0.5).curveTo(-62.3,-1.1,-62.9,-1.1).curveTo(-63,-1.1,-63,-1.1).curveTo(-63.1,-1.1,-63.2,-1.1).curveTo(-63.2,-1.1,-63.3,-1).curveTo(-63.3,-1,-63.4,-1).curveTo(-63.4,-1,-63.4,-0.9).curveTo(-63.5,-0.9,-63.5,-0.8).curveTo(-63.5,-0.8,-63.5,-0.8).curveTo(-63.5,-0.7,-63.5,-0.7).curveTo(-63.5,-0.3,-63.1,-0.2).lineTo(-62.5,-0.1).curveTo(-61.5,0.1,-61.5,1).curveTo(-61.5,1.4,-61.8,1.7).curveTo(-62.2,2.1,-62.8,2.1).curveTo(-63.5,2.1,-63.9,1.7).closePath().moveTo(-67.3,1.7).curveTo(-67.6,1.4,-67.7,1).lineTo(-67,0.8).curveTo(-67,1.1,-66.8,1.3).curveTo(-66.6,1.5,-66.2,1.5).curveTo(-66.1,1.5,-66,1.5).curveTo(-66,1.5,-65.9,1.4).curveTo(-65.9,1.4,-65.8,1.4).curveTo(-65.8,1.4,-65.7,1.3).curveTo(-65.7,1.3,-65.7,1.3).curveTo(-65.6,1.2,-65.6,1.2).curveTo(-65.6,1.2,-65.6,1.1).curveTo(-65.6,1.1,-65.6,1).curveTo(-65.6,0.6,-66,0.5).lineTo(-66.7,0.4).curveTo(-67.1,0.3,-67.3,0).curveTo(-67.6,-0.2,-67.6,-0.6).curveTo(-67.6,-1.1,-67.2,-1.4).curveTo(-66.8,-1.7,-66.3,-1.7).curveTo(-65.6,-1.7,-65.2,-1.4).curveTo(-65,-1.1,-64.9,-0.8).lineTo(-65.5,-0.5).curveTo(-65.6,-1.1,-66.3,-1.1).curveTo(-66.3,-1.1,-66.4,-1.1).curveTo(-66.5,-1.1,-66.5,-1.1).curveTo(-66.6,-1.1,-66.6,-1).curveTo(-66.7,-1,-66.7,-1).curveTo(-66.8,-1,-66.8,-0.9).curveTo(-66.8,-0.9,-66.8,-0.8).curveTo(-66.9,-0.8,-66.9,-0.8).curveTo(-66.9,-0.7,-66.9,-0.7).curveTo(-66.9,-0.3,-66.5,-0.2).lineTo(-65.9,-0.1).curveTo(-64.9,0.1,-64.9,1).curveTo(-64.9,1.4,-65.2,1.7).curveTo(-65.6,2.1,-66.2,2.1).curveTo(-66.9,2.1,-67.3,1.7).closePath().moveTo(-71.1,1.6).curveTo(-71.7,1,-71.7,0.2).curveTo(-71.7,-0.7,-71.1,-1.2).curveTo(-70.6,-1.7,-69.9,-1.7).curveTo(-69.1,-1.7,-68.7,-1.2).curveTo(-68.2,-0.7,-68.2,0.1).lineTo(-68.2,0.4).lineTo(-70.9,0.4).curveTo(-70.9,0.9,-70.6,1.2).curveTo(-70.3,1.5,-69.9,1.5).curveTo(-69.1,1.5,-68.8,0.7).lineTo(-68.2,0.9).curveTo(-68.4,1.4,-68.8,1.8).curveTo(-69.2,2.1,-69.9,2.1).curveTo(-70.6,2.1,-71.1,1.6).closePath().moveTo(-68.9,-0.2).curveTo(-69,-0.6,-69.2,-0.9).curveTo(-69.5,-1.1,-69.9,-1.1).curveTo(-70.4,-1.1,-70.6,-0.8).curveTo(-70.9,-0.6,-70.9,-0.2).lineTo(-68.9,-0.2).lineTo(-68.9,-0.2).closePath().moveTo(-94.6,1.7).curveTo(-94.9,1.4,-95,1).lineTo(-94.3,0.8).curveTo(-94.3,1.1,-94.1,1.3).curveTo(-93.9,1.5,-93.5,1.5).curveTo(-93.4,1.5,-93.3,1.5).curveTo(-93.3,1.5,-93.2,1.4).curveTo(-93.2,1.4,-93.1,1.4).curveTo(-93.1,1.4,-93,1.3).curveTo(-93,1.3,-93,1.3).curveTo(-92.9,1.2,-92.9,1.2).curveTo(-92.9,1.2,-92.9,1.1).curveTo(-92.9,1.1,-92.9,1).curveTo(-92.9,0.6,-93.3,0.5).lineTo(-94,0.4).curveTo(-94.4,0.3,-94.6,0).curveTo(-94.9,-0.2,-94.9,-0.6).curveTo(-94.9,-1.1,-94.5,-1.4).curveTo(-94.1,-1.7,-93.6,-1.7).curveTo(-92.9,-1.7,-92.5,-1.4).curveTo(-92.3,-1.1,-92.2,-0.8).lineTo(-92.8,-0.5).curveTo(-92.9,-1.1,-93.6,-1.1).curveTo(-93.6,-1.1,-93.7,-1.1).curveTo(-93.8,-1.1,-93.8,-1.1).curveTo(-93.9,-1.1,-93.9,-1).curveTo(-94,-1,-94,-1).curveTo(-94.1,-1,-94.1,-0.9).curveTo(-94.1,-0.9,-94.1,-0.8).curveTo(-94.2,-0.8,-94.2,-0.8).curveTo(-94.2,-0.7,-94.2,-0.7).curveTo(-94.2,-0.3,-93.8,-0.2).lineTo(-93.2,-0.1).curveTo(-92.2,0.1,-92.2,1).curveTo(-92.2,1.4,-92.5,1.7).curveTo(-92.9,2.1,-93.5,2.1).curveTo(-94.2,2.1,-94.6,1.7).closePath().moveTo(106.7,1.9).curveTo(106.7,1.8,106.7,1.8).curveTo(106.6,1.8,106.6,1.7).curveTo(106.6,1.7,106.6,1.6).curveTo(106.6,1.5,106.6,1.5).curveTo(106.6,1.4,106.6,1.4).curveTo(106.6,1.3,106.6,1.3).curveTo(106.6,1.2,106.7,1.2).curveTo(106.7,1.2,106.7,1.1).curveTo(106.8,1.1,106.8,1.1).curveTo(106.9,1,106.9,1).curveTo(107,1,107,1).curveTo(107.1,1,107.1,1).curveTo(107.2,1,107.2,1).curveTo(107.3,1,107.3,1).curveTo(107.4,1,107.4,1.1).curveTo(107.4,1.1,107.5,1.1).curveTo(107.5,1.2,107.5,1.2).curveTo(107.6,1.2,107.6,1.3).curveTo(107.6,1.3,107.6,1.4).curveTo(107.6,1.4,107.6,1.5).curveTo(107.6,1.5,107.6,1.6).curveTo(107.6,1.7,107.6,1.7).curveTo(107.6,1.8,107.5,1.8).curveTo(107.5,1.8,107.5,1.9).curveTo(107.4,1.9,107.4,1.9).curveTo(107.4,2,107.3,2).curveTo(107.3,2,107.2,2).curveTo(107.2,2,107.1,2).curveTo(107.1,2,107,2).curveTo(107,2,106.9,2).curveTo(106.9,2,106.8,1.9).curveTo(106.8,1.9,106.7,1.9).closePath().moveTo(-2.4,1.7).curveTo(-2.7,1.5,-2.7,1).lineTo(-2.7,-1).lineTo(-3.4,-1).lineTo(-3.4,-1.6).lineTo(-3.2,-1.6).curveTo(-2.6,-1.6,-2.6,-2.2).lineTo(-2.6,-2.8).lineTo(-2,-2.8).lineTo(-2,-1.6).lineTo(-1.2,-1.6).lineTo(-1.2,-1).lineTo(-2,-1).lineTo(-2,0.9).curveTo(-2,1.4,-1.5,1.4).lineTo(-1.2,1.3).lineTo(-1.2,1.9).lineTo(-1.7,2).curveTo(-2.1,2,-2.4,1.7).closePath().moveTo(-6.9,1.7).curveTo(-7.2,1.5,-7.2,1).lineTo(-7.2,-1).lineTo(-7.9,-1).lineTo(-7.9,-1.6).lineTo(-7.7,-1.6).curveTo(-7.1,-1.6,-7.1,-2.2).lineTo(-7.1,-2.8).lineTo(-6.5,-2.8).lineTo(-6.5,-1.6).lineTo(-5.7,-1.6).lineTo(-5.7,-1).lineTo(-6.5,-1).lineTo(-6.5,0.9).curveTo(-6.5,1.4,-6,1.4).lineTo(-5.7,1.3).lineTo(-5.7,1.9).lineTo(-6.2,2).curveTo(-6.6,2,-6.9,1.7).closePath().moveTo(-34.2,1.9).curveTo(-34.2,1.8,-34.2,1.8).curveTo(-34.3,1.8,-34.3,1.7).curveTo(-34.3,1.7,-34.3,1.6).curveTo(-34.3,1.5,-34.3,1.5).curveTo(-34.3,1.4,-34.3,1.4).curveTo(-34.3,1.3,-34.3,1.3).curveTo(-34.3,1.2,-34.2,1.2).curveTo(-34.2,1.2,-34.2,1.1).curveTo(-34.1,1.1,-34.1,1.1).curveTo(-34.1,1,-34,1).curveTo(-34,1,-33.9,1).curveTo(-33.8,1,-33.8,1).curveTo(-33.7,1,-33.7,1).curveTo(-33.6,1,-33.6,1).curveTo(-33.5,1,-33.5,1.1).curveTo(-33.5,1.1,-33.4,1.1).curveTo(-33.4,1.2,-33.4,1.2).curveTo(-33.3,1.2,-33.3,1.3).curveTo(-33.3,1.3,-33.3,1.4).curveTo(-33.3,1.4,-33.3,1.5).curveTo(-33.3,1.5,-33.3,1.6).curveTo(-33.3,1.7,-33.3,1.7).curveTo(-33.3,1.8,-33.4,1.8).curveTo(-33.4,1.8,-33.4,1.9).curveTo(-33.5,1.9,-33.5,1.9).curveTo(-33.5,2,-33.6,2).curveTo(-33.6,2,-33.7,2).curveTo(-33.7,2,-33.8,2).curveTo(-33.8,2,-33.9,2).curveTo(-34,2,-34,2).curveTo(-34.1,2,-34.1,1.9).curveTo(-34.1,1.9,-34.2,1.9).closePath().moveTo(-90.8,1.7).curveTo(-91,1.5,-91,1).lineTo(-91,-1).lineTo(-91.7,-1).lineTo(-91.7,-1.6).lineTo(-91.5,-1.6).curveTo(-91,-1.6,-91,-2.2).lineTo(-91,-2.8).lineTo(-90.3,-2.8).lineTo(-90.3,-1.6).lineTo(-89.5,-1.6).lineTo(-89.5,-1).lineTo(-90.3,-1).lineTo(-90.3,0.9).curveTo(-90.3,1.4,-89.8,1.4).lineTo(-89.5,1.3).lineTo(-89.5,1.9).lineTo(-90,2).curveTo(-90.5,2,-90.8,1.7).closePath().moveTo(-98.6,1.7).curveTo(-98.9,1.5,-98.9,1).lineTo(-98.9,-1).lineTo(-99.6,-1).lineTo(-99.6,-1.6).lineTo(-99.4,-1.6).curveTo(-98.8,-1.6,-98.8,-2.2).lineTo(-98.8,-2.8).lineTo(-98.2,-2.8).lineTo(-98.2,-1.6).lineTo(-97.4,-1.6).lineTo(-97.4,-1).lineTo(-98.2,-1).lineTo(-98.2,0.9).curveTo(-98.2,1.4,-97.7,1.4).lineTo(-97.4,1.3).lineTo(-97.4,1.9).lineTo(-97.9,2).curveTo(-98.3,2,-98.6,1.7).closePath().moveTo(96.5,2).lineTo(96.5,-0.2).curveTo(96.5,-1.1,95.7,-1.1).curveTo(95.3,-1.1,95,-0.8).curveTo(94.8,-0.5,94.8,-0.1).lineTo(94.8,2).lineTo(94.1,2).lineTo(94.1,-1.6).lineTo(94.8,-1.6).lineTo(94.8,-1.1).curveTo(95.2,-1.7,95.9,-1.7).curveTo(96.5,-1.7,96.9,-1.3).curveTo(97.2,-0.9,97.2,-0.3).lineTo(97.2,2).closePath().moveTo(88.4,2).lineTo(88.4,-0.2).curveTo(88.4,-1.1,87.6,-1.1).curveTo(87.2,-1.1,87,-0.8).curveTo(86.7,-0.6,86.7,-0.1).lineTo(86.7,2).lineTo(86,2).lineTo(86,-3.5).lineTo(86.7,-3.5).lineTo(86.7,-1.2).curveTo(87.1,-1.7,87.8,-1.7).curveTo(88.4,-1.7,88.8,-1.3).curveTo(89.1,-0.9,89.1,-0.3).lineTo(89.1,2).closePath().moveTo(74,2).lineTo(74,-0.2).curveTo(74,-1.1,73.2,-1.1).curveTo(72.8,-1.1,72.5,-0.8).curveTo(72.3,-0.5,72.3,-0.1).lineTo(72.3,2).lineTo(71.6,2).lineTo(71.6,-1.6).lineTo(72.3,-1.6).lineTo(72.3,-1.1).curveTo(72.7,-1.7,73.4,-1.7).curveTo(74,-1.7,74.4,-1.3).curveTo(74.7,-0.9,74.7,-0.3).lineTo(74.7,2).closePath().moveTo(64,2).lineTo(64,-3.5).lineTo(64.7,-3.5).lineTo(64.7,2).closePath().moveTo(57.3,2).lineTo(55.8,-1.6).lineTo(56.6,-1.6).lineTo(57.6,1.2).lineTo(58.7,-1.6).lineTo(59.4,-1.6).lineTo(58,2).closePath().moveTo(49.3,2).lineTo(49.3,-1.6).lineTo(50,-1.6).lineTo(50,-1).curveTo(50.3,-1.7,51.1,-1.7).lineTo(51.3,-1.7).lineTo(51.3,-0.9).lineTo(51,-0.9).curveTo(50,-0.9,50,0.2).lineTo(50,2).closePath().moveTo(28.7,2).lineTo(28.7,-0.2).curveTo(28.7,-1.1,27.8,-1.1).curveTo(27.4,-1.1,27.2,-0.8).curveTo(27,-0.5,27,-0.1).lineTo(27,2).lineTo(26.3,2).lineTo(26.3,-1.6).lineTo(27,-1.6).lineTo(27,-1.1).curveTo(27.3,-1.7,28.1,-1.7).curveTo(28.7,-1.7,29,-1.3).curveTo(29.4,-0.9,29.4,-0.3).lineTo(29.4,2).closePath().moveTo(24.4,2).lineTo(24.4,-1.6).lineTo(25.1,-1.6).lineTo(25.1,2).closePath().moveTo(22.6,2).lineTo(22.6,-0.2).curveTo(22.6,-1.1,21.8,-1.1).curveTo(21.4,-1.1,21.1,-0.8).curveTo(20.9,-0.5,20.9,-0.1).lineTo(20.9,2).lineTo(20.2,2).lineTo(20.2,-1.6).lineTo(20.9,-1.6).lineTo(20.9,-1.1).curveTo(21.3,-1.7,22,-1.7).curveTo(22.6,-1.7,23,-1.3).curveTo(23.3,-0.9,23.3,-0.3).lineTo(23.3,2).closePath().moveTo(18.4,2).lineTo(18.4,-0.2).curveTo(18.4,-1.1,17.6,-1.1).curveTo(17.2,-1.1,16.9,-0.8).curveTo(16.7,-0.5,16.7,-0.1).lineTo(16.7,2).lineTo(16,2).lineTo(16,-1.6).lineTo(16.7,-1.6).lineTo(16.7,-1.1).curveTo(17.1,-1.7,17.8,-1.7).curveTo(18.4,-1.7,18.8,-1.3).curveTo(19.1,-0.9,19.1,-0.3).lineTo(19.1,2).closePath().moveTo(10.2,2).lineTo(10.2,-3.5).lineTo(10.9,-3.5).lineTo(10.9,2).closePath().moveTo(-40,2).lineTo(-40,-3.5).lineTo(-39.3,-3.5).lineTo(-39.3,2).closePath().moveTo(-41.8,2).lineTo(-41.8,-0.2).curveTo(-41.8,-1.1,-42.7,-1.1).curveTo(-43.1,-1.1,-43.3,-0.8).curveTo(-43.5,-0.5,-43.5,-0.1).lineTo(-43.5,2).lineTo(-44.2,2).lineTo(-44.2,-1.6).lineTo(-43.5,-1.6).lineTo(-43.5,-1.1).curveTo(-43.2,-1.7,-42.4,-1.7).curveTo(-41.8,-1.7,-41.5,-1.3).curveTo(-41.1,-0.9,-41.1,-0.3).lineTo(-41.1,2).closePath().moveTo(-52.1,2).lineTo(-52.1,-0.2).curveTo(-52.1,-1.1,-53,-1.1).curveTo(-53.4,-1.1,-53.6,-0.8).curveTo(-53.8,-0.5,-53.8,-0.1).lineTo(-53.8,2).lineTo(-54.5,2).lineTo(-54.5,-1.6).lineTo(-53.8,-1.6).lineTo(-53.8,-1.1).curveTo(-53.5,-1.7,-52.7,-1.7).curveTo(-52.1,-1.7,-51.8,-1.3).curveTo(-51.4,-0.9,-51.4,-0.3).lineTo(-51.4,2).closePath().moveTo(-60.6,2).lineTo(-60.6,-1.6).lineTo(-59.9,-1.6).lineTo(-59.9,2).closePath().moveTo(-74.1,2).lineTo(-74.1,-1.6).lineTo(-73.4,-1.6).lineTo(-73.4,-1).curveTo(-73.1,-1.7,-72.4,-1.7).lineTo(-72.1,-1.7).lineTo(-72.1,-0.9).lineTo(-72.4,-0.9).curveTo(-73.4,-0.9,-73.4,0.2).lineTo(-73.4,2).closePath().moveTo(-80.3,2).lineTo(-80.3,-0.3).curveTo(-80.3,-1.1,-81.1,-1.1).curveTo(-81.5,-1.1,-81.7,-0.9).curveTo(-81.9,-0.6,-81.9,-0.2).lineTo(-81.9,2).lineTo(-82.6,2).lineTo(-82.6,-0.3).curveTo(-82.6,-1.1,-83.4,-1.1).curveTo(-83.8,-1.1,-84,-0.9).curveTo(-84.2,-0.6,-84.2,-0.2).lineTo(-84.2,2).lineTo(-84.9,2).lineTo(-84.9,-1.6).lineTo(-84.3,-1.6).lineTo(-84.3,-1.2).curveTo(-83.9,-1.7,-83.2,-1.7).curveTo(-82.4,-1.7,-82.1,-1.1).curveTo(-81.7,-1.7,-80.9,-1.7).curveTo(-80.4,-1.7,-80,-1.4).curveTo(-79.6,-1,-79.6,-0.4).lineTo(-79.6,2).closePath().moveTo(-86.8,2).lineTo(-86.8,-1.6).lineTo(-86.1,-1.6).lineTo(-86.1,2).closePath().moveTo(-96.5,2).lineTo(-96.5,-1.6).lineTo(-95.8,-1.6).lineTo(-95.8,2).closePath().moveTo(-101.9,2).lineTo(-101.9,-1.6).lineTo(-101.2,-1.6).lineTo(-101.2,-1).curveTo(-100.9,-1.7,-100.1,-1.7).lineTo(-99.9,-1.7).lineTo(-99.9,-0.9).lineTo(-100.2,-0.9).curveTo(-101.2,-0.9,-101.2,0.2).lineTo(-101.2,2).closePath().moveTo(-103.3,2).lineTo(-103.9,0.5).lineTo(-106.3,0.5).lineTo(-106.8,2).lineTo(-107.6,2).lineTo(-105.5,-3.3).lineTo(-104.6,-3.3).lineTo(-102.5,2).closePath().moveTo(-104.2,-0.2).lineTo(-105.1,-2.6).lineTo(-106,-0.2).lineTo(-104.2,-0.2).closePath().moveTo(24.4,-2.6).curveTo(24.4,-2.7,24.4,-2.7).curveTo(24.3,-2.7,24.3,-2.8).curveTo(24.3,-2.8,24.3,-2.9).curveTo(24.3,-2.9,24.3,-3).curveTo(24.3,-3,24.3,-3.1).curveTo(24.3,-3.1,24.3,-3.2).curveTo(24.3,-3.2,24.4,-3.3).curveTo(24.4,-3.3,24.4,-3.4).curveTo(24.5,-3.4,24.5,-3.4).curveTo(24.5,-3.5,24.6,-3.5).curveTo(24.6,-3.5,24.7,-3.5).curveTo(24.7,-3.5,24.8,-3.5).curveTo(24.8,-3.5,24.9,-3.5).curveTo(24.9,-3.5,25,-3.5).curveTo(25,-3.5,25,-3.4).curveTo(25.1,-3.4,25.1,-3.4).curveTo(25.2,-3.3,25.2,-3.3).curveTo(25.2,-3.2,25.2,-3.2).curveTo(25.3,-3.1,25.3,-3.1).curveTo(25.3,-3,25.3,-3).curveTo(25.3,-2.9,25.3,-2.9).curveTo(25.3,-2.8,25.2,-2.8).curveTo(25.2,-2.7,25.2,-2.7).curveTo(25.2,-2.7,25.1,-2.6).curveTo(25.1,-2.6,25,-2.6).curveTo(25,-2.5,25,-2.5).curveTo(24.9,-2.5,24.9,-2.5).curveTo(24.8,-2.5,24.8,-2.5).curveTo(24.7,-2.5,24.7,-2.5).curveTo(24.6,-2.5,24.6,-2.5).curveTo(24.5,-2.5,24.5,-2.6).curveTo(24.5,-2.6,24.4,-2.6).closePath().moveTo(-60.6,-2.6).curveTo(-60.7,-2.7,-60.7,-2.7).curveTo(-60.7,-2.7,-60.7,-2.8).curveTo(-60.8,-2.8,-60.8,-2.9).curveTo(-60.8,-2.9,-60.8,-3).curveTo(-60.8,-3,-60.8,-3.1).curveTo(-60.8,-3.1,-60.7,-3.2).curveTo(-60.7,-3.2,-60.7,-3.3).curveTo(-60.7,-3.3,-60.6,-3.4).curveTo(-60.6,-3.4,-60.5,-3.4).curveTo(-60.5,-3.5,-60.5,-3.5).curveTo(-60.4,-3.5,-60.4,-3.5).curveTo(-60.3,-3.5,-60.3,-3.5).curveTo(-60.2,-3.5,-60.2,-3.5).curveTo(-60.1,-3.5,-60.1,-3.5).curveTo(-60,-3.5,-60,-3.4).curveTo(-60,-3.4,-59.9,-3.4).curveTo(-59.9,-3.3,-59.9,-3.3).curveTo(-59.8,-3.2,-59.8,-3.2).curveTo(-59.8,-3.1,-59.8,-3.1).curveTo(-59.8,-3,-59.8,-3).curveTo(-59.8,-2.9,-59.8,-2.9).curveTo(-59.8,-2.8,-59.8,-2.8).curveTo(-59.8,-2.7,-59.9,-2.7).curveTo(-59.9,-2.7,-59.9,-2.6).curveTo(-60,-2.6,-60,-2.6).curveTo(-60,-2.5,-60.1,-2.5).curveTo(-60.1,-2.5,-60.2,-2.5).curveTo(-60.2,-2.5,-60.3,-2.5).curveTo(-60.3,-2.5,-60.4,-2.5).curveTo(-60.4,-2.5,-60.5,-2.5).curveTo(-60.5,-2.5,-60.5,-2.6).curveTo(-60.6,-2.6,-60.6,-2.6).closePath().moveTo(-86.8,-2.6).curveTo(-86.8,-2.7,-86.8,-2.7).curveTo(-86.9,-2.7,-86.9,-2.8).curveTo(-86.9,-2.8,-86.9,-2.9).curveTo(-86.9,-2.9,-86.9,-3).curveTo(-86.9,-3,-86.9,-3.1).curveTo(-86.9,-3.1,-86.9,-3.2).curveTo(-86.9,-3.2,-86.8,-3.3).curveTo(-86.8,-3.3,-86.8,-3.4).curveTo(-86.7,-3.4,-86.7,-3.4).curveTo(-86.7,-3.5,-86.6,-3.5).curveTo(-86.6,-3.5,-86.5,-3.5).curveTo(-86.5,-3.5,-86.4,-3.5).curveTo(-86.4,-3.5,-86.3,-3.5).curveTo(-86.3,-3.5,-86.2,-3.5).curveTo(-86.2,-3.5,-86.2,-3.4).curveTo(-86.1,-3.4,-86.1,-3.4).curveTo(-86,-3.3,-86,-3.3).curveTo(-86,-3.2,-86,-3.2).curveTo(-85.9,-3.1,-85.9,-3.1).curveTo(-85.9,-3,-85.9,-3).curveTo(-85.9,-2.9,-85.9,-2.9).curveTo(-85.9,-2.8,-86,-2.8).curveTo(-86,-2.7,-86,-2.7).curveTo(-86,-2.7,-86.1,-2.6).curveTo(-86.1,-2.6,-86.2,-2.6).curveTo(-86.2,-2.5,-86.2,-2.5).curveTo(-86.3,-2.5,-86.3,-2.5).curveTo(-86.4,-2.5,-86.4,-2.5).curveTo(-86.5,-2.5,-86.5,-2.5).curveTo(-86.6,-2.5,-86.6,-2.5).curveTo(-86.7,-2.5,-86.7,-2.6).curveTo(-86.7,-2.6,-86.8,-2.6).closePath().moveTo(-96.5,-2.6).curveTo(-96.5,-2.7,-96.5,-2.7).curveTo(-96.6,-2.7,-96.6,-2.8).curveTo(-96.6,-2.8,-96.6,-2.9).curveTo(-96.6,-2.9,-96.6,-3).curveTo(-96.6,-3,-96.6,-3.1).curveTo(-96.6,-3.1,-96.6,-3.2).curveTo(-96.6,-3.2,-96.5,-3.3).curveTo(-96.5,-3.3,-96.5,-3.4).curveTo(-96.4,-3.4,-96.4,-3.4).curveTo(-96.4,-3.5,-96.3,-3.5).curveTo(-96.3,-3.5,-96.2,-3.5).curveTo(-96.2,-3.5,-96.1,-3.5).curveTo(-96.1,-3.5,-96,-3.5).curveTo(-96,-3.5,-95.9,-3.5).curveTo(-95.9,-3.5,-95.9,-3.4).curveTo(-95.8,-3.4,-95.8,-3.4).curveTo(-95.7,-3.3,-95.7,-3.3).curveTo(-95.7,-3.2,-95.7,-3.2).curveTo(-95.6,-3.1,-95.6,-3.1).curveTo(-95.6,-3,-95.6,-3).curveTo(-95.6,-2.9,-95.6,-2.9).curveTo(-95.6,-2.8,-95.7,-2.8).curveTo(-95.7,-2.7,-95.7,-2.7).curveTo(-95.7,-2.7,-95.8,-2.6).curveTo(-95.8,-2.6,-95.9,-2.6).curveTo(-95.9,-2.5,-95.9,-2.5).curveTo(-96,-2.5,-96,-2.5).curveTo(-96.1,-2.5,-96.1,-2.5).curveTo(-96.2,-2.5,-96.2,-2.5).curveTo(-96.3,-2.5,-96.3,-2.5).curveTo(-96.4,-2.5,-96.4,-2.6).curveTo(-96.4,-2.6,-96.5,-2.6).closePath().moveTo(-17.3,-2.7).curveTo(-17.4,-2.7,-17.4,-2.8).curveTo(-17.4,-2.8,-17.4,-2.8).curveTo(-17.5,-2.9,-17.5,-2.9).curveTo(-17.5,-3,-17.5,-3).curveTo(-17.5,-3.1,-17.5,-3.1).curveTo(-17.5,-3.2,-17.4,-3.2).curveTo(-17.4,-3.3,-17.4,-3.3).curveTo(-17.4,-3.3,-17.3,-3.4).curveTo(-17.3,-3.4,-17.2,-3.4).curveTo(-17.2,-3.5,-17.2,-3.5).curveTo(-17.1,-3.5,-17.1,-3.5).curveTo(-17,-3.5,-17,-3.5).curveTo(-16.9,-3.5,-16.9,-3.5).curveTo(-16.8,-3.5,-16.8,-3.5).curveTo(-16.7,-3.5,-16.7,-3.4).curveTo(-16.7,-3.4,-16.6,-3.4).curveTo(-16.6,-3.3,-16.6,-3.3).curveTo(-16.5,-3.3,-16.5,-3.2).curveTo(-16.5,-3.2,-16.5,-3.1).curveTo(-16.5,-3.1,-16.5,-3).curveTo(-16.5,-3,-16.5,-2.9).curveTo(-16.5,-2.9,-16.5,-2.8).curveTo(-16.5,-2.8,-16.6,-2.8).curveTo(-16.6,-2.7,-16.6,-2.7).curveTo(-16.7,-2.6,-16.7,-2.6).curveTo(-16.7,-2.6,-16.8,-2.6).curveTo(-16.8,-2.5,-16.9,-2.5).curveTo(-16.9,-2.5,-17,-2.5).curveTo(-17,-2.5,-17.1,-2.5).curveTo(-17.1,-2.5,-17.2,-2.6).curveTo(-17.2,-2.6,-17.2,-2.6).curveTo(-17.3,-2.6,-17.3,-2.7).closePath();
	this.shape_135.setTransform(476.625,84.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79}]}).wait(285));

	// Layer_4
	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-2,2.4).curveTo(-3,1.4,-3,-0.1).curveTo(-2.9,-1.5,-2.1,-2.3).curveTo(-1.2,-3.3,-0,-3.2).curveTo(1.4,-3.3,2.1,-2.3).curveTo(3,-1.5,3,-0.1).lineTo(2.9,0.4).lineTo(-1.7,0.4).curveTo(-1.7,1.1,-1.2,1.6).curveTo(-0.6,2.2,0.2,2.2).curveTo(1.4,2.2,1.9,0.9).lineTo(2.9,1.3).curveTo(2.6,2.1,2,2.7).curveTo(1.1,3.2,0.2,3.2).curveTo(-1.2,3.2,-2,2.4).closePath().moveTo(1.7,-0.6).curveTo(1.6,-1.3,1.2,-1.8).curveTo(0.8,-2.2,-0,-2.2).curveTo(-0.7,-2.2,-1.2,-1.7).curveTo(-1.6,-1.3,-1.6,-0.6).lineTo(1.7,-0.6).lineTo(1.7,-0.6).closePath();
	this.shape_136.setTransform(687.25,29.6);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.7,3.1).lineTo(-1.7,-3).lineTo(-0.5,-3).lineTo(-0.5,-1.9).curveTo(0,-3.1,1.3,-3.1).lineTo(1.7,-3.1).lineTo(1.7,-1.8).lineTo(1.2,-1.8).curveTo(-0.5,-1.9,-0.5,0.1).lineTo(-0.5,3.1).closePath();
	this.shape_137.setTransform(681.9,29.55);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-2.2,2.3).curveTo(-3.1,1.4,-3.1,0).curveTo(-3.1,-1.4,-2.2,-2.3).curveTo(-1.4,-3.3,0,-3.2).curveTo(1.4,-3.3,2.3,-2.3).curveTo(3.1,-1.4,3.1,0).curveTo(3.1,1.4,2.3,2.3).curveTo(1.4,3.2,0,3.2).curveTo(-1.4,3.2,-2.2,2.3).closePath().moveTo(-1.3,-1.6).curveTo(-1.9,-1.1,-1.9,0).curveTo(-1.9,1,-1.3,1.6).curveTo(-0.8,2.1,0,2.2).curveTo(0.8,2.1,1.3,1.6).curveTo(1.9,1,1.9,0).curveTo(1.9,-1.1,1.3,-1.6).curveTo(0.8,-2.2,0,-2.2).curveTo(-0.8,-2.2,-1.3,-1.6).closePath();
	this.shape_138.setTransform(675.625,29.6);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.beginFill("#2E2E2E").beginStroke().moveTo(3.3,3.2).lineTo(3.3,-0.7).curveTo(3.3,-2.1,2,-2.1).curveTo(1.4,-2.1,1,-1.7).curveTo(0.6,-1.2,0.6,-0.5).lineTo(0.6,3.2).lineTo(-0.6,3.2).lineTo(-0.6,-0.7).curveTo(-0.6,-2.1,-1.9,-2.1).curveTo(-2.5,-2.1,-2.9,-1.7).curveTo(-3.3,-1.2,-3.3,-0.5).lineTo(-3.3,3.2).lineTo(-4.5,3.2).lineTo(-4.5,-3).lineTo(-3.3,-3).lineTo(-3.3,-2.1).curveTo(-2.8,-3.2,-1.5,-3.1).curveTo(-0.2,-3.1,0.4,-2).curveTo(1,-3.1,2.4,-3.1).curveTo(3.2,-3.2,3.9,-2.6).curveTo(4.5,-2,4.5,-0.8).lineTo(4.5,3.2).closePath();
	this.shape_139.setTransform(666.7,29.5);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.7,3.1).lineTo(-1.7,-3).lineTo(-0.5,-3).lineTo(-0.5,-1.9).curveTo(0,-3.1,1.3,-3.1).lineTo(1.7,-3.1).lineTo(1.7,-1.8).lineTo(1.2,-1.8).curveTo(-0.5,-1.9,-0.5,0.1).lineTo(-0.5,3.1).closePath();
	this.shape_140.setTransform(656.15,29.55);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-2.2,2.3).curveTo(-3.1,1.4,-3.1,0).curveTo(-3.1,-1.4,-2.2,-2.3).curveTo(-1.4,-3.3,0,-3.2).curveTo(1.4,-3.3,2.3,-2.3).curveTo(3.1,-1.4,3.1,0).curveTo(3.1,1.4,2.3,2.3).curveTo(1.4,3.2,0,3.2).curveTo(-1.4,3.2,-2.2,2.3).closePath().moveTo(-1.3,-1.6).curveTo(-1.9,-1.1,-1.9,0).curveTo(-1.9,1,-1.3,1.6).curveTo(-0.8,2.1,0,2.2).curveTo(0.8,2.1,1.3,1.6).curveTo(1.9,1,1.9,0).curveTo(1.9,-1.1,1.3,-1.6).curveTo(0.8,-2.2,0,-2.2).curveTo(-0.8,-2.2,-1.3,-1.6).closePath();
	this.shape_141.setTransform(649.875,29.6);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-0.8,4.6).lineTo(-0.8,-0.4).lineTo(-1.9,-0.4).lineTo(-1.9,-1.5).lineTo(-0.8,-1.5).lineTo(-0.8,-2.5).curveTo(-0.8,-3.5,-0.2,-4.1).curveTo(0.4,-4.6,1.2,-4.6).curveTo(1.8,-4.6,1.9,-4.5).lineTo(1.9,-3.4).lineTo(1.4,-3.5).curveTo(0.4,-3.5,0.4,-2.5).lineTo(0.4,-1.5).lineTo(1.9,-1.5).lineTo(1.9,-0.4).lineTo(0.4,-0.4).lineTo(0.4,4.6).closePath();
	this.shape_142.setTransform(644.125,28.025);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.beginFill("#2E2E2E").beginStroke().moveTo(1.3,4.6).lineTo(-0.7,1.9).lineTo(-1.6,2.7).lineTo(-1.6,4.6).lineTo(-2.8,4.6).lineTo(-2.8,-4.6).lineTo(-1.6,-4.6).lineTo(-1.6,1.2).lineTo(1.1,-1.5).lineTo(2.7,-1.5).lineTo(0.1,1).lineTo(2.8,4.6).closePath();
	this.shape_143.setTransform(636.025,28.05);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-2,2.3).curveTo(-2.9,1.4,-2.9,0).curveTo(-2.9,-1.5,-2,-2.3).curveTo(-1.2,-3.3,0.2,-3.2).curveTo(1.3,-3.2,2,-2.7).curveTo(2.7,-2.1,2.9,-1.3).lineTo(1.8,-0.9).curveTo(1.5,-2.2,0.2,-2.2).curveTo(-0.6,-2.1,-1.1,-1.6).curveTo(-1.7,-1,-1.7,0).curveTo(-1.7,1,-1.1,1.6).curveTo(-0.6,2.1,0.2,2.2).curveTo(1.5,2.2,1.9,0.9).lineTo(2.9,1.4).curveTo(2.7,2.1,2,2.6).curveTo(1.3,3.2,0.2,3.2).curveTo(-1.2,3.2,-2,2.3).closePath();
	this.shape_144.setTransform(629.025,29.6);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-0.6,4.7).lineTo(-0.6,-1.5).lineTo(0.6,-1.5).lineTo(0.6,4.7).closePath().moveTo(-0.6,-3.2).curveTo(-0.9,-3.5,-0.9,-3.8).curveTo(-0.9,-4.2,-0.6,-4.4).curveTo(-0.4,-4.7,0,-4.7).curveTo(0.3,-4.7,0.6,-4.4).curveTo(0.8,-4.2,0.8,-3.8).curveTo(0.8,-3.5,0.6,-3.2).curveTo(0.3,-3,0,-3).curveTo(-0.4,-3,-0.6,-3.2).closePath();
	this.shape_145.setTransform(624.05,28);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-0.6,4.6).lineTo(-0.6,-4.6).lineTo(0.6,-4.6).lineTo(0.6,4.6).closePath();
	this.shape_146.setTransform(620.95,28.05);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-2.8,3.4).curveTo(-4.2,2.1,-4.3,0).curveTo(-4.2,-2.2,-2.8,-3.5).curveTo(-1.5,-4.7,0.2,-4.7).curveTo(1.7,-4.7,2.8,-3.9).curveTo(3.9,-3.2,4.2,-1.9).lineTo(3,-1.4).curveTo(2.5,-3.6,0.2,-3.6).curveTo(-1.1,-3.5,-1.9,-2.7).curveTo(-2.9,-1.7,-2.9,0).curveTo(-2.9,1.6,-1.9,2.6).curveTo(-1.1,3.6,0.2,3.5).curveTo(1.3,3.5,2.1,3).curveTo(2.8,2.3,3.1,1.4).lineTo(4.3,1.8).curveTo(3.8,3.1,2.8,3.9).curveTo(1.7,4.7,0.2,4.7).curveTo(-1.6,4.7,-2.8,3.4).closePath();
	this.shape_147.setTransform(614.65,28.15);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.beginFill().beginStroke("#2E2E2E").setStrokeStyle(1.7,1,1).moveTo(-40,-10).lineTo(40,-10).curveTo(44.1,-10,47.1,-7.1).curveTo(50,-4.2,50,0).curveTo(50,4.1,47.1,7).curveTo(44.1,10,40,10).lineTo(-40,10).curveTo(-44.2,10,-47.1,7).curveTo(-50,4.1,-50,0).curveTo(-50,-4.2,-47.1,-7.1).curveTo(-44.1,-10,-40,-10).closePath();
	this.shape_148.setTransform(651.025,28.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136}]}).wait(285));

	// BKG
	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.beginFill("#F26522").beginStroke().moveTo(-364,45).lineTo(-364,-45).lineTo(364,-45).lineTo(364,45).closePath();
	this.shape_149.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_149).wait(285));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(327.8,23.2,400.2,103);
// library properties:
lib.properties = {
	id: '56DC97A13D194E2C906C95BBEC24E126',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Leaderboard_728x90/gh-pages/images/IMG01jpgcopy.jpg", id:"IMG01jpgcopy"},
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Leaderboard_728x90/gh-pages/images/IMG02jpgcopy.jpg", id:"IMG02jpgcopy"},
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Leaderboard_728x90/gh-pages/images/IMG03.jpg", id:"IMG03"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['56DC97A13D194E2C906C95BBEC24E126'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;